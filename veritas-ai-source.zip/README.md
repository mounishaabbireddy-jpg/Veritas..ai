# VERITAS AI — See Beyond the Synthetic

> Advanced synthetic media detection and forensic signal analysis platform for images and videos.

## 🚀 Quick Start

1. Install dependencies:
```bash
npm install
```

2. Run development server:
```bash
npm run dev
```

Open http://localhost:3000 in your browser.

## 📦 How to Upload to GitHub

1. Create a new repository on [GitHub](https://github.com/new).
2. Upload these extracted files directly via GitHub's "Upload existing files" button, or push via git terminal commands:
```bash
git init
git add .
git commit -m "feat: complete VERITAS AI platform"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```
