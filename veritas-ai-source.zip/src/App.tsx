const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport13_react_jsxDevRuntime["jsxDEV"];/**
* @license
* SPDX-License-Identifier: Apache-2.0
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=ca23fb93";
import { Navbar } from "/src/components/Navbar.tsx";
import { HeroSection } from "/src/components/HeroSection.tsx";
import { MediaUploadSection } from "/src/components/MediaUploadSection.tsx";
import { ResultsDashboard } from "/src/components/ResultsDashboard.tsx";
import { FeaturesSection } from "/src/components/FeaturesSection.tsx";
import { HowItWorksSection } from "/src/components/HowItWorksSection.tsx";
import { TechnologySection } from "/src/components/TechnologySection.tsx";
import { PricingSection } from "/src/components/PricingSection.tsx";
import { FaqSection } from "/src/components/FaqSection.tsx";
import { Footer } from "/src/components/Footer.tsx";
import { MobilePublishModal } from "/src/components/MobilePublishModal.tsx";
import { Check, X, Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=ca23fb93";
var _jsxFileName = "/app/applet/src/App.tsx";
import __vite__cjsImport13_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ca23fb93";
export default function App() {
	const [analysisData, setAnalysisData] = useState(null);
	const [isAnalyzing, setIsAnalyzing] = useState(false);
	const [mobileModalOpen, setMobileModalOpen] = useState(false);
	const [selectedPlan, setSelectedPlan] = useState(null);
	const scrollToAnalyze = () => {
		const el = document.getElementById("analyze");
		if (el) {
			el.scrollIntoView({ behavior: "smooth" });
		}
	};
	const scrollToTech = () => {
		const el = document.getElementById("technology");
		if (el) {
			el.scrollIntoView({ behavior: "smooth" });
		}
	};
	const handleAnalysisComplete = (payload) => {
		setAnalysisData(payload);
	};
	const handleAnalyzeAnother = () => {
		setAnalysisData(null);
		scrollToAnalyze();
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-[#03050a] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/20 selection:text-cyan-200",
		children: [
			/* @__PURE__ */ _jsxDEV(Navbar, {
				onAnalyzeClick: scrollToAnalyze,
				onOpenMobileGuide: () => setMobileModalOpen(true)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1",
				children: [
					/* @__PURE__ */ _jsxDEV(HeroSection, {
						onAnalyzeClick: scrollToAnalyze,
						onExploreTechClick: scrollToTech
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(MediaUploadSection, {
						onAnalysisComplete: handleAnalysisComplete,
						isAnalyzing,
						setIsAnalyzing
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 9
					}, this),
					analysisData && /* @__PURE__ */ _jsxDEV(ResultsDashboard, {
						result: analysisData.result,
						previewUrl: analysisData.previewUrl,
						elaUrl: analysisData.elaUrl,
						highpassUrl: analysisData.highpassUrl,
						luminanceUrl: analysisData.luminanceUrl,
						onAnalyzeAnother: handleAnalyzeAnother
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(HowItWorksSection, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(FeaturesSection, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(TechnologySection, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(PricingSection, { onSelectPlan: (plan) => setSelectedPlan(plan) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 103,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(FaqSection, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 106,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 67,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Footer, {
				onAnalyzeClick: scrollToAnalyze,
				onOpenMobileGuide: () => setMobileModalOpen(true)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 110,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(MobilePublishModal, {
				isOpen: mobileModalOpen,
				onClose: () => setMobileModalOpen(false)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 116,
				columnNumber: 7
			}, this),
			selectedPlan && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "relative w-full max-w-md rounded-2xl border border-cyan-500/30 bg-[#060a18] p-6 shadow-2xl space-y-4",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setSelectedPlan(null),
							className: "absolute top-4 right-4 p-1.5 rounded-lg bg-white/[0.05] text-slate-400 hover:text-white",
							children: /* @__PURE__ */ _jsxDEV(X, { className: "h-4 w-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 129,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-500/20 text-cyan-300",
								children: /* @__PURE__ */ _jsxDEV(Sparkles, { className: "h-5 w-5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 134,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 133,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-base font-bold text-white",
								children: [selectedPlan, " Activated"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 137,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-400 font-mono",
								children: "Immediate Workspace Provisioning"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 140,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 136,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 132,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-300 leading-relaxed",
							children: [
								"Your session has been upgraded to the ",
								/* @__PURE__ */ _jsxDEV("strong", { children: selectedPlan }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 147,
									columnNumber: 53
								}, this),
								" tier. You can now analyze high-resolution media, access all Error Level Analysis filter layers, and export forensic JSON reports."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 146,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300 flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Check, { className: "h-4 w-4 shrink-0 text-emerald-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 151,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Full feature access enabled in this browser session." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 150,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "pt-2 flex justify-end gap-3",
							children: /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									setSelectedPlan(null);
									scrollToAnalyze();
								},
								className: "w-full py-2.5 text-xs font-semibold text-black bg-cyan-400 hover:bg-cyan-300 rounded-xl transition-colors cursor-pointer",
								children: "Go to Detection Studio"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 156,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 155,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 124,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 123,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 59,
		columnNumber: 5
	}, this);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLE9BQU8sU0FBUyxnQkFBZ0I7QUFDaEMsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsMEJBQTBCO0FBQ25DLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsY0FBYztBQUN2QixTQUFTLDBCQUEwQjtBQUVuQyxTQUFTLE9BQU8sR0FBRyxnQkFBZ0I7OztBQVVuQyxlQUFlLFNBQVMsTUFBTTtDQUM1QixNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBaUMsSUFBSTtDQUM3RSxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxLQUFLO0NBQ3BELE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsS0FBSztDQUM1RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBd0IsSUFBSTtDQUVwRSxNQUFNLHdCQUF3QjtFQUM1QixNQUFNLEtBQUssU0FBUyxlQUFlLFNBQVM7RUFDNUMsSUFBSSxJQUFJO0dBQ04sR0FBRyxlQUFlLEVBQUUsVUFBVSxTQUFTLENBQUM7RUFDMUM7Q0FDRjtDQUVBLE1BQU0scUJBQXFCO0VBQ3pCLE1BQU0sS0FBSyxTQUFTLGVBQWUsWUFBWTtFQUMvQyxJQUFJLElBQUk7R0FDTixHQUFHLGVBQWUsRUFBRSxVQUFVLFNBQVMsQ0FBQztFQUMxQztDQUNGO0NBRUEsTUFBTSwwQkFBMEIsWUFBNkI7RUFDM0QsZ0JBQWdCLE9BQU87Q0FDekI7Q0FFQSxNQUFNLDZCQUE2QjtFQUNqQyxnQkFBZ0IsSUFBSTtFQUNwQixnQkFBZ0I7Q0FDbEI7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FHRSx3QkFBQyxRQUFEO0lBQ0UsZ0JBQWdCO0lBQ2hCLHlCQUF5QixtQkFBbUIsSUFBSTtHQUNqRDs7Ozs7R0FFRCx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFoQjtLQUVFLHdCQUFDLGFBQUQ7TUFDRSxnQkFBZ0I7TUFDaEIsb0JBQW9CO0tBQ3JCOzs7OztLQUdELHdCQUFDLG9CQUFEO01BQ0Usb0JBQW9CO01BQ1A7TUFDRztLQUNqQjs7Ozs7S0FHQSxnQkFDQyx3QkFBQyxrQkFBRDtNQUNFLFFBQVEsYUFBYTtNQUNyQixZQUFZLGFBQWE7TUFDekIsUUFBUSxhQUFhO01BQ3JCLGFBQWEsYUFBYTtNQUMxQixjQUFjLGFBQWE7TUFDM0Isa0JBQWtCO0tBQ25COzs7OztLQUlILHdCQUFDLG1CQUFELENBQW9COzs7OztLQUdwQix3QkFBQyxpQkFBRCxDQUFrQjs7Ozs7S0FHbEIsd0JBQUMsbUJBQUQsQ0FBb0I7Ozs7O0tBR3BCLHdCQUFDLGdCQUFELEVBQWdCLGVBQWUsU0FBUyxnQkFBZ0IsSUFBSSxFQUFJOzs7OztLQUdoRSx3QkFBQyxZQUFELENBQWE7Ozs7O0lBQ1Q7Ozs7OztHQUdOLHdCQUFDLFFBQUQ7SUFDRSxnQkFBZ0I7SUFDaEIseUJBQXlCLG1CQUFtQixJQUFJO0dBQ2pEOzs7OztHQUdELHdCQUFDLG9CQUFEO0lBQ0UsUUFBUTtJQUNSLGVBQWUsbUJBQW1CLEtBQUs7R0FDeEM7Ozs7O0dBR0EsZ0JBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsVUFBRDtPQUNFLGVBQWUsZ0JBQWdCLElBQUk7T0FDbkMsV0FBVTtpQkFFVix3QkFBQyxHQUFELEVBQUcsV0FBVSxVQUFXOzs7OztNQUNsQjs7Ozs7TUFFUix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFVBQVc7Ozs7O09BQzVCOzs7O2lCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZCxDQUNHLGNBQWEsWUFDWjs7Ozs7aUJBQ0osd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQW1DO09BRTdDOzs7O2VBQ0E7Ozs7ZUFDRjs7Ozs7O01BRUwsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWI7UUFBc0Q7UUFDZCx3QkFBQyxVQUFELFlBQVMsYUFBcUI7Ozs7O1FBQUM7T0FDcEU7Ozs7OztNQUVILHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsb0NBQXFDOzs7O2lCQUN0RCx3QkFBQyxRQUFELFlBQU0sdURBQTBEOzs7O2VBQzdEOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxVQUFEO1FBQ0UsZUFBZTtTQUNiLGdCQUFnQixJQUFJO1NBQ3BCLGdCQUFnQjtRQUNsQjtRQUNBLFdBQVU7a0JBQ1g7T0FFTzs7Ozs7TUFDTDs7Ozs7S0FDRjs7Ozs7O0dBQ0Y7Ozs7O0VBR0o7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogU1BEWC1MaWNlbnNlLUlkZW50aWZpZXI6IEFwYWNoZS0yLjBcbiAqL1xuXG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBOYXZiYXIgfSBmcm9tICcuL2NvbXBvbmVudHMvTmF2YmFyJztcbmltcG9ydCB7IEhlcm9TZWN0aW9uIH0gZnJvbSAnLi9jb21wb25lbnRzL0hlcm9TZWN0aW9uJztcbmltcG9ydCB7IE1lZGlhVXBsb2FkU2VjdGlvbiB9IGZyb20gJy4vY29tcG9uZW50cy9NZWRpYVVwbG9hZFNlY3Rpb24nO1xuaW1wb3J0IHsgUmVzdWx0c0Rhc2hib2FyZCB9IGZyb20gJy4vY29tcG9uZW50cy9SZXN1bHRzRGFzaGJvYXJkJztcbmltcG9ydCB7IEZlYXR1cmVzU2VjdGlvbiB9IGZyb20gJy4vY29tcG9uZW50cy9GZWF0dXJlc1NlY3Rpb24nO1xuaW1wb3J0IHsgSG93SXRXb3Jrc1NlY3Rpb24gfSBmcm9tICcuL2NvbXBvbmVudHMvSG93SXRXb3Jrc1NlY3Rpb24nO1xuaW1wb3J0IHsgVGVjaG5vbG9neVNlY3Rpb24gfSBmcm9tICcuL2NvbXBvbmVudHMvVGVjaG5vbG9neVNlY3Rpb24nO1xuaW1wb3J0IHsgUHJpY2luZ1NlY3Rpb24gfSBmcm9tICcuL2NvbXBvbmVudHMvUHJpY2luZ1NlY3Rpb24nO1xuaW1wb3J0IHsgRmFxU2VjdGlvbiB9IGZyb20gJy4vY29tcG9uZW50cy9GYXFTZWN0aW9uJztcbmltcG9ydCB7IEZvb3RlciB9IGZyb20gJy4vY29tcG9uZW50cy9Gb290ZXInO1xuaW1wb3J0IHsgTW9iaWxlUHVibGlzaE1vZGFsIH0gZnJvbSAnLi9jb21wb25lbnRzL01vYmlsZVB1Ymxpc2hNb2RhbCc7XG5pbXBvcnQgeyBBbmFseXNpc1Jlc3VsdCB9IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IHsgQ2hlY2ssIFgsIFNwYXJrbGVzIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuaW50ZXJmYWNlIEFuYWx5c2lzUGF5bG9hZCB7XG4gIHJlc3VsdDogQW5hbHlzaXNSZXN1bHQ7XG4gIHByZXZpZXdVcmw6IHN0cmluZztcbiAgZWxhVXJsPzogc3RyaW5nO1xuICBoaWdocGFzc1VybD86IHN0cmluZztcbiAgbHVtaW5hbmNlVXJsPzogc3RyaW5nO1xufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoKSB7XG4gIGNvbnN0IFthbmFseXNpc0RhdGEsIHNldEFuYWx5c2lzRGF0YV0gPSB1c2VTdGF0ZTxBbmFseXNpc1BheWxvYWQgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2lzQW5hbHl6aW5nLCBzZXRJc0FuYWx5emluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFttb2JpbGVNb2RhbE9wZW4sIHNldE1vYmlsZU1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtzZWxlY3RlZFBsYW4sIHNldFNlbGVjdGVkUGxhbl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICBjb25zdCBzY3JvbGxUb0FuYWx5emUgPSAoKSA9PiB7XG4gICAgY29uc3QgZWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnYW5hbHl6ZScpO1xuICAgIGlmIChlbCkge1xuICAgICAgZWwuc2Nyb2xsSW50b1ZpZXcoeyBiZWhhdmlvcjogJ3Ntb290aCcgfSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IHNjcm9sbFRvVGVjaCA9ICgpID0+IHtcbiAgICBjb25zdCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0ZWNobm9sb2d5Jyk7XG4gICAgaWYgKGVsKSB7XG4gICAgICBlbC5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiAnc21vb3RoJyB9KTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQW5hbHlzaXNDb21wbGV0ZSA9IChwYXlsb2FkOiBBbmFseXNpc1BheWxvYWQpID0+IHtcbiAgICBzZXRBbmFseXNpc0RhdGEocGF5bG9hZCk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQW5hbHl6ZUFub3RoZXIgPSAoKSA9PiB7XG4gICAgc2V0QW5hbHlzaXNEYXRhKG51bGwpO1xuICAgIHNjcm9sbFRvQW5hbHl6ZSgpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctWyMwMzA1MGFdIHRleHQtc2xhdGUtMTAwIGZsZXggZmxleC1jb2wgZm9udC1zYW5zIHNlbGVjdGlvbjpiZy1jeWFuLTUwMC8yMCBzZWxlY3Rpb246dGV4dC1jeWFuLTIwMFwiPlxuICAgICAgXG4gICAgICB7LyogVG9wIE5hdmJhciAqL31cbiAgICAgIDxOYXZiYXJcbiAgICAgICAgb25BbmFseXplQ2xpY2s9e3Njcm9sbFRvQW5hbHl6ZX1cbiAgICAgICAgb25PcGVuTW9iaWxlR3VpZGU9eygpID0+IHNldE1vYmlsZU1vZGFsT3Blbih0cnVlKX1cbiAgICAgIC8+XG5cbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMVwiPlxuICAgICAgICB7LyogSGVybyBTZWN0aW9uICovfVxuICAgICAgICA8SGVyb1NlY3Rpb25cbiAgICAgICAgICBvbkFuYWx5emVDbGljaz17c2Nyb2xsVG9BbmFseXplfVxuICAgICAgICAgIG9uRXhwbG9yZVRlY2hDbGljaz17c2Nyb2xsVG9UZWNofVxuICAgICAgICAvPlxuXG4gICAgICAgIHsvKiBVcGxvYWQgJiBEZXRlY3Rpb24gV29ya3NwYWNlICovfVxuICAgICAgICA8TWVkaWFVcGxvYWRTZWN0aW9uXG4gICAgICAgICAgb25BbmFseXNpc0NvbXBsZXRlPXtoYW5kbGVBbmFseXNpc0NvbXBsZXRlfVxuICAgICAgICAgIGlzQW5hbHl6aW5nPXtpc0FuYWx5emluZ31cbiAgICAgICAgICBzZXRJc0FuYWx5emluZz17c2V0SXNBbmFseXppbmd9XG4gICAgICAgIC8+XG5cbiAgICAgICAgey8qIFJlc3VsdHMgRGFzaGJvYXJkIChBY3RpdmUgd2hlbiBtZWRpYSBpcyBhbmFseXplZCkgKi99XG4gICAgICAgIHthbmFseXNpc0RhdGEgJiYgKFxuICAgICAgICAgIDxSZXN1bHRzRGFzaGJvYXJkXG4gICAgICAgICAgICByZXN1bHQ9e2FuYWx5c2lzRGF0YS5yZXN1bHR9XG4gICAgICAgICAgICBwcmV2aWV3VXJsPXthbmFseXNpc0RhdGEucHJldmlld1VybH1cbiAgICAgICAgICAgIGVsYVVybD17YW5hbHlzaXNEYXRhLmVsYVVybH1cbiAgICAgICAgICAgIGhpZ2hwYXNzVXJsPXthbmFseXNpc0RhdGEuaGlnaHBhc3NVcmx9XG4gICAgICAgICAgICBsdW1pbmFuY2VVcmw9e2FuYWx5c2lzRGF0YS5sdW1pbmFuY2VVcmx9XG4gICAgICAgICAgICBvbkFuYWx5emVBbm90aGVyPXtoYW5kbGVBbmFseXplQW5vdGhlcn1cbiAgICAgICAgICAvPlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiBIb3cgSXQgV29ya3MgUGlwZWxpbmUgKi99XG4gICAgICAgIDxIb3dJdFdvcmtzU2VjdGlvbiAvPlxuXG4gICAgICAgIHsvKiBGb3JlbnNpYyBDYXBhYmlsaXRpZXMgJiBGZWF0dXJlcyAqL31cbiAgICAgICAgPEZlYXR1cmVzU2VjdGlvbiAvPlxuXG4gICAgICAgIHsvKiBTY2llbnRpZmljIEZvdW5kYXRpb25zICYgVGVjaG5vbG9neSAqL31cbiAgICAgICAgPFRlY2hub2xvZ3lTZWN0aW9uIC8+XG5cbiAgICAgICAgey8qIFRyYW5zcGFyZW50IFByaWNpbmcgUGxhbnMgKi99XG4gICAgICAgIDxQcmljaW5nU2VjdGlvbiBvblNlbGVjdFBsYW49eyhwbGFuKSA9PiBzZXRTZWxlY3RlZFBsYW4ocGxhbil9IC8+XG5cbiAgICAgICAgey8qIEZyZXF1ZW50bHkgQXNrZWQgUXVlc3Rpb25zICovfVxuICAgICAgICA8RmFxU2VjdGlvbiAvPlxuICAgICAgPC9tYWluPlxuXG4gICAgICB7LyogRm9vdGVyICovfVxuICAgICAgPEZvb3RlclxuICAgICAgICBvbkFuYWx5emVDbGljaz17c2Nyb2xsVG9BbmFseXplfVxuICAgICAgICBvbk9wZW5Nb2JpbGVHdWlkZT17KCkgPT4gc2V0TW9iaWxlTW9kYWxPcGVuKHRydWUpfVxuICAgICAgLz5cblxuICAgICAgey8qIE1vYmlsZSBQdWJsaXNoaW5nIEd1aWRlIE1vZGFsICovfVxuICAgICAgPE1vYmlsZVB1Ymxpc2hNb2RhbFxuICAgICAgICBpc09wZW49e21vYmlsZU1vZGFsT3Blbn1cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0TW9iaWxlTW9kYWxPcGVuKGZhbHNlKX1cbiAgICAgIC8+XG5cbiAgICAgIHsvKiBQbGFuIFNlbGVjdGlvbiBDb25maXJtYXRpb24gTW9kYWwgKi99XG4gICAgICB7c2VsZWN0ZWRQbGFuICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGJnLWJsYWNrLzgwIGJhY2tkcm9wLWJsdXItbWQgYW5pbWF0ZS1pbiBmYWRlLWluXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXctbWQgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1jeWFuLTUwMC8zMCBiZy1bIzA2MGExOF0gcC02IHNoYWRvdy0yeGwgc3BhY2UteS00XCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkUGxhbihudWxsKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTQgcmlnaHQtNCBwLTEuNSByb3VuZGVkLWxnIGJnLXdoaXRlL1swLjA1XSB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC0xMCB3LTEwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXhsIGJnLWN5YW4tNTAwLzIwIHRleHQtY3lhbi0zMDBcIj5cbiAgICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFBsYW59IEFjdGl2YXRlZFxuICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgIEltbWVkaWF0ZSBXb3Jrc3BhY2UgUHJvdmlzaW9uaW5nXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtMzAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICBZb3VyIHNlc3Npb24gaGFzIGJlZW4gdXBncmFkZWQgdG8gdGhlIDxzdHJvbmc+e3NlbGVjdGVkUGxhbn08L3N0cm9uZz4gdGllci4gWW91IGNhbiBub3cgYW5hbHl6ZSBoaWdoLXJlc29sdXRpb24gbWVkaWEsIGFjY2VzcyBhbGwgRXJyb3IgTGV2ZWwgQW5hbHlzaXMgZmlsdGVyIGxheWVycywgYW5kIGV4cG9ydCBmb3JlbnNpYyBKU09OIHJlcG9ydHMuXG4gICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQtbGcgYmctZW1lcmFsZC01MDAvMTAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8yMCB0ZXh0LXhzIHRleHQtZW1lcmFsZC0zMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPENoZWNrIGNsYXNzTmFtZT1cImgtNCB3LTQgc2hyaW5rLTAgdGV4dC1lbWVyYWxkLTQwMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPkZ1bGwgZmVhdHVyZSBhY2Nlc3MgZW5hYmxlZCBpbiB0aGlzIGJyb3dzZXIgc2Vzc2lvbi48L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIGZsZXgganVzdGlmeS1lbmQgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkUGxhbihudWxsKTtcbiAgICAgICAgICAgICAgICAgIHNjcm9sbFRvQW5hbHl6ZSgpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBiZy1jeWFuLTQwMCBob3ZlcjpiZy1jeWFuLTMwMCByb3VuZGVkLXhsIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIEdvIHRvIERldGVjdGlvbiBTdHVkaW9cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgPC9kaXY+XG4gICk7XG59XG4iXX0=