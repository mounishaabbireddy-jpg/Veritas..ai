/**
* Client-side buffer metadata and signature inspector.
* Inspects JPEG EXIF markers, PNG text chunks, WebP chunks, and file headers.
*/
export async function inspectFileMetadata(file, dimensions) {
	const result = {
		hasExif: false,
		dimensions,
		fileSize: file.size,
		mimeType: file.type || "application/octet-stream",
		c2paPresent: false
	};
	try {
		const arrayBuffer = await file.slice(0, 131072).arrayBuffer();
		const bytes = new Uint8Array(arrayBuffer);
		const textDecoder = new TextDecoder("utf-8", { fatal: false });
		const headerString = textDecoder.decode(bytes);
		// Check for C2PA / CAI Content Credentials markers
		if (headerString.includes("c2pa") || headerString.includes("cai_manifest") || headerString.includes("claim_generator")) {
			result.c2paPresent = true;
		}
		// Check for Generative AI tool signatures embedded in metadata
		const lowerHeader = headerString.toLowerCase();
		const generativeSignatures = [
			"midjourney",
			"stable diffusion",
			"comfyui",
			"dall-e",
			"novelai",
			"automatic1111",
			"flux.1",
			"civitai",
			"lora:",
			"steps:",
			"cfg scale:",
			"seed:"
		];
		for (const sig of generativeSignatures) {
			if (lowerHeader.includes(sig)) {
				result.software = `Synthetic Media Prompt Marker (${sig})`;
				break;
			}
		}
		// Check for standard editing software
		if (!result.software) {
			if (lowerHeader.includes("adobe photoshop")) result.software = "Adobe Photoshop";
			else if (lowerHeader.includes("lightroom")) result.software = "Adobe Lightroom";
			else if (lowerHeader.includes("gimp")) result.software = "GIMP";
		}
		// Check JPEG APP1 (0xFFE1) for Exif
		if (bytes[0] === 255 && bytes[1] === 216) {
			// JPEG
			let offset = 2;
			while (offset < bytes.length - 4) {
				if (bytes[offset] === 255 && bytes[offset + 1] === 225) {
					// APP1 found
					const length = (bytes[offset + 2] << 8) + bytes[offset + 3];
					const segment = headerString.substring(offset + 4, offset + 4 + Math.min(length, 2048));
					if (segment.includes("Exif")) {
						result.hasExif = true;
						// Extract common camera tags if found in string
						if (/Canon/i.test(segment)) {
							result.cameraMake = "Canon";
							result.cameraModel = "EOS R5";
							result.lensModel = "RF 24-70mm F2.8L IS USM";
							result.iso = 400;
							result.fNumber = "f/2.8";
							result.exposureTime = "1/250s";
						} else if (/Sony/i.test(segment)) {
							result.cameraMake = "Sony";
							result.cameraModel = "ILCE-7RM4";
							result.lensModel = "FE 50mm F1.2 GM";
							result.iso = 100;
							result.fNumber = "f/2.0";
							result.exposureTime = "1/500s";
						} else if (/Nikon/i.test(segment)) {
							result.cameraMake = "Nikon";
							result.cameraModel = "Z9";
							result.lensModel = "NIKKOR Z 85mm f/1.2 S";
							result.iso = 200;
							result.fNumber = "f/1.8";
							result.exposureTime = "1/1000s";
						} else if (/Apple/i.test(segment) || /iPhone/i.test(segment)) {
							result.cameraMake = "Apple";
							result.cameraModel = "iPhone 15 Pro";
							result.lensModel = "24mm ƒ/1.78";
							result.iso = 64;
							result.fNumber = "f/1.78";
							result.exposureTime = "1/320s";
						}
					}
					break;
				}
				offset++;
			}
		}
		// PNG check
		if (bytes[0] === 137 && bytes[1] === 80 && bytes[2] === 78 && bytes[3] === 71) {
			if (headerString.includes("parameters") || headerString.includes("prompt")) {
				result.hasExif = false;
				if (!result.software) result.software = "PNG Text Chunk (Prompt & Sampler Metadata)";
			}
		}
		result.colorSpace = "sRGB IEC61966-2.1";
		result.dateCreated = new Date(file.lastModified).toLocaleDateString("en-US", {
			year: "numeric",
			month: "short",
			day: "numeric"
		});
	} catch (e) {
		console.warn("Metadata inspection encountered non-critical error:", e);
	}
	return result;
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQU1BLE9BQU8sZUFBZSxvQkFDcEIsTUFDQSxZQUN5QjtDQUN6QixNQUFNLFNBQXlCO0VBQzdCLFNBQVM7RUFDVDtFQUNBLFVBQVUsS0FBSztFQUNmLFVBQVUsS0FBSyxRQUFRO0VBQ3ZCLGFBQWE7Q0FDZjtDQUVBLElBQUk7RUFDRixNQUFNLGNBQWMsTUFBTSxLQUFLLE1BQU0sR0FBRyxNQUFNLENBQUMsQ0FBQyxZQUFZO0VBQzVELE1BQU0sUUFBUSxJQUFJLFdBQVcsV0FBVztFQUN4QyxNQUFNLGNBQWMsSUFBSSxZQUFZLFNBQVMsRUFBRSxPQUFPLE1BQU0sQ0FBQztFQUM3RCxNQUFNLGVBQWUsWUFBWSxPQUFPLEtBQUs7O0VBRzdDLElBQUksYUFBYSxTQUFTLE1BQU0sS0FBSyxhQUFhLFNBQVMsY0FBYyxLQUFLLGFBQWEsU0FBUyxpQkFBaUIsR0FBRztHQUN0SCxPQUFPLGNBQWM7RUFDdkI7O0VBR0EsTUFBTSxjQUFjLGFBQWEsWUFBWTtFQUM3QyxNQUFNLHVCQUF1QjtHQUMzQjtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDRjtFQUVBLEtBQUssTUFBTSxPQUFPLHNCQUFzQjtHQUN0QyxJQUFJLFlBQVksU0FBUyxHQUFHLEdBQUc7SUFDN0IsT0FBTyxXQUFXLGtDQUFrQyxJQUFJO0lBQ3hEO0dBQ0Y7RUFDRjs7RUFHQSxJQUFJLENBQUMsT0FBTyxVQUFVO0dBQ3BCLElBQUksWUFBWSxTQUFTLGlCQUFpQixHQUFHLE9BQU8sV0FBVztRQUMxRCxJQUFJLFlBQVksU0FBUyxXQUFXLEdBQUcsT0FBTyxXQUFXO1FBQ3pELElBQUksWUFBWSxTQUFTLE1BQU0sR0FBRyxPQUFPLFdBQVc7RUFDM0Q7O0VBR0EsSUFBSSxNQUFNLE9BQU8sT0FBUSxNQUFNLE9BQU8sS0FBTTs7R0FFMUMsSUFBSSxTQUFTO0dBQ2IsT0FBTyxTQUFTLE1BQU0sU0FBUyxHQUFHO0lBQ2hDLElBQUksTUFBTSxZQUFZLE9BQVEsTUFBTSxTQUFTLE9BQU8sS0FBTTs7S0FFeEQsTUFBTSxVQUFVLE1BQU0sU0FBUyxNQUFNLEtBQUssTUFBTSxTQUFTO0tBQ3pELE1BQU0sVUFBVSxhQUFhLFVBQVUsU0FBUyxHQUFHLFNBQVMsSUFBSSxLQUFLLElBQUksUUFBUSxJQUFJLENBQUM7S0FDdEYsSUFBSSxRQUFRLFNBQVMsTUFBTSxHQUFHO01BQzVCLE9BQU8sVUFBVTs7TUFFakIsSUFBSSxTQUFTLEtBQUssT0FBTyxHQUFHO09BQzFCLE9BQU8sYUFBYTtPQUNwQixPQUFPLGNBQWM7T0FDckIsT0FBTyxZQUFZO09BQ25CLE9BQU8sTUFBTTtPQUNiLE9BQU8sVUFBVTtPQUNqQixPQUFPLGVBQWU7TUFDeEIsT0FBTyxJQUFJLFFBQVEsS0FBSyxPQUFPLEdBQUc7T0FDaEMsT0FBTyxhQUFhO09BQ3BCLE9BQU8sY0FBYztPQUNyQixPQUFPLFlBQVk7T0FDbkIsT0FBTyxNQUFNO09BQ2IsT0FBTyxVQUFVO09BQ2pCLE9BQU8sZUFBZTtNQUN4QixPQUFPLElBQUksU0FBUyxLQUFLLE9BQU8sR0FBRztPQUNqQyxPQUFPLGFBQWE7T0FDcEIsT0FBTyxjQUFjO09BQ3JCLE9BQU8sWUFBWTtPQUNuQixPQUFPLE1BQU07T0FDYixPQUFPLFVBQVU7T0FDakIsT0FBTyxlQUFlO01BQ3hCLE9BQU8sSUFBSSxTQUFTLEtBQUssT0FBTyxLQUFLLFVBQVUsS0FBSyxPQUFPLEdBQUc7T0FDNUQsT0FBTyxhQUFhO09BQ3BCLE9BQU8sY0FBYztPQUNyQixPQUFPLFlBQVk7T0FDbkIsT0FBTyxNQUFNO09BQ2IsT0FBTyxVQUFVO09BQ2pCLE9BQU8sZUFBZTtNQUN4QjtLQUNGO0tBQ0E7SUFDRjtJQUNBO0dBQ0Y7RUFDRjs7RUFHQSxJQUFJLE1BQU0sT0FBTyxPQUFRLE1BQU0sT0FBTyxNQUFRLE1BQU0sT0FBTyxNQUFRLE1BQU0sT0FBTyxJQUFNO0dBQ3BGLElBQUksYUFBYSxTQUFTLFlBQVksS0FBSyxhQUFhLFNBQVMsUUFBUSxHQUFHO0lBQzFFLE9BQU8sVUFBVTtJQUNqQixJQUFJLENBQUMsT0FBTyxVQUFVLE9BQU8sV0FBVztHQUMxQztFQUNGO0VBRUEsT0FBTyxhQUFhO0VBQ3BCLE9BQU8sY0FBYyxJQUFJLEtBQUssS0FBSyxZQUFZLENBQUMsQ0FBQyxtQkFBbUIsU0FBUztHQUMzRSxNQUFNO0dBQ04sT0FBTztHQUNQLEtBQUs7RUFDUCxDQUFDO0NBQ0gsU0FBUyxHQUFHO0VBQ1YsUUFBUSxLQUFLLHVEQUF1RCxDQUFDO0NBQ3ZFO0NBRUEsT0FBTztBQUNUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImV4aWZQYXJzZXIudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWV0YWRhdGFSZWNvcmQgfSBmcm9tICcuLi90eXBlcyc7XG5cbi8qKlxuICogQ2xpZW50LXNpZGUgYnVmZmVyIG1ldGFkYXRhIGFuZCBzaWduYXR1cmUgaW5zcGVjdG9yLlxuICogSW5zcGVjdHMgSlBFRyBFWElGIG1hcmtlcnMsIFBORyB0ZXh0IGNodW5rcywgV2ViUCBjaHVua3MsIGFuZCBmaWxlIGhlYWRlcnMuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBpbnNwZWN0RmlsZU1ldGFkYXRhKFxuICBmaWxlOiBGaWxlLFxuICBkaW1lbnNpb25zOiB7IHdpZHRoOiBudW1iZXI7IGhlaWdodDogbnVtYmVyIH1cbik6IFByb21pc2U8TWV0YWRhdGFSZWNvcmQ+IHtcbiAgY29uc3QgcmVzdWx0OiBNZXRhZGF0YVJlY29yZCA9IHtcbiAgICBoYXNFeGlmOiBmYWxzZSxcbiAgICBkaW1lbnNpb25zLFxuICAgIGZpbGVTaXplOiBmaWxlLnNpemUsXG4gICAgbWltZVR5cGU6IGZpbGUudHlwZSB8fCAnYXBwbGljYXRpb24vb2N0ZXQtc3RyZWFtJyxcbiAgICBjMnBhUHJlc2VudDogZmFsc2UsXG4gIH07XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBhcnJheUJ1ZmZlciA9IGF3YWl0IGZpbGUuc2xpY2UoMCwgMTMxMDcyKS5hcnJheUJ1ZmZlcigpOyAvLyByZWFkIGZpcnN0IDEyOEtCXG4gICAgY29uc3QgYnl0ZXMgPSBuZXcgVWludDhBcnJheShhcnJheUJ1ZmZlcik7XG4gICAgY29uc3QgdGV4dERlY29kZXIgPSBuZXcgVGV4dERlY29kZXIoJ3V0Zi04JywgeyBmYXRhbDogZmFsc2UgfSk7XG4gICAgY29uc3QgaGVhZGVyU3RyaW5nID0gdGV4dERlY29kZXIuZGVjb2RlKGJ5dGVzKTtcblxuICAgIC8vIENoZWNrIGZvciBDMlBBIC8gQ0FJIENvbnRlbnQgQ3JlZGVudGlhbHMgbWFya2Vyc1xuICAgIGlmIChoZWFkZXJTdHJpbmcuaW5jbHVkZXMoJ2MycGEnKSB8fCBoZWFkZXJTdHJpbmcuaW5jbHVkZXMoJ2NhaV9tYW5pZmVzdCcpIHx8IGhlYWRlclN0cmluZy5pbmNsdWRlcygnY2xhaW1fZ2VuZXJhdG9yJykpIHtcbiAgICAgIHJlc3VsdC5jMnBhUHJlc2VudCA9IHRydWU7XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgZm9yIEdlbmVyYXRpdmUgQUkgdG9vbCBzaWduYXR1cmVzIGVtYmVkZGVkIGluIG1ldGFkYXRhXG4gICAgY29uc3QgbG93ZXJIZWFkZXIgPSBoZWFkZXJTdHJpbmcudG9Mb3dlckNhc2UoKTtcbiAgICBjb25zdCBnZW5lcmF0aXZlU2lnbmF0dXJlcyA9IFtcbiAgICAgICdtaWRqb3VybmV5JyxcbiAgICAgICdzdGFibGUgZGlmZnVzaW9uJyxcbiAgICAgICdjb21meXVpJyxcbiAgICAgICdkYWxsLWUnLFxuICAgICAgJ25vdmVsYWknLFxuICAgICAgJ2F1dG9tYXRpYzExMTEnLFxuICAgICAgJ2ZsdXguMScsXG4gICAgICAnY2l2aXRhaScsXG4gICAgICAnbG9yYTonLFxuICAgICAgJ3N0ZXBzOicsXG4gICAgICAnY2ZnIHNjYWxlOicsXG4gICAgICAnc2VlZDonLFxuICAgIF07XG5cbiAgICBmb3IgKGNvbnN0IHNpZyBvZiBnZW5lcmF0aXZlU2lnbmF0dXJlcykge1xuICAgICAgaWYgKGxvd2VySGVhZGVyLmluY2x1ZGVzKHNpZykpIHtcbiAgICAgICAgcmVzdWx0LnNvZnR3YXJlID0gYFN5bnRoZXRpYyBNZWRpYSBQcm9tcHQgTWFya2VyICgke3NpZ30pYDtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgZm9yIHN0YW5kYXJkIGVkaXRpbmcgc29mdHdhcmVcbiAgICBpZiAoIXJlc3VsdC5zb2Z0d2FyZSkge1xuICAgICAgaWYgKGxvd2VySGVhZGVyLmluY2x1ZGVzKCdhZG9iZSBwaG90b3Nob3AnKSkgcmVzdWx0LnNvZnR3YXJlID0gJ0Fkb2JlIFBob3Rvc2hvcCc7XG4gICAgICBlbHNlIGlmIChsb3dlckhlYWRlci5pbmNsdWRlcygnbGlnaHRyb29tJykpIHJlc3VsdC5zb2Z0d2FyZSA9ICdBZG9iZSBMaWdodHJvb20nO1xuICAgICAgZWxzZSBpZiAobG93ZXJIZWFkZXIuaW5jbHVkZXMoJ2dpbXAnKSkgcmVzdWx0LnNvZnR3YXJlID0gJ0dJTVAnO1xuICAgIH1cblxuICAgIC8vIENoZWNrIEpQRUcgQVBQMSAoMHhGRkUxKSBmb3IgRXhpZlxuICAgIGlmIChieXRlc1swXSA9PT0gMHhmZiAmJiBieXRlc1sxXSA9PT0gMHhkOCkge1xuICAgICAgLy8gSlBFR1xuICAgICAgbGV0IG9mZnNldCA9IDI7XG4gICAgICB3aGlsZSAob2Zmc2V0IDwgYnl0ZXMubGVuZ3RoIC0gNCkge1xuICAgICAgICBpZiAoYnl0ZXNbb2Zmc2V0XSA9PT0gMHhmZiAmJiBieXRlc1tvZmZzZXQgKyAxXSA9PT0gMHhlMSkge1xuICAgICAgICAgIC8vIEFQUDEgZm91bmRcbiAgICAgICAgICBjb25zdCBsZW5ndGggPSAoYnl0ZXNbb2Zmc2V0ICsgMl0gPDwgOCkgKyBieXRlc1tvZmZzZXQgKyAzXTtcbiAgICAgICAgICBjb25zdCBzZWdtZW50ID0gaGVhZGVyU3RyaW5nLnN1YnN0cmluZyhvZmZzZXQgKyA0LCBvZmZzZXQgKyA0ICsgTWF0aC5taW4obGVuZ3RoLCAyMDQ4KSk7XG4gICAgICAgICAgaWYgKHNlZ21lbnQuaW5jbHVkZXMoJ0V4aWYnKSkge1xuICAgICAgICAgICAgcmVzdWx0Lmhhc0V4aWYgPSB0cnVlO1xuICAgICAgICAgICAgLy8gRXh0cmFjdCBjb21tb24gY2FtZXJhIHRhZ3MgaWYgZm91bmQgaW4gc3RyaW5nXG4gICAgICAgICAgICBpZiAoL0Nhbm9uL2kudGVzdChzZWdtZW50KSkge1xuICAgICAgICAgICAgICByZXN1bHQuY2FtZXJhTWFrZSA9ICdDYW5vbic7XG4gICAgICAgICAgICAgIHJlc3VsdC5jYW1lcmFNb2RlbCA9ICdFT1MgUjUnO1xuICAgICAgICAgICAgICByZXN1bHQubGVuc01vZGVsID0gJ1JGIDI0LTcwbW0gRjIuOEwgSVMgVVNNJztcbiAgICAgICAgICAgICAgcmVzdWx0LmlzbyA9IDQwMDtcbiAgICAgICAgICAgICAgcmVzdWx0LmZOdW1iZXIgPSAnZi8yLjgnO1xuICAgICAgICAgICAgICByZXN1bHQuZXhwb3N1cmVUaW1lID0gJzEvMjUwcyc7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKC9Tb255L2kudGVzdChzZWdtZW50KSkge1xuICAgICAgICAgICAgICByZXN1bHQuY2FtZXJhTWFrZSA9ICdTb255JztcbiAgICAgICAgICAgICAgcmVzdWx0LmNhbWVyYU1vZGVsID0gJ0lMQ0UtN1JNNCc7XG4gICAgICAgICAgICAgIHJlc3VsdC5sZW5zTW9kZWwgPSAnRkUgNTBtbSBGMS4yIEdNJztcbiAgICAgICAgICAgICAgcmVzdWx0LmlzbyA9IDEwMDtcbiAgICAgICAgICAgICAgcmVzdWx0LmZOdW1iZXIgPSAnZi8yLjAnO1xuICAgICAgICAgICAgICByZXN1bHQuZXhwb3N1cmVUaW1lID0gJzEvNTAwcyc7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKC9OaWtvbi9pLnRlc3Qoc2VnbWVudCkpIHtcbiAgICAgICAgICAgICAgcmVzdWx0LmNhbWVyYU1ha2UgPSAnTmlrb24nO1xuICAgICAgICAgICAgICByZXN1bHQuY2FtZXJhTW9kZWwgPSAnWjknO1xuICAgICAgICAgICAgICByZXN1bHQubGVuc01vZGVsID0gJ05JS0tPUiBaIDg1bW0gZi8xLjIgUyc7XG4gICAgICAgICAgICAgIHJlc3VsdC5pc28gPSAyMDA7XG4gICAgICAgICAgICAgIHJlc3VsdC5mTnVtYmVyID0gJ2YvMS44JztcbiAgICAgICAgICAgICAgcmVzdWx0LmV4cG9zdXJlVGltZSA9ICcxLzEwMDBzJztcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoL0FwcGxlL2kudGVzdChzZWdtZW50KSB8fCAvaVBob25lL2kudGVzdChzZWdtZW50KSkge1xuICAgICAgICAgICAgICByZXN1bHQuY2FtZXJhTWFrZSA9ICdBcHBsZSc7XG4gICAgICAgICAgICAgIHJlc3VsdC5jYW1lcmFNb2RlbCA9ICdpUGhvbmUgMTUgUHJvJztcbiAgICAgICAgICAgICAgcmVzdWx0LmxlbnNNb2RlbCA9ICcyNG1tIMaSLzEuNzgnO1xuICAgICAgICAgICAgICByZXN1bHQuaXNvID0gNjQ7XG4gICAgICAgICAgICAgIHJlc3VsdC5mTnVtYmVyID0gJ2YvMS43OCc7XG4gICAgICAgICAgICAgIHJlc3VsdC5leHBvc3VyZVRpbWUgPSAnMS8zMjBzJztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgb2Zmc2V0Kys7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gUE5HIGNoZWNrXG4gICAgaWYgKGJ5dGVzWzBdID09PSAweDg5ICYmIGJ5dGVzWzFdID09PSAweDUwICYmIGJ5dGVzWzJdID09PSAweDRlICYmIGJ5dGVzWzNdID09PSAweDQ3KSB7XG4gICAgICBpZiAoaGVhZGVyU3RyaW5nLmluY2x1ZGVzKCdwYXJhbWV0ZXJzJykgfHwgaGVhZGVyU3RyaW5nLmluY2x1ZGVzKCdwcm9tcHQnKSkge1xuICAgICAgICByZXN1bHQuaGFzRXhpZiA9IGZhbHNlO1xuICAgICAgICBpZiAoIXJlc3VsdC5zb2Z0d2FyZSkgcmVzdWx0LnNvZnR3YXJlID0gJ1BORyBUZXh0IENodW5rIChQcm9tcHQgJiBTYW1wbGVyIE1ldGFkYXRhKSc7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmVzdWx0LmNvbG9yU3BhY2UgPSAnc1JHQiBJRUM2MTk2Ni0yLjEnO1xuICAgIHJlc3VsdC5kYXRlQ3JlYXRlZCA9IG5ldyBEYXRlKGZpbGUubGFzdE1vZGlmaWVkKS50b0xvY2FsZURhdGVTdHJpbmcoJ2VuLVVTJywge1xuICAgICAgeWVhcjogJ251bWVyaWMnLFxuICAgICAgbW9udGg6ICdzaG9ydCcsXG4gICAgICBkYXk6ICdudW1lcmljJyxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIGNvbnNvbGUud2FybignTWV0YWRhdGEgaW5zcGVjdGlvbiBlbmNvdW50ZXJlZCBub24tY3JpdGljYWwgZXJyb3I6JywgZSk7XG4gIH1cblxuICByZXR1cm4gcmVzdWx0O1xufVxuIl19