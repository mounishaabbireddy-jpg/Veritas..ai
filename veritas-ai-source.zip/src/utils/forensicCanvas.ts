/**
* Generate an Error Level Analysis (ELA) canvas data URL.
* Resaves the image at a known quality level (e.g. 0.85) to a canvas,
* compares pixel-by-pixel luminance differences, and scales the difference.
*/
export async function generateELAMap(imageSource, scale = 18) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.crossOrigin = "anonymous";
		img.onload = () => {
			try {
				const canvas = document.createElement("canvas");
				canvas.width = Math.min(img.naturalWidth, 1200);
				const ratio = canvas.width / img.naturalWidth;
				canvas.height = Math.round(img.naturalHeight * ratio);
				const ctx = canvas.getContext("2d");
				if (!ctx) return reject(new Error("Canvas 2D context unavailable"));
				// Draw original
				ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
				const originalData = ctx.getImageData(0, 0, canvas.width, canvas.height);
				// Re-compress to JPEG at 85% quality
				const compressedDataUrl = canvas.toDataURL("image/jpeg", .85);
				const compressedImg = new Image();
				compressedImg.onload = () => {
					const compCanvas = document.createElement("canvas");
					compCanvas.width = canvas.width;
					compCanvas.height = canvas.height;
					const compCtx = compCanvas.getContext("2d");
					if (!compCtx) return reject(new Error("Canvas 2D context unavailable"));
					compCtx.drawImage(compressedImg, 0, 0);
					const compData = compCtx.getImageData(0, 0, canvas.width, canvas.height);
					// Create difference canvas
					const diffCanvas = document.createElement("canvas");
					diffCanvas.width = canvas.width;
					diffCanvas.height = canvas.height;
					const diffCtx = diffCanvas.getContext("2d");
					if (!diffCtx) return reject(new Error("Canvas 2D context unavailable"));
					const diffData = diffCtx.createImageData(canvas.width, canvas.height);
					const orig = originalData.data;
					const comp = compData.data;
					const diff = diffData.data;
					for (let i = 0; i < orig.length; i += 4) {
						const dr = Math.abs(orig[i] - comp[i]) * scale;
						const dg = Math.abs(orig[i + 1] - comp[i + 1]) * scale;
						const db = Math.abs(orig[i + 2] - comp[i + 2]) * scale;
						// Map difference into deep navy / electric cyan / magenta spectrum
						const maxDelta = Math.max(dr, dg, db);
						if (maxDelta > 160) {
							// High discrepancy hotspot (magenta / bright white)
							diff[i] = Math.min(255, dr * 1.2);
							diff[i + 1] = Math.min(255, dg * .4);
							diff[i + 2] = Math.min(255, db * 1.4);
						} else if (maxDelta > 60) {
							// Medium discrepancy (cyan / blue)
							diff[i] = Math.min(255, dr * .2);
							diff[i + 1] = Math.min(255, dg * 1.1);
							diff[i + 2] = Math.min(255, db * 1.5);
						} else {
							// Low discrepancy baseline
							diff[i] = Math.min(255, dr * .5);
							diff[i + 1] = Math.min(255, dg * .5);
							diff[i + 2] = Math.min(255, db * .8);
						}
						diff[i + 3] = 255;
					}
					diffCtx.putImageData(diffData, 0, 0);
					resolve(diffCanvas.toDataURL("image/png"));
				};
				compressedImg.onerror = reject;
				compressedImg.src = compressedDataUrl;
			} catch (err) {
				reject(err);
			}
		};
		img.onerror = reject;
		img.src = imageSource;
	});
}
/**
* Generate High-Pass Frequency / Edge Continuity Filter.
* Attenuates low frequencies, leaving high-frequency transitions and noise grain.
*/
export async function generateHighPassMap(imageSource) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.crossOrigin = "anonymous";
		img.onload = () => {
			try {
				const canvas = document.createElement("canvas");
				canvas.width = Math.min(img.naturalWidth, 1200);
				const ratio = canvas.width / img.naturalWidth;
				canvas.height = Math.round(img.naturalHeight * ratio);
				const ctx = canvas.getContext("2d");
				if (!ctx) return reject(new Error("Canvas 2D context unavailable"));
				ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
				const originalData = ctx.getImageData(0, 0, canvas.width, canvas.height);
				const width = canvas.width;
				const height = canvas.height;
				const src = originalData.data;
				const outCanvas = document.createElement("canvas");
				outCanvas.width = width;
				outCanvas.height = height;
				const outCtx = outCanvas.getContext("2d");
				if (!outCtx) return reject(new Error("Canvas 2D context unavailable"));
				const outData = outCtx.createImageData(width, height);
				const out = outData.data;
				// Laplacian 3x3 kernel:
				// [ 0, -1,  0]
				// [-1,  4, -1]
				// [ 0, -1,  0]
				for (let y = 1; y < height - 1; y++) {
					for (let x = 1; x < width - 1; x++) {
						const idx = (y * width + x) * 4;
						const top = ((y - 1) * width + x) * 4;
						const bottom = ((y + 1) * width + x) * 4;
						const left = (y * width + (x - 1)) * 4;
						const right = (y * width + (x + 1)) * 4;
						for (let c = 0; c < 3; c++) {
							const lap = 4 * src[idx + c] - src[top + c] - src[bottom + c] - src[left + c] - src[right + c];
							// Offset to mid-gray (128) + scaled edge
							const val = Math.min(255, Math.max(0, 128 + lap * 1.5));
							out[idx + c] = val;
						}
						out[idx + 3] = 255;
					}
				}
				outCtx.putImageData(outData, 0, 0);
				resolve(outCanvas.toDataURL("image/png"));
			} catch (err) {
				reject(err);
			}
		};
		img.onerror = reject;
		img.src = imageSource;
	});
}
/**
* Generate Luminance Gradient & Solarization view
*/
export async function generateLuminanceMap(imageSource) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.crossOrigin = "anonymous";
		img.onload = () => {
			try {
				const canvas = document.createElement("canvas");
				canvas.width = Math.min(img.naturalWidth, 1200);
				const ratio = canvas.width / img.naturalWidth;
				canvas.height = Math.round(img.naturalHeight * ratio);
				const ctx = canvas.getContext("2d");
				if (!ctx) return reject(new Error("Canvas 2D context unavailable"));
				ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
				const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
				const data = imgData.data;
				for (let i = 0; i < data.length; i += 4) {
					// Photometric luminance
					const lum = .299 * data[i] + .587 * data[i + 1] + .114 * data[i + 2];
					// Gradient pseudocolor (violet to cyan to white)
					data[i] = Math.min(255, (255 - lum) * .7 + lum * .2);
					data[i + 1] = Math.min(255, lum * .9);
					data[i + 2] = Math.min(255, lum * 1.3);
					data[i + 3] = 255;
				}
				ctx.putImageData(imgData, 0, 0);
				resolve(canvas.toDataURL("image/png"));
			} catch (err) {
				reject(err);
			}
		};
		img.onerror = reject;
		img.src = imageSource;
	});
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFhQSxPQUFPLGVBQWUsZUFDcEIsYUFDQSxRQUFnQixJQUNDO0NBQ2pCLE9BQU8sSUFBSSxTQUFTLFNBQVMsV0FBVztFQUN0QyxNQUFNLE1BQU0sSUFBSSxNQUFNO0VBQ3RCLElBQUksY0FBYztFQUNsQixJQUFJLGVBQWU7R0FDakIsSUFBSTtJQUNGLE1BQU0sU0FBUyxTQUFTLGNBQWMsUUFBUTtJQUM5QyxPQUFPLFFBQVEsS0FBSyxJQUFJLElBQUksY0FBYyxJQUFJO0lBQzlDLE1BQU0sUUFBUSxPQUFPLFFBQVEsSUFBSTtJQUNqQyxPQUFPLFNBQVMsS0FBSyxNQUFNLElBQUksZ0JBQWdCLEtBQUs7SUFFcEQsTUFBTSxNQUFNLE9BQU8sV0FBVyxJQUFJO0lBQ2xDLElBQUksQ0FBQyxLQUFLLE9BQU8sT0FBTyxJQUFJLE1BQU0sK0JBQStCLENBQUM7O0lBR2xFLElBQUksVUFBVSxLQUFLLEdBQUcsR0FBRyxPQUFPLE9BQU8sT0FBTyxNQUFNO0lBQ3BELE1BQU0sZUFBZSxJQUFJLGFBQWEsR0FBRyxHQUFHLE9BQU8sT0FBTyxPQUFPLE1BQU07O0lBR3ZFLE1BQU0sb0JBQW9CLE9BQU8sVUFBVSxjQUFjLEdBQUk7SUFDN0QsTUFBTSxnQkFBZ0IsSUFBSSxNQUFNO0lBQ2hDLGNBQWMsZUFBZTtLQUMzQixNQUFNLGFBQWEsU0FBUyxjQUFjLFFBQVE7S0FDbEQsV0FBVyxRQUFRLE9BQU87S0FDMUIsV0FBVyxTQUFTLE9BQU87S0FDM0IsTUFBTSxVQUFVLFdBQVcsV0FBVyxJQUFJO0tBQzFDLElBQUksQ0FBQyxTQUFTLE9BQU8sT0FBTyxJQUFJLE1BQU0sK0JBQStCLENBQUM7S0FFdEUsUUFBUSxVQUFVLGVBQWUsR0FBRyxDQUFDO0tBQ3JDLE1BQU0sV0FBVyxRQUFRLGFBQWEsR0FBRyxHQUFHLE9BQU8sT0FBTyxPQUFPLE1BQU07O0tBR3ZFLE1BQU0sYUFBYSxTQUFTLGNBQWMsUUFBUTtLQUNsRCxXQUFXLFFBQVEsT0FBTztLQUMxQixXQUFXLFNBQVMsT0FBTztLQUMzQixNQUFNLFVBQVUsV0FBVyxXQUFXLElBQUk7S0FDMUMsSUFBSSxDQUFDLFNBQVMsT0FBTyxPQUFPLElBQUksTUFBTSwrQkFBK0IsQ0FBQztLQUV0RSxNQUFNLFdBQVcsUUFBUSxnQkFBZ0IsT0FBTyxPQUFPLE9BQU8sTUFBTTtLQUNwRSxNQUFNLE9BQU8sYUFBYTtLQUMxQixNQUFNLE9BQU8sU0FBUztLQUN0QixNQUFNLE9BQU8sU0FBUztLQUV0QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQUssR0FBRztNQUN2QyxNQUFNLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSyxLQUFLLEVBQUUsSUFBSTtNQUN6QyxNQUFNLEtBQUssS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLEtBQUssSUFBSSxFQUFFLElBQUk7TUFDakQsTUFBTSxLQUFLLEtBQUssSUFBSSxLQUFLLElBQUksS0FBSyxLQUFLLElBQUksRUFBRSxJQUFJOztNQUdqRCxNQUFNLFdBQVcsS0FBSyxJQUFJLElBQUksSUFBSSxFQUFFO01BQ3BDLElBQUksV0FBVyxLQUFLOztPQUVsQixLQUFLLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSyxHQUFHO09BQ2hDLEtBQUssSUFBSSxLQUFLLEtBQUssSUFBSSxLQUFLLEtBQUssRUFBRztPQUNwQyxLQUFLLElBQUksS0FBSyxLQUFLLElBQUksS0FBSyxLQUFLLEdBQUc7TUFDdEMsT0FBTyxJQUFJLFdBQVcsSUFBSTs7T0FFeEIsS0FBSyxLQUFLLEtBQUssSUFBSSxLQUFLLEtBQUssRUFBRztPQUNoQyxLQUFLLElBQUksS0FBSyxLQUFLLElBQUksS0FBSyxLQUFLLEdBQUc7T0FDcEMsS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSyxHQUFHO01BQ3RDLE9BQU87O09BRUwsS0FBSyxLQUFLLEtBQUssSUFBSSxLQUFLLEtBQUssRUFBRztPQUNoQyxLQUFLLElBQUksS0FBSyxLQUFLLElBQUksS0FBSyxLQUFLLEVBQUc7T0FDcEMsS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSyxFQUFHO01BQ3RDO01BQ0EsS0FBSyxJQUFJLEtBQUs7S0FDaEI7S0FFQSxRQUFRLGFBQWEsVUFBVSxHQUFHLENBQUM7S0FDbkMsUUFBUSxXQUFXLFVBQVUsV0FBVyxDQUFDO0lBQzNDO0lBQ0EsY0FBYyxVQUFVO0lBQ3hCLGNBQWMsTUFBTTtHQUN0QixTQUFTLEtBQUs7SUFDWixPQUFPLEdBQUc7R0FDWjtFQUNGO0VBQ0EsSUFBSSxVQUFVO0VBQ2QsSUFBSSxNQUFNO0NBQ1osQ0FBQztBQUNIOzs7OztBQU1BLE9BQU8sZUFBZSxvQkFBb0IsYUFBc0M7Q0FDOUUsT0FBTyxJQUFJLFNBQVMsU0FBUyxXQUFXO0VBQ3RDLE1BQU0sTUFBTSxJQUFJLE1BQU07RUFDdEIsSUFBSSxjQUFjO0VBQ2xCLElBQUksZUFBZTtHQUNqQixJQUFJO0lBQ0YsTUFBTSxTQUFTLFNBQVMsY0FBYyxRQUFRO0lBQzlDLE9BQU8sUUFBUSxLQUFLLElBQUksSUFBSSxjQUFjLElBQUk7SUFDOUMsTUFBTSxRQUFRLE9BQU8sUUFBUSxJQUFJO0lBQ2pDLE9BQU8sU0FBUyxLQUFLLE1BQU0sSUFBSSxnQkFBZ0IsS0FBSztJQUVwRCxNQUFNLE1BQU0sT0FBTyxXQUFXLElBQUk7SUFDbEMsSUFBSSxDQUFDLEtBQUssT0FBTyxPQUFPLElBQUksTUFBTSwrQkFBK0IsQ0FBQztJQUVsRSxJQUFJLFVBQVUsS0FBSyxHQUFHLEdBQUcsT0FBTyxPQUFPLE9BQU8sTUFBTTtJQUNwRCxNQUFNLGVBQWUsSUFBSSxhQUFhLEdBQUcsR0FBRyxPQUFPLE9BQU8sT0FBTyxNQUFNO0lBQ3ZFLE1BQU0sUUFBUSxPQUFPO0lBQ3JCLE1BQU0sU0FBUyxPQUFPO0lBQ3RCLE1BQU0sTUFBTSxhQUFhO0lBRXpCLE1BQU0sWUFBWSxTQUFTLGNBQWMsUUFBUTtJQUNqRCxVQUFVLFFBQVE7SUFDbEIsVUFBVSxTQUFTO0lBQ25CLE1BQU0sU0FBUyxVQUFVLFdBQVcsSUFBSTtJQUN4QyxJQUFJLENBQUMsUUFBUSxPQUFPLE9BQU8sSUFBSSxNQUFNLCtCQUErQixDQUFDO0lBRXJFLE1BQU0sVUFBVSxPQUFPLGdCQUFnQixPQUFPLE1BQU07SUFDcEQsTUFBTSxNQUFNLFFBQVE7Ozs7O0lBTXBCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLEdBQUcsS0FBSztLQUNuQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxHQUFHLEtBQUs7TUFDbEMsTUFBTSxPQUFPLElBQUksUUFBUSxLQUFLO01BQzlCLE1BQU0sUUFBUSxJQUFJLEtBQUssUUFBUSxLQUFLO01BQ3BDLE1BQU0sV0FBVyxJQUFJLEtBQUssUUFBUSxLQUFLO01BQ3ZDLE1BQU0sUUFBUSxJQUFJLFNBQVMsSUFBSSxNQUFNO01BQ3JDLE1BQU0sU0FBUyxJQUFJLFNBQVMsSUFBSSxNQUFNO01BRXRDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7T0FDMUIsTUFBTSxNQUFNLElBQUksSUFBSSxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSSxTQUFTLEtBQUssSUFBSSxPQUFPLEtBQUssSUFBSSxRQUFROztPQUU1RixNQUFNLE1BQU0sS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJLEdBQUcsTUFBTSxNQUFNLEdBQUcsQ0FBQztPQUN0RCxJQUFJLE1BQU0sS0FBSztNQUNqQjtNQUNBLElBQUksTUFBTSxLQUFLO0tBQ2pCO0lBQ0Y7SUFFQSxPQUFPLGFBQWEsU0FBUyxHQUFHLENBQUM7SUFDakMsUUFBUSxVQUFVLFVBQVUsV0FBVyxDQUFDO0dBQzFDLFNBQVMsS0FBSztJQUNaLE9BQU8sR0FBRztHQUNaO0VBQ0Y7RUFDQSxJQUFJLFVBQVU7RUFDZCxJQUFJLE1BQU07Q0FDWixDQUFDO0FBQ0g7Ozs7QUFLQSxPQUFPLGVBQWUscUJBQXFCLGFBQXNDO0NBQy9FLE9BQU8sSUFBSSxTQUFTLFNBQVMsV0FBVztFQUN0QyxNQUFNLE1BQU0sSUFBSSxNQUFNO0VBQ3RCLElBQUksY0FBYztFQUNsQixJQUFJLGVBQWU7R0FDakIsSUFBSTtJQUNGLE1BQU0sU0FBUyxTQUFTLGNBQWMsUUFBUTtJQUM5QyxPQUFPLFFBQVEsS0FBSyxJQUFJLElBQUksY0FBYyxJQUFJO0lBQzlDLE1BQU0sUUFBUSxPQUFPLFFBQVEsSUFBSTtJQUNqQyxPQUFPLFNBQVMsS0FBSyxNQUFNLElBQUksZ0JBQWdCLEtBQUs7SUFFcEQsTUFBTSxNQUFNLE9BQU8sV0FBVyxJQUFJO0lBQ2xDLElBQUksQ0FBQyxLQUFLLE9BQU8sT0FBTyxJQUFJLE1BQU0sK0JBQStCLENBQUM7SUFFbEUsSUFBSSxVQUFVLEtBQUssR0FBRyxHQUFHLE9BQU8sT0FBTyxPQUFPLE1BQU07SUFDcEQsTUFBTSxVQUFVLElBQUksYUFBYSxHQUFHLEdBQUcsT0FBTyxPQUFPLE9BQU8sTUFBTTtJQUNsRSxNQUFNLE9BQU8sUUFBUTtJQUVyQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQUssR0FBRzs7S0FFdkMsTUFBTSxNQUFNLE9BQVEsS0FBSyxLQUFLLE9BQVEsS0FBSyxJQUFJLEtBQUssT0FBUSxLQUFLLElBQUk7O0tBRXJFLEtBQUssS0FBSyxLQUFLLElBQUksTUFBTSxNQUFNLE9BQU8sS0FBTSxNQUFNLEVBQUc7S0FDckQsS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJLEtBQUssTUFBTSxFQUFHO0tBQ3JDLEtBQUssSUFBSSxLQUFLLEtBQUssSUFBSSxLQUFLLE1BQU0sR0FBRztLQUNyQyxLQUFLLElBQUksS0FBSztJQUNoQjtJQUVBLElBQUksYUFBYSxTQUFTLEdBQUcsQ0FBQztJQUM5QixRQUFRLE9BQU8sVUFBVSxXQUFXLENBQUM7R0FDdkMsU0FBUyxLQUFLO0lBQ1osT0FBTyxHQUFHO0dBQ1o7RUFDRjtFQUNBLElBQUksVUFBVTtFQUNkLElBQUksTUFBTTtDQUNaLENBQUM7QUFDSCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJmb3JlbnNpY0NhbnZhcy50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEZvcmVuc2ljIENhbnZhcyBUb29sczpcbiAqIEltcGxlbWVudHMgY2xpZW50LXNpZGUgRXJyb3IgTGV2ZWwgQW5hbHlzaXMgKEVMQSksXG4gKiBIaWdoLVBhc3MgRnJlcXVlbmN5IEZpbHRlcmluZywgYW5kIEx1bWluYW5jZSBEaXN0cmlidXRpb24uXG4gKi9cblxuZXhwb3J0IHR5cGUgRm9yZW5zaWNGaWx0ZXJNb2RlID0gJ29yaWdpbmFsJyB8ICdlbGEnIHwgJ2hpZ2hwYXNzJyB8ICdsdW1pbmFuY2UnO1xuXG4vKipcbiAqIEdlbmVyYXRlIGFuIEVycm9yIExldmVsIEFuYWx5c2lzIChFTEEpIGNhbnZhcyBkYXRhIFVSTC5cbiAqIFJlc2F2ZXMgdGhlIGltYWdlIGF0IGEga25vd24gcXVhbGl0eSBsZXZlbCAoZS5nLiAwLjg1KSB0byBhIGNhbnZhcyxcbiAqIGNvbXBhcmVzIHBpeGVsLWJ5LXBpeGVsIGx1bWluYW5jZSBkaWZmZXJlbmNlcywgYW5kIHNjYWxlcyB0aGUgZGlmZmVyZW5jZS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlRUxBTWFwKFxuICBpbWFnZVNvdXJjZTogc3RyaW5nLFxuICBzY2FsZTogbnVtYmVyID0gMThcbik6IFByb21pc2U8c3RyaW5nPiB7XG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgY29uc3QgaW1nID0gbmV3IEltYWdlKCk7XG4gICAgaW1nLmNyb3NzT3JpZ2luID0gJ2Fub255bW91cyc7XG4gICAgaW1nLm9ubG9hZCA9ICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xuICAgICAgICBjYW52YXMud2lkdGggPSBNYXRoLm1pbihpbWcubmF0dXJhbFdpZHRoLCAxMjAwKTtcbiAgICAgICAgY29uc3QgcmF0aW8gPSBjYW52YXMud2lkdGggLyBpbWcubmF0dXJhbFdpZHRoO1xuICAgICAgICBjYW52YXMuaGVpZ2h0ID0gTWF0aC5yb3VuZChpbWcubmF0dXJhbEhlaWdodCAqIHJhdGlvKTtcblxuICAgICAgICBjb25zdCBjdHggPSBjYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcbiAgICAgICAgaWYgKCFjdHgpIHJldHVybiByZWplY3QobmV3IEVycm9yKCdDYW52YXMgMkQgY29udGV4dCB1bmF2YWlsYWJsZScpKTtcblxuICAgICAgICAvLyBEcmF3IG9yaWdpbmFsXG4gICAgICAgIGN0eC5kcmF3SW1hZ2UoaW1nLCAwLCAwLCBjYW52YXMud2lkdGgsIGNhbnZhcy5oZWlnaHQpO1xuICAgICAgICBjb25zdCBvcmlnaW5hbERhdGEgPSBjdHguZ2V0SW1hZ2VEYXRhKDAsIDAsIGNhbnZhcy53aWR0aCwgY2FudmFzLmhlaWdodCk7XG5cbiAgICAgICAgLy8gUmUtY29tcHJlc3MgdG8gSlBFRyBhdCA4NSUgcXVhbGl0eVxuICAgICAgICBjb25zdCBjb21wcmVzc2VkRGF0YVVybCA9IGNhbnZhcy50b0RhdGFVUkwoJ2ltYWdlL2pwZWcnLCAwLjg1KTtcbiAgICAgICAgY29uc3QgY29tcHJlc3NlZEltZyA9IG5ldyBJbWFnZSgpO1xuICAgICAgICBjb21wcmVzc2VkSW1nLm9ubG9hZCA9ICgpID0+IHtcbiAgICAgICAgICBjb25zdCBjb21wQ2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnY2FudmFzJyk7XG4gICAgICAgICAgY29tcENhbnZhcy53aWR0aCA9IGNhbnZhcy53aWR0aDtcbiAgICAgICAgICBjb21wQ2FudmFzLmhlaWdodCA9IGNhbnZhcy5oZWlnaHQ7XG4gICAgICAgICAgY29uc3QgY29tcEN0eCA9IGNvbXBDYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcbiAgICAgICAgICBpZiAoIWNvbXBDdHgpIHJldHVybiByZWplY3QobmV3IEVycm9yKCdDYW52YXMgMkQgY29udGV4dCB1bmF2YWlsYWJsZScpKTtcblxuICAgICAgICAgIGNvbXBDdHguZHJhd0ltYWdlKGNvbXByZXNzZWRJbWcsIDAsIDApO1xuICAgICAgICAgIGNvbnN0IGNvbXBEYXRhID0gY29tcEN0eC5nZXRJbWFnZURhdGEoMCwgMCwgY2FudmFzLndpZHRoLCBjYW52YXMuaGVpZ2h0KTtcblxuICAgICAgICAgIC8vIENyZWF0ZSBkaWZmZXJlbmNlIGNhbnZhc1xuICAgICAgICAgIGNvbnN0IGRpZmZDYW52YXMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdjYW52YXMnKTtcbiAgICAgICAgICBkaWZmQ2FudmFzLndpZHRoID0gY2FudmFzLndpZHRoO1xuICAgICAgICAgIGRpZmZDYW52YXMuaGVpZ2h0ID0gY2FudmFzLmhlaWdodDtcbiAgICAgICAgICBjb25zdCBkaWZmQ3R4ID0gZGlmZkNhbnZhcy5nZXRDb250ZXh0KCcyZCcpO1xuICAgICAgICAgIGlmICghZGlmZkN0eCkgcmV0dXJuIHJlamVjdChuZXcgRXJyb3IoJ0NhbnZhcyAyRCBjb250ZXh0IHVuYXZhaWxhYmxlJykpO1xuXG4gICAgICAgICAgY29uc3QgZGlmZkRhdGEgPSBkaWZmQ3R4LmNyZWF0ZUltYWdlRGF0YShjYW52YXMud2lkdGgsIGNhbnZhcy5oZWlnaHQpO1xuICAgICAgICAgIGNvbnN0IG9yaWcgPSBvcmlnaW5hbERhdGEuZGF0YTtcbiAgICAgICAgICBjb25zdCBjb21wID0gY29tcERhdGEuZGF0YTtcbiAgICAgICAgICBjb25zdCBkaWZmID0gZGlmZkRhdGEuZGF0YTtcblxuICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgb3JpZy5sZW5ndGg7IGkgKz0gNCkge1xuICAgICAgICAgICAgY29uc3QgZHIgPSBNYXRoLmFicyhvcmlnW2ldIC0gY29tcFtpXSkgKiBzY2FsZTtcbiAgICAgICAgICAgIGNvbnN0IGRnID0gTWF0aC5hYnMob3JpZ1tpICsgMV0gLSBjb21wW2kgKyAxXSkgKiBzY2FsZTtcbiAgICAgICAgICAgIGNvbnN0IGRiID0gTWF0aC5hYnMob3JpZ1tpICsgMl0gLSBjb21wW2kgKyAyXSkgKiBzY2FsZTtcblxuICAgICAgICAgICAgLy8gTWFwIGRpZmZlcmVuY2UgaW50byBkZWVwIG5hdnkgLyBlbGVjdHJpYyBjeWFuIC8gbWFnZW50YSBzcGVjdHJ1bVxuICAgICAgICAgICAgY29uc3QgbWF4RGVsdGEgPSBNYXRoLm1heChkciwgZGcsIGRiKTtcbiAgICAgICAgICAgIGlmIChtYXhEZWx0YSA+IDE2MCkge1xuICAgICAgICAgICAgICAvLyBIaWdoIGRpc2NyZXBhbmN5IGhvdHNwb3QgKG1hZ2VudGEgLyBicmlnaHQgd2hpdGUpXG4gICAgICAgICAgICAgIGRpZmZbaV0gPSBNYXRoLm1pbigyNTUsIGRyICogMS4yKTtcbiAgICAgICAgICAgICAgZGlmZltpICsgMV0gPSBNYXRoLm1pbigyNTUsIGRnICogMC40KTtcbiAgICAgICAgICAgICAgZGlmZltpICsgMl0gPSBNYXRoLm1pbigyNTUsIGRiICogMS40KTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAobWF4RGVsdGEgPiA2MCkge1xuICAgICAgICAgICAgICAvLyBNZWRpdW0gZGlzY3JlcGFuY3kgKGN5YW4gLyBibHVlKVxuICAgICAgICAgICAgICBkaWZmW2ldID0gTWF0aC5taW4oMjU1LCBkciAqIDAuMik7XG4gICAgICAgICAgICAgIGRpZmZbaSArIDFdID0gTWF0aC5taW4oMjU1LCBkZyAqIDEuMSk7XG4gICAgICAgICAgICAgIGRpZmZbaSArIDJdID0gTWF0aC5taW4oMjU1LCBkYiAqIDEuNSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAvLyBMb3cgZGlzY3JlcGFuY3kgYmFzZWxpbmVcbiAgICAgICAgICAgICAgZGlmZltpXSA9IE1hdGgubWluKDI1NSwgZHIgKiAwLjUpO1xuICAgICAgICAgICAgICBkaWZmW2kgKyAxXSA9IE1hdGgubWluKDI1NSwgZGcgKiAwLjUpO1xuICAgICAgICAgICAgICBkaWZmW2kgKyAyXSA9IE1hdGgubWluKDI1NSwgZGIgKiAwLjgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZGlmZltpICsgM10gPSAyNTU7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgZGlmZkN0eC5wdXRJbWFnZURhdGEoZGlmZkRhdGEsIDAsIDApO1xuICAgICAgICAgIHJlc29sdmUoZGlmZkNhbnZhcy50b0RhdGFVUkwoJ2ltYWdlL3BuZycpKTtcbiAgICAgICAgfTtcbiAgICAgICAgY29tcHJlc3NlZEltZy5vbmVycm9yID0gcmVqZWN0O1xuICAgICAgICBjb21wcmVzc2VkSW1nLnNyYyA9IGNvbXByZXNzZWREYXRhVXJsO1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgfVxuICAgIH07XG4gICAgaW1nLm9uZXJyb3IgPSByZWplY3Q7XG4gICAgaW1nLnNyYyA9IGltYWdlU291cmNlO1xuICB9KTtcbn1cblxuLyoqXG4gKiBHZW5lcmF0ZSBIaWdoLVBhc3MgRnJlcXVlbmN5IC8gRWRnZSBDb250aW51aXR5IEZpbHRlci5cbiAqIEF0dGVudWF0ZXMgbG93IGZyZXF1ZW5jaWVzLCBsZWF2aW5nIGhpZ2gtZnJlcXVlbmN5IHRyYW5zaXRpb25zIGFuZCBub2lzZSBncmFpbi5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlSGlnaFBhc3NNYXAoaW1hZ2VTb3VyY2U6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgY29uc3QgaW1nID0gbmV3IEltYWdlKCk7XG4gICAgaW1nLmNyb3NzT3JpZ2luID0gJ2Fub255bW91cyc7XG4gICAgaW1nLm9ubG9hZCA9ICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xuICAgICAgICBjYW52YXMud2lkdGggPSBNYXRoLm1pbihpbWcubmF0dXJhbFdpZHRoLCAxMjAwKTtcbiAgICAgICAgY29uc3QgcmF0aW8gPSBjYW52YXMud2lkdGggLyBpbWcubmF0dXJhbFdpZHRoO1xuICAgICAgICBjYW52YXMuaGVpZ2h0ID0gTWF0aC5yb3VuZChpbWcubmF0dXJhbEhlaWdodCAqIHJhdGlvKTtcblxuICAgICAgICBjb25zdCBjdHggPSBjYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcbiAgICAgICAgaWYgKCFjdHgpIHJldHVybiByZWplY3QobmV3IEVycm9yKCdDYW52YXMgMkQgY29udGV4dCB1bmF2YWlsYWJsZScpKTtcblxuICAgICAgICBjdHguZHJhd0ltYWdlKGltZywgMCwgMCwgY2FudmFzLndpZHRoLCBjYW52YXMuaGVpZ2h0KTtcbiAgICAgICAgY29uc3Qgb3JpZ2luYWxEYXRhID0gY3R4LmdldEltYWdlRGF0YSgwLCAwLCBjYW52YXMud2lkdGgsIGNhbnZhcy5oZWlnaHQpO1xuICAgICAgICBjb25zdCB3aWR0aCA9IGNhbnZhcy53aWR0aDtcbiAgICAgICAgY29uc3QgaGVpZ2h0ID0gY2FudmFzLmhlaWdodDtcbiAgICAgICAgY29uc3Qgc3JjID0gb3JpZ2luYWxEYXRhLmRhdGE7XG5cbiAgICAgICAgY29uc3Qgb3V0Q2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnY2FudmFzJyk7XG4gICAgICAgIG91dENhbnZhcy53aWR0aCA9IHdpZHRoO1xuICAgICAgICBvdXRDYW52YXMuaGVpZ2h0ID0gaGVpZ2h0O1xuICAgICAgICBjb25zdCBvdXRDdHggPSBvdXRDYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcbiAgICAgICAgaWYgKCFvdXRDdHgpIHJldHVybiByZWplY3QobmV3IEVycm9yKCdDYW52YXMgMkQgY29udGV4dCB1bmF2YWlsYWJsZScpKTtcblxuICAgICAgICBjb25zdCBvdXREYXRhID0gb3V0Q3R4LmNyZWF0ZUltYWdlRGF0YSh3aWR0aCwgaGVpZ2h0KTtcbiAgICAgICAgY29uc3Qgb3V0ID0gb3V0RGF0YS5kYXRhO1xuXG4gICAgICAgIC8vIExhcGxhY2lhbiAzeDMga2VybmVsOlxuICAgICAgICAvLyBbIDAsIC0xLCAgMF1cbiAgICAgICAgLy8gWy0xLCAgNCwgLTFdXG4gICAgICAgIC8vIFsgMCwgLTEsICAwXVxuICAgICAgICBmb3IgKGxldCB5ID0gMTsgeSA8IGhlaWdodCAtIDE7IHkrKykge1xuICAgICAgICAgIGZvciAobGV0IHggPSAxOyB4IDwgd2lkdGggLSAxOyB4KyspIHtcbiAgICAgICAgICAgIGNvbnN0IGlkeCA9ICh5ICogd2lkdGggKyB4KSAqIDQ7XG4gICAgICAgICAgICBjb25zdCB0b3AgPSAoKHkgLSAxKSAqIHdpZHRoICsgeCkgKiA0O1xuICAgICAgICAgICAgY29uc3QgYm90dG9tID0gKCh5ICsgMSkgKiB3aWR0aCArIHgpICogNDtcbiAgICAgICAgICAgIGNvbnN0IGxlZnQgPSAoeSAqIHdpZHRoICsgKHggLSAxKSkgKiA0O1xuICAgICAgICAgICAgY29uc3QgcmlnaHQgPSAoeSAqIHdpZHRoICsgKHggKyAxKSkgKiA0O1xuXG4gICAgICAgICAgICBmb3IgKGxldCBjID0gMDsgYyA8IDM7IGMrKykge1xuICAgICAgICAgICAgICBjb25zdCBsYXAgPSA0ICogc3JjW2lkeCArIGNdIC0gc3JjW3RvcCArIGNdIC0gc3JjW2JvdHRvbSArIGNdIC0gc3JjW2xlZnQgKyBjXSAtIHNyY1tyaWdodCArIGNdO1xuICAgICAgICAgICAgICAvLyBPZmZzZXQgdG8gbWlkLWdyYXkgKDEyOCkgKyBzY2FsZWQgZWRnZVxuICAgICAgICAgICAgICBjb25zdCB2YWwgPSBNYXRoLm1pbigyNTUsIE1hdGgubWF4KDAsIDEyOCArIGxhcCAqIDEuNSkpO1xuICAgICAgICAgICAgICBvdXRbaWR4ICsgY10gPSB2YWw7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvdXRbaWR4ICsgM10gPSAyNTU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgb3V0Q3R4LnB1dEltYWdlRGF0YShvdXREYXRhLCAwLCAwKTtcbiAgICAgICAgcmVzb2x2ZShvdXRDYW52YXMudG9EYXRhVVJMKCdpbWFnZS9wbmcnKSk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICB9XG4gICAgfTtcbiAgICBpbWcub25lcnJvciA9IHJlamVjdDtcbiAgICBpbWcuc3JjID0gaW1hZ2VTb3VyY2U7XG4gIH0pO1xufVxuXG4vKipcbiAqIEdlbmVyYXRlIEx1bWluYW5jZSBHcmFkaWVudCAmIFNvbGFyaXphdGlvbiB2aWV3XG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZW5lcmF0ZUx1bWluYW5jZU1hcChpbWFnZVNvdXJjZTogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICBjb25zdCBpbWcgPSBuZXcgSW1hZ2UoKTtcbiAgICBpbWcuY3Jvc3NPcmlnaW4gPSAnYW5vbnltb3VzJztcbiAgICBpbWcub25sb2FkID0gKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnY2FudmFzJyk7XG4gICAgICAgIGNhbnZhcy53aWR0aCA9IE1hdGgubWluKGltZy5uYXR1cmFsV2lkdGgsIDEyMDApO1xuICAgICAgICBjb25zdCByYXRpbyA9IGNhbnZhcy53aWR0aCAvIGltZy5uYXR1cmFsV2lkdGg7XG4gICAgICAgIGNhbnZhcy5oZWlnaHQgPSBNYXRoLnJvdW5kKGltZy5uYXR1cmFsSGVpZ2h0ICogcmF0aW8pO1xuXG4gICAgICAgIGNvbnN0IGN0eCA9IGNhbnZhcy5nZXRDb250ZXh0KCcyZCcpO1xuICAgICAgICBpZiAoIWN0eCkgcmV0dXJuIHJlamVjdChuZXcgRXJyb3IoJ0NhbnZhcyAyRCBjb250ZXh0IHVuYXZhaWxhYmxlJykpO1xuXG4gICAgICAgIGN0eC5kcmF3SW1hZ2UoaW1nLCAwLCAwLCBjYW52YXMud2lkdGgsIGNhbnZhcy5oZWlnaHQpO1xuICAgICAgICBjb25zdCBpbWdEYXRhID0gY3R4LmdldEltYWdlRGF0YSgwLCAwLCBjYW52YXMud2lkdGgsIGNhbnZhcy5oZWlnaHQpO1xuICAgICAgICBjb25zdCBkYXRhID0gaW1nRGF0YS5kYXRhO1xuXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7IGkgKz0gNCkge1xuICAgICAgICAgIC8vIFBob3RvbWV0cmljIGx1bWluYW5jZVxuICAgICAgICAgIGNvbnN0IGx1bSA9IDAuMjk5ICogZGF0YVtpXSArIDAuNTg3ICogZGF0YVtpICsgMV0gKyAwLjExNCAqIGRhdGFbaSArIDJdO1xuICAgICAgICAgIC8vIEdyYWRpZW50IHBzZXVkb2NvbG9yICh2aW9sZXQgdG8gY3lhbiB0byB3aGl0ZSlcbiAgICAgICAgICBkYXRhW2ldID0gTWF0aC5taW4oMjU1LCAoMjU1IC0gbHVtKSAqIDAuNyArIGx1bSAqIDAuMik7IC8vIFJlZFxuICAgICAgICAgIGRhdGFbaSArIDFdID0gTWF0aC5taW4oMjU1LCBsdW0gKiAwLjkpOyAgICAgICAgICAgICAgICAgIC8vIEdyZWVuXG4gICAgICAgICAgZGF0YVtpICsgMl0gPSBNYXRoLm1pbigyNTUsIGx1bSAqIDEuMyk7ICAgICAgICAgICAgICAgICAgLy8gQmx1ZVxuICAgICAgICAgIGRhdGFbaSArIDNdID0gMjU1O1xuICAgICAgICB9XG5cbiAgICAgICAgY3R4LnB1dEltYWdlRGF0YShpbWdEYXRhLCAwLCAwKTtcbiAgICAgICAgcmVzb2x2ZShjYW52YXMudG9EYXRhVVJMKCdpbWFnZS9wbmcnKSk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICB9XG4gICAgfTtcbiAgICBpbWcub25lcnJvciA9IHJlamVjdDtcbiAgICBpbWcuc3JjID0gaW1hZ2VTb3VyY2U7XG4gIH0pO1xufVxuIl19