const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4c5f34d3";
import { X, Globe, Copy, Check, Download, FileArchive, Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=4c5f34d3";
import { downloadProjectZip } from "/src/utils/projectDownloader.ts";
var _jsxFileName = "/app/applet/src/components/MobilePublishModal.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4c5f34d3";
export const MobilePublishModal = ({ isOpen, onClose }) => {
	const [copiedUrl, setCopiedUrl] = useState(false);
	const [isDownloading, setIsDownloading] = useState(false);
	const [downloadStatus, setDownloadStatus] = useState("");
	if (!isOpen) return null;
	// Real Applet URLs from runtime environment
	const sharedUrl = "https://ais-pre-hduufdxkwtwwfq3hpahshn-511732575964.asia-east1.run.app";
	const handleCopy = () => {
		navigator.clipboard.writeText(sharedUrl);
		setCopiedUrl(true);
		setTimeout(() => setCopiedUrl(false), 2200);
	};
	const handleDownloadZip = async () => {
		try {
			setIsDownloading(true);
			await downloadProjectZip((status) => setDownloadStatus(status));
		} catch (e) {
			console.error("Download error:", e);
		} finally {
			setIsDownloading(false);
			setDownloadStatus("");
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "relative w-full max-w-xl rounded-2xl border border-cyan-500/30 bg-[#060a18] p-6 sm:p-8 shadow-2xl text-slate-100 overflow-hidden max-h-[90vh] overflow-y-auto",
			children: [
				/* @__PURE__ */ _jsxDEV("div", { className: "absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onClose,
					className: "absolute top-5 right-5 p-2 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] text-slate-400 hover:text-white transition-colors",
					"aria-label": "Close modal",
					children: /* @__PURE__ */ _jsxDEV(X, { className: "h-5 w-5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3 mb-6",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400",
						children: /* @__PURE__ */ _jsxDEV(Download, { className: "h-5 w-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 56,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "text-xl font-bold text-white",
						children: "Download Files & GitHub Upload"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-400 font-mono",
						children: "VERITAS AI Source Package (.ZIP)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-6",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-4 rounded-xl bg-gradient-to-r from-cyan-950/50 via-slate-900 to-violet-950/40 border border-cyan-500/30 space-y-3",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between text-xs font-mono",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-cyan-300 uppercase tracking-wider flex items-center gap-1.5 font-bold",
										children: [/* @__PURE__ */ _jsxDEV(FileArchive, { className: "h-4 w-4 text-cyan-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 76,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Complete Project Archive" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 77,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 75,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-emerald-400 text-[11px] font-semibold bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20",
										children: "Ready to Upload"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 79,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 74,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-300 leading-relaxed",
									children: "Contains all source code (React 19, TypeScript, Express backend, forensic canvas modules, styles, and configs)."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 84,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: handleDownloadZip,
									disabled: isDownloading,
									className: "w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-bold text-xs uppercase tracking-wider text-black bg-gradient-to-r from-cyan-400 via-cyan-300 to-teal-300 hover:from-cyan-300 hover:to-white shadow-[0_0_20px_rgba(6,182,212,0.3)] transition-all cursor-pointer disabled:opacity-50",
									children: [isDownloading ? /* @__PURE__ */ _jsxDEV(Loader2, { className: "h-4 w-4 animate-spin" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 94,
										columnNumber: 17
									}, this) : /* @__PURE__ */ _jsxDEV(Download, { className: "h-4 w-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 96,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: isDownloading ? downloadStatus || "Packing ZIP..." : "Download veritas-ai-source.zip" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 98,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 88,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 73,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-4 rounded-xl bg-white/[0.03] border border-white/[0.08] space-y-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between text-xs font-mono",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-cyan-400 uppercase tracking-wider flex items-center gap-1.5 font-semibold",
									children: [/* @__PURE__ */ _jsxDEV(Globe, { className: "h-3.5 w-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 106,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Your Public Live URL" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 107,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 105,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-emerald-400 text-[11px] font-medium bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20",
									children: "Live & Accessible Everywhere"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 109,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 104,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 p-2.5 rounded-lg bg-black/60 border border-white/[0.08]",
								children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									readOnly: true,
									value: sharedUrl,
									className: "flex-1 bg-transparent text-xs font-mono text-cyan-200 outline-none truncate selection:bg-cyan-500/30"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 115,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleCopy,
									className: "flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-xs font-mono text-cyan-300 transition-colors shrink-0 cursor-pointer",
									children: [copiedUrl ? /* @__PURE__ */ _jsxDEV(Check, { className: "h-3.5 w-3.5 text-emerald-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 125,
										columnNumber: 30
									}, this) : /* @__PURE__ */ _jsxDEV(Copy, { className: "h-3.5 w-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 125,
										columnNumber: 83
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: copiedUrl ? "Copied" : "Copy" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 126,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 121,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 114,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3 text-xs",
							children: [/* @__PURE__ */ _jsxDEV("h4", {
								className: "font-semibold text-white uppercase font-mono text-[11px] tracking-wider text-slate-300",
								children: "3 Easy Steps to Use from Your Mobile Phone:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 133,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-2.5",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 rounded-lg bg-white/[0.02] border border-white/[0.06] flex items-start gap-3",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-cyan-500/20 text-cyan-300 font-mono text-[10px] font-bold",
											children: "1"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 139,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", {
											className: "text-white",
											children: "Open the Link on Mobile:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 143,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-slate-400 mt-0.5",
											children: "Send or copy the URL above to your phone via WhatsApp, Gmail, or Messages. Open it in Chrome or Safari."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 144,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 142,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 138,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 rounded-lg bg-white/[0.02] border border-white/[0.06] flex items-start gap-3",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-cyan-500/20 text-cyan-300 font-mono text-[10px] font-bold",
											children: "2"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 151,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", {
											className: "text-white",
											children: "Add to Home Screen (PWA):"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 155,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-slate-400 mt-0.5",
											children: [
												"On iOS Safari: Tap the ",
												/* @__PURE__ */ _jsxDEV("strong", { children: "Share" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 157,
													columnNumber: 44
												}, this),
												" button → choose ",
												/* @__PURE__ */ _jsxDEV("strong", { children: "\"Add to Home Screen\"" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 157,
													columnNumber: 88
												}, this),
												".",
												/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 158,
													columnNumber: 21
												}, this),
												"On Android Chrome: Tap the ",
												/* @__PURE__ */ _jsxDEV("strong", { children: "three dots" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 159,
													columnNumber: 48
												}, this),
												" menu → select ",
												/* @__PURE__ */ _jsxDEV("strong", { children: "\"Install app\"" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 159,
													columnNumber: 95
												}, this),
												" or ",
												/* @__PURE__ */ _jsxDEV("strong", { children: "\"Add to Home screen\"" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 159,
													columnNumber: 129
												}, this),
												"."
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 156,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 154,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 150,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 rounded-lg bg-white/[0.02] border border-white/[0.06] flex items-start gap-3",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-cyan-500/20 text-cyan-300 font-mono text-[10px] font-bold",
											children: "3"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 165,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", {
											className: "text-white",
											children: "Permanent Custom Domain (GitHub / Vercel / Netlify):"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 169,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-slate-400 mt-0.5",
											children: [
												"In AI Studio Build, tap ",
												/* @__PURE__ */ _jsxDEV("strong", { children: "\"Export to GitHub\"" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 171,
													columnNumber: 45
												}, this),
												". On your phone or laptop, link the GitHub repository to Vercel or Cloudflare Pages for a custom ",
												/* @__PURE__ */ _jsxDEV("code", {
													className: "text-cyan-300",
													children: "veritas.yourname.com"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 171,
													columnNumber: 177
												}, this),
												" domain with 1 click."
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 170,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 168,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 164,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 137,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 132,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "pt-2 flex justify-end",
							children: /* @__PURE__ */ _jsxDEV("button", {
								onClick: onClose,
								className: "px-5 py-2.5 text-xs font-semibold text-black bg-cyan-400 hover:bg-cyan-300 rounded-xl transition-colors cursor-pointer",
								children: "Got It"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 180,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 179,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 39,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLEdBQWUsT0FBTyxNQUFNLE9BQWlELFVBQVUsYUFBYSxlQUFlO0FBQzVILFNBQVMsMEJBQTBCOzs7QUFPbkMsT0FBTyxNQUFNLHNCQUF5RCxFQUFFLFFBQVEsY0FBYztDQUM1RixNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxLQUFLO0NBQ2hELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLEtBQUs7Q0FDeEQsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxFQUFFO0NBRXZELElBQUksQ0FBQyxRQUFRLE9BQU87O0NBR3BCLE1BQU0sWUFBWTtDQUVsQixNQUFNLG1CQUFtQjtFQUN2QixVQUFVLFVBQVUsVUFBVSxTQUFTO0VBQ3ZDLGFBQWEsSUFBSTtFQUNqQixpQkFBaUIsYUFBYSxLQUFLLEdBQUcsSUFBSTtDQUM1QztDQUVBLE1BQU0sb0JBQW9CLFlBQVk7RUFDcEMsSUFBSTtHQUNGLGlCQUFpQixJQUFJO0dBQ3JCLE1BQU0sb0JBQW9CLFdBQVcsa0JBQWtCLE1BQU0sQ0FBQztFQUNoRSxTQUFTLEdBQUc7R0FDVixRQUFRLE1BQU0sbUJBQW1CLENBQUM7RUFDcEMsVUFBVTtHQUNSLGlCQUFpQixLQUFLO0dBQ3RCLGtCQUFrQixFQUFFO0VBQ3RCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUdFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLDRGQUE2Rjs7Ozs7SUFHNUcsd0JBQUMsVUFBRDtLQUNFLFNBQVM7S0FDVCxXQUFVO0tBQ1YsY0FBVztlQUVYLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O0lBQ2xCOzs7OztJQUdSLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7OztLQUM1Qjs7OztlQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBK0I7S0FFekM7Ozs7ZUFDSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBbUM7S0FFN0M7Ozs7YUFDQTs7OzthQUNGOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BR0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLHdCQUF5Qjs7OztvQkFDaEQsd0JBQUMsUUFBRCxZQUFNLDJCQUE4Qjs7OztrQkFDaEM7Ozs7O21CQUNOLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFnSDtTQUUxSDs7OztpQkFDSDs7Ozs7O1FBRUwsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQXlDO1FBRW5EOzs7OztRQUVILHdCQUFDLFVBQUQ7U0FDRSxTQUFTO1NBQ1QsVUFBVTtTQUNWLFdBQVU7bUJBSFosQ0FLRyxnQkFDQyx3QkFBQyxTQUFELEVBQVMsV0FBVSx1QkFBd0I7Ozs7b0JBRTNDLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFVBQVc7Ozs7bUJBRWpDLHdCQUFDLFFBQUQsWUFBTyxnQkFBZ0Isa0JBQWtCLG1CQUFtQixpQ0FBdUM7Ozs7aUJBQzdGOzs7Ozs7T0FDTDs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLGNBQWU7Ozs7bUJBQ2hDLHdCQUFDLFFBQUQsWUFBTSx1QkFBMEI7Ozs7aUJBQzVCOzs7OztrQkFDTix3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBOEc7UUFFeEg7Ozs7Z0JBQ0g7Ozs7O2lCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTDtTQUNBLE9BQU87U0FDUCxXQUFVO1FBQ1g7Ozs7a0JBQ0Qsd0JBQUMsVUFBRDtTQUNFLFNBQVM7U0FDVCxXQUFVO21CQUZaLENBSUcsWUFBWSx3QkFBQyxPQUFELEVBQU8sV0FBVSwrQkFBZ0M7Ozs7b0JBQUksd0JBQUMsTUFBRCxFQUFNLFdBQVUsY0FBZTs7OzttQkFDakcsd0JBQUMsUUFBRCxZQUFPLFlBQVksV0FBVyxPQUFhOzs7O2lCQUNyQzs7Ozs7Z0JBQ0w7Ozs7O2VBQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQXlGO09BRW5HOzs7O2lCQUVKLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBOEg7VUFFeEk7Ozs7b0JBQ04sd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFVBQUQ7V0FBUSxXQUFVO3FCQUFhO1VBQWdDOzs7O29CQUMvRCx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBd0I7VUFFbEM7Ozs7a0JBQ0E7Ozs7a0JBQ0Y7Ozs7OztTQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQThIO1VBRXhJOzs7O29CQUNOLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxVQUFEO1dBQVEsV0FBVTtxQkFBYTtVQUFpQzs7OztvQkFDaEUsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQWI7WUFBcUM7WUFDWix3QkFBQyxVQUFELFlBQVEsUUFBYTs7Ozs7WUFBQztZQUFzQix3QkFBQyxVQUFELFlBQVEseUJBQTRCOzs7OztZQUFDO1lBQ3hHLHdCQUFDLE1BQUQsQ0FBSzs7Ozs7WUFBQztZQUNxQix3QkFBQyxVQUFELFlBQVEsYUFBa0I7Ozs7O1lBQUM7WUFBb0Isd0JBQUMsVUFBRCxZQUFRLGtCQUFxQjs7Ozs7WUFBQztZQUFJLHdCQUFDLFVBQUQsWUFBUSx5QkFBNEI7Ozs7O1lBQUM7V0FDaEo7Ozs7O2tCQUNBOzs7O2tCQUNGOzs7Ozs7U0FFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUE4SDtVQUV4STs7OztvQkFDTix3QkFBQyxPQUFELGFBQ0Usd0JBQUMsVUFBRDtXQUFRLFdBQVU7cUJBQWE7VUFBNEQ7Ozs7b0JBQzNGLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFiO1lBQXFDO1lBQ1gsd0JBQUMsVUFBRCxZQUFRLHVCQUEwQjs7Ozs7WUFBQztZQUFpRyx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBZ0I7WUFBMEI7Ozs7O1lBQUM7V0FDdE47Ozs7O2tCQUNBOzs7O2tCQUNGOzs7Ozs7UUFDRjs7Ozs7ZUFDRjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsVUFBRDtRQUNFLFNBQVM7UUFDVCxXQUFVO2tCQUNYO09BRU87Ozs7O01BQ0w7Ozs7O0tBRUY7Ozs7OztHQUVGOzs7Ozs7Q0FDRjs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJNb2JpbGVQdWJsaXNoTW9kYWwudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFgsIFNtYXJ0cGhvbmUsIEdsb2JlLCBDb3B5LCBDaGVjaywgUXJDb2RlLCBTaGFyZTIsIEV4dGVybmFsTGluaywgQXJyb3dSaWdodCwgRG93bmxvYWQsIEZpbGVBcmNoaXZlLCBMb2FkZXIyIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IGRvd25sb2FkUHJvamVjdFppcCB9IGZyb20gJy4uL3V0aWxzL3Byb2plY3REb3dubG9hZGVyJztcblxuaW50ZXJmYWNlIE1vYmlsZVB1Ymxpc2hNb2RhbFByb3BzIHtcbiAgaXNPcGVuOiBib29sZWFuO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgTW9iaWxlUHVibGlzaE1vZGFsOiBSZWFjdC5GQzxNb2JpbGVQdWJsaXNoTW9kYWxQcm9wcz4gPSAoeyBpc09wZW4sIG9uQ2xvc2UgfSkgPT4ge1xuICBjb25zdCBbY29waWVkVXJsLCBzZXRDb3BpZWRVcmxdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbaXNEb3dubG9hZGluZywgc2V0SXNEb3dubG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtkb3dubG9hZFN0YXR1cywgc2V0RG93bmxvYWRTdGF0dXNdID0gdXNlU3RhdGUoJycpO1xuXG4gIGlmICghaXNPcGVuKSByZXR1cm4gbnVsbDtcblxuICAvLyBSZWFsIEFwcGxldCBVUkxzIGZyb20gcnVudGltZSBlbnZpcm9ubWVudFxuICBjb25zdCBzaGFyZWRVcmwgPSAnaHR0cHM6Ly9haXMtcHJlLWhkdXVmZHhrd3R3d2ZxM2hwYWhzaG4tNTExNzMyNTc1OTY0LmFzaWEtZWFzdDEucnVuLmFwcCc7XG5cbiAgY29uc3QgaGFuZGxlQ29weSA9ICgpID0+IHtcbiAgICBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dChzaGFyZWRVcmwpO1xuICAgIHNldENvcGllZFVybCh0cnVlKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldENvcGllZFVybChmYWxzZSksIDIyMDApO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZURvd25sb2FkWmlwID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBzZXRJc0Rvd25sb2FkaW5nKHRydWUpO1xuICAgICAgYXdhaXQgZG93bmxvYWRQcm9qZWN0WmlwKChzdGF0dXMpID0+IHNldERvd25sb2FkU3RhdHVzKHN0YXR1cykpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Rvd25sb2FkIGVycm9yOicsIGUpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc0Rvd25sb2FkaW5nKGZhbHNlKTtcbiAgICAgIHNldERvd25sb2FkU3RhdHVzKCcnKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgYmctYmxhY2svODAgYmFja2Ryb3AtYmx1ci1tZCBhbmltYXRlLWluIGZhZGUtaW4gZHVyYXRpb24tMjAwXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBtYXgtdy14bCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWN5YW4tNTAwLzMwIGJnLVsjMDYwYTE4XSBwLTYgc206cC04IHNoYWRvdy0yeGwgdGV4dC1zbGF0ZS0xMDAgb3ZlcmZsb3ctaGlkZGVuIG1heC1oLVs5MHZoXSBvdmVyZmxvdy15LWF1dG9cIj5cbiAgICAgICAgXG4gICAgICAgIHsvKiBHbG93IGFtYmllbnQgYmFja2dyb3VuZCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMCByaWdodC0wIHctNjQgaC02NCBiZy1jeWFuLTUwMC8xMCByb3VuZGVkLWZ1bGwgYmx1ci0zeGwgcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG5cbiAgICAgICAgey8qIENsb3NlIEJ1dHRvbiAqL31cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTUgcmlnaHQtNSBwLTIgcm91bmRlZC1sZyBiZy13aGl0ZS9bMC4wNV0gaG92ZXI6Ymctd2hpdGUvWzAuMV0gdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgYXJpYS1sYWJlbD1cIkNsb3NlIG1vZGFsXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxYIGNsYXNzTmFtZT1cImgtNSB3LTVcIiAvPlxuICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICB7LyogTW9kYWwgSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC0xMCB3LTEwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXhsIGJnLWN5YW4tNTAwLzEwIGJvcmRlciBib3JkZXItY3lhbi01MDAvMzAgdGV4dC1jeWFuLTQwMFwiPlxuICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cImgtNSB3LTVcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICBEb3dubG9hZCBGaWxlcyAmIEdpdEh1YiBVcGxvYWRcbiAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICBWRVJJVEFTIEFJIFNvdXJjZSBQYWNrYWdlICguWklQKVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQ29udGVudCBUYWJzIC8gU3RlcHMgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgXG4gICAgICAgICAgey8qIERpcmVjdCBaSVAgRG93bmxvYWQgQm94ICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLWN5YW4tOTUwLzUwIHZpYS1zbGF0ZS05MDAgdG8tdmlvbGV0LTk1MC80MCBib3JkZXIgYm9yZGVyLWN5YW4tNTAwLzMwIHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1jeWFuLTMwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICA8RmlsZUFyY2hpdmUgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWN5YW4tNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5Db21wbGV0ZSBQcm9qZWN0IEFyY2hpdmU8L3NwYW4+XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTQwMCB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIGJnLWVtZXJhbGQtNTAwLzEwIHB4LTIgcHktMC41IHJvdW5kZWQgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8yMFwiPlxuICAgICAgICAgICAgICAgIFJlYWR5IHRvIFVwbG9hZFxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTMwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgQ29udGFpbnMgYWxsIHNvdXJjZSBjb2RlIChSZWFjdCAxOSwgVHlwZVNjcmlwdCwgRXhwcmVzcyBiYWNrZW5kLCBmb3JlbnNpYyBjYW52YXMgbW9kdWxlcywgc3R5bGVzLCBhbmQgY29uZmlncykuXG4gICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRG93bmxvYWRaaXB9XG4gICAgICAgICAgICAgIGRpc2FibGVkPXtpc0Rvd25sb2FkaW5nfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcHktMyBweC00IHJvdW5kZWQteGwgZm9udC1ib2xkIHRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtYmxhY2sgYmctZ3JhZGllbnQtdG8tciBmcm9tLWN5YW4tNDAwIHZpYS1jeWFuLTMwMCB0by10ZWFsLTMwMCBob3Zlcjpmcm9tLWN5YW4tMzAwIGhvdmVyOnRvLXdoaXRlIHNoYWRvdy1bMF8wXzIwcHhfcmdiYSg2LDE4MiwyMTIsMC4zKV0gdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtpc0Rvd25sb2FkaW5nID8gKFxuICAgICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cImgtNCB3LTQgYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDxzcGFuPntpc0Rvd25sb2FkaW5nID8gZG93bmxvYWRTdGF0dXMgfHwgJ1BhY2tpbmcgWklQLi4uJyA6ICdEb3dubG9hZCB2ZXJpdGFzLWFpLXNvdXJjZS56aXAnfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIFxuICAgICAgICAgIHsvKiBTZWN0aW9uIDE6IEluc3RhbnQgTW9iaWxlIExpdmUgVVJMICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYmctd2hpdGUvWzAuMDNdIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMDhdIHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1jeWFuLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgPEdsb2JlIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5Zb3VyIFB1YmxpYyBMaXZlIFVSTDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNDAwIHRleHQtWzExcHhdIGZvbnQtbWVkaXVtIGJnLWVtZXJhbGQtNTAwLzEwIHB4LTIgcHktMC41IHJvdW5kZWQgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8yMFwiPlxuICAgICAgICAgICAgICAgIExpdmUgJiBBY2Nlc3NpYmxlIEV2ZXJ5d2hlcmVcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcC0yLjUgcm91bmRlZC1sZyBiZy1ibGFjay82MCBib3JkZXIgYm9yZGVyLXdoaXRlL1swLjA4XVwiPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgcmVhZE9ubHlcbiAgICAgICAgICAgICAgICB2YWx1ZT17c2hhcmVkVXJsfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBiZy10cmFuc3BhcmVudCB0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LWN5YW4tMjAwIG91dGxpbmUtbm9uZSB0cnVuY2F0ZSBzZWxlY3Rpb246YmctY3lhbi01MDAvMzBcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ29weX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IHJvdW5kZWQtbWQgYmctY3lhbi01MDAvMjAgaG92ZXI6YmctY3lhbi01MDAvMzAgYm9yZGVyIGJvcmRlci1jeWFuLTUwMC80MCB0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LWN5YW4tMzAwIHRyYW5zaXRpb24tY29sb3JzIHNocmluay0wIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtjb3BpZWRVcmwgPyA8Q2hlY2sgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgdGV4dC1lbWVyYWxkLTQwMFwiIC8+IDogPENvcHkgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPn1cbiAgICAgICAgICAgICAgICA8c3Bhbj57Y29waWVkVXJsID8gJ0NvcGllZCcgOiAnQ29weSd9PC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFNlY3Rpb24gMjogSG93IHRvIG9wZW4gYW5kIHRlc3Qgb24gcGhvbmUgcmlnaHQgbm93ICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zIHRleHQteHNcIj5cbiAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtd2hpdGUgdXBwZXJjYXNlIGZvbnQtbW9ubyB0ZXh0LVsxMXB4XSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAzIEVhc3kgU3RlcHMgdG8gVXNlIGZyb20gWW91ciBNb2JpbGUgUGhvbmU6XG4gICAgICAgICAgICA8L2g0PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMi41XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQtbGcgYmctd2hpdGUvWzAuMDJdIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMDZdIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGgtNSB3LTUgc2hyaW5rLTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy1jeWFuLTUwMC8yMCB0ZXh0LWN5YW4tMzAwIGZvbnQtbW9ubyB0ZXh0LVsxMHB4XSBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC13aGl0ZVwiPk9wZW4gdGhlIExpbmsgb24gTW9iaWxlOjwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgIFNlbmQgb3IgY29weSB0aGUgVVJMIGFib3ZlIHRvIHlvdXIgcGhvbmUgdmlhIFdoYXRzQXBwLCBHbWFpbCwgb3IgTWVzc2FnZXMuIE9wZW4gaXQgaW4gQ2hyb21lIG9yIFNhZmFyaS5cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC1sZyBiZy13aGl0ZS9bMC4wMl0gYm9yZGVyIGJvcmRlci13aGl0ZS9bMC4wNl0gZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaC01IHctNSBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLWN5YW4tNTAwLzIwIHRleHQtY3lhbi0zMDAgZm9udC1tb25vIHRleHQtWzEwcHhdIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgMlxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlXCI+QWRkIHRvIEhvbWUgU2NyZWVuIChQV0EpOjwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgIE9uIGlPUyBTYWZhcmk6IFRhcCB0aGUgPHN0cm9uZz5TaGFyZTwvc3Ryb25nPiBidXR0b24gJnJhcnI7IGNob29zZSA8c3Ryb25nPlwiQWRkIHRvIEhvbWUgU2NyZWVuXCI8L3N0cm9uZz4uXG4gICAgICAgICAgICAgICAgICAgIDxiciAvPlxuICAgICAgICAgICAgICAgICAgICBPbiBBbmRyb2lkIENocm9tZTogVGFwIHRoZSA8c3Ryb25nPnRocmVlIGRvdHM8L3N0cm9uZz4gbWVudSAmcmFycjsgc2VsZWN0IDxzdHJvbmc+XCJJbnN0YWxsIGFwcFwiPC9zdHJvbmc+IG9yIDxzdHJvbmc+XCJBZGQgdG8gSG9tZSBzY3JlZW5cIjwvc3Ryb25nPi5cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC1sZyBiZy13aGl0ZS9bMC4wMl0gYm9yZGVyIGJvcmRlci13aGl0ZS9bMC4wNl0gZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaC01IHctNSBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLWN5YW4tNTAwLzIwIHRleHQtY3lhbi0zMDAgZm9udC1tb25vIHRleHQtWzEwcHhdIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgM1xuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlXCI+UGVybWFuZW50IEN1c3RvbSBEb21haW4gKEdpdEh1YiAvIFZlcmNlbCAvIE5ldGxpZnkpOjwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgIEluIEFJIFN0dWRpbyBCdWlsZCwgdGFwIDxzdHJvbmc+XCJFeHBvcnQgdG8gR2l0SHViXCI8L3N0cm9uZz4uIE9uIHlvdXIgcGhvbmUgb3IgbGFwdG9wLCBsaW5rIHRoZSBHaXRIdWIgcmVwb3NpdG9yeSB0byBWZXJjZWwgb3IgQ2xvdWRmbGFyZSBQYWdlcyBmb3IgYSBjdXN0b20gPGNvZGUgY2xhc3NOYW1lPVwidGV4dC1jeWFuLTMwMFwiPnZlcml0YXMueW91cm5hbWUuY29tPC9jb2RlPiBkb21haW4gd2l0aCAxIGNsaWNrLlxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEFjdGlvbiBidXR0b24gKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIGZsZXgganVzdGlmeS1lbmRcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgYmctY3lhbi00MDAgaG92ZXI6YmctY3lhbi0zMDAgcm91bmRlZC14bCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIEdvdCBJdFxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==