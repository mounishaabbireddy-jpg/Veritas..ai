const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4c5f34d3";
import { ShieldAlert, ShieldCheck, HelpCircle, Download, RotateCcw, Layers, FileCode, Info, ChevronDown, ChevronUp, Activity, Share2, AlertCircle, SlidersHorizontal } from "/node_modules/.vite/deps/lucide-react.js?v=4c5f34d3";
var _jsxFileName = "/app/applet/src/components/ResultsDashboard.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4c5f34d3";
export const ResultsDashboard = ({ result, previewUrl, elaUrl, highpassUrl, luminanceUrl, onAnalyzeAnother }) => {
	const [filterMode, setFilterMode] = useState("original");
	const [expandedIndicator, setExpandedIndicator] = useState(result.indicators[0]?.id || null);
	const [copiedNotification, setCopiedNotification] = useState(false);
	const [comparisonSplit, setComparisonSplit] = useState(50);
	const [isSplitActive, setIsSplitActive] = useState(false);
	// Determine current active preview image based on filter mode
	const currentVisualSource = filterMode === "ela" && elaUrl ? elaUrl : filterMode === "highpass" && highpassUrl ? highpassUrl : filterMode === "luminance" && luminanceUrl ? luminanceUrl : previewUrl;
	// Category visual styles
	const getCategoryTheme = () => {
		switch (result.assessment) {
			case "Likely AI-generated": return {
				badgeBg: "bg-rose-500/15 border-rose-500/40 text-rose-300",
				dotBg: "bg-rose-500 shadow-[0_0_12px_#f43f5e]",
				icon: /* @__PURE__ */ _jsxDEV(ShieldAlert, { className: "h-6 w-6 text-rose-400" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 17
				}, this),
				headline: "Synthetic Media Signals Detected",
				cardBorder: "border-rose-500/30",
				gaugeColor: "#f43f5e",
				accentColor: "text-rose-400"
			};
			case "Likely authentic": return {
				badgeBg: "bg-emerald-500/15 border-emerald-500/40 text-emerald-300",
				dotBg: "bg-emerald-500 shadow-[0_0_12px_#10b981]",
				icon: /* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "h-6 w-6 text-emerald-400" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 78,
					columnNumber: 17
				}, this),
				headline: "Optical Hardware Consistency Confirmed",
				cardBorder: "border-emerald-500/30",
				gaugeColor: "#10b981",
				accentColor: "text-emerald-400"
			};
			case "Inconclusive":
			default: return {
				badgeBg: "bg-amber-500/15 border-amber-500/40 text-amber-300",
				dotBg: "bg-amber-500 shadow-[0_0_12px_#f59e0b]",
				icon: /* @__PURE__ */ _jsxDEV(HelpCircle, { className: "h-6 w-6 text-amber-400" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 89,
					columnNumber: 17
				}, this),
				headline: "Ambiguous Forensic Profile",
				cardBorder: "border-amber-500/30",
				gaugeColor: "#f59e0b",
				accentColor: "text-amber-400"
			};
		}
	};
	const theme = getCategoryTheme();
	const handleExportJSON = () => {
		const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(result, null, 2));
		const downloadAnchor = document.createElement("a");
		downloadAnchor.setAttribute("href", dataStr);
		downloadAnchor.setAttribute("download", `VERITAS_Report_${result.fileName.replace(/\.[^/.]+$/, "")}.json`);
		document.body.appendChild(downloadAnchor);
		downloadAnchor.click();
		downloadAnchor.remove();
	};
	const handleCopyReport = () => {
		const reportText = `[VERITAS AI FORENSIC REPORT]
File: ${result.fileName} (${(result.fileSize / 1024).toFixed(1)} KB)
Assessment: ${result.assessment}
Confidence: ${result.confidenceScore}% (±${result.uncertaintyMargin}%)
Scan Duration: ${result.analysisDurationSeconds}s
Engine: ${result.engineName}
Timestamp: ${result.timestamp}

Verdict Rationale:
${result.verdictRationale}

Key Indicators:
${result.indicators.map((i) => `- [${i.severity.toUpperCase()}] ${i.name}: ${i.title} (${i.confidence}% confidence)`).join("\n")}

Uncertainty Disclosure:
${result.engineDisclaimer}`;
		navigator.clipboard.writeText(reportText);
		setCopiedNotification(true);
		setTimeout(() => setCopiedNotification(false), 2400);
	};
	// SVG Gauge calculations
	const radius = 38;
	const circumference = 2 * Math.PI * radius;
	const strokeDashoffset = circumference - result.confidenceScore / 100 * circumference;
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "results-dashboard",
		className: "relative scroll-mt-20 py-20 px-6 lg:px-8 border-t border-white/[0.08] bg-[#030614]",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "mx-auto max-w-6xl space-y-8",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: `rounded-3xl border ${theme.cardBorder} bg-[#060a1d]/95 backdrop-blur-2xl p-6 sm:p-9 shadow-2xl relative overflow-hidden`,
				children: [
					/* @__PURE__ */ _jsxDEV("div", { className: "absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-[100px] pointer-events-none" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 146,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3.5 max-w-2xl",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: `inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-mono font-bold tracking-wider uppercase border ${theme.badgeBg}`,
										children: [/* @__PURE__ */ _jsxDEV("span", { className: `w-2.5 h-2.5 rounded-full ${theme.dotBg}` }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 152,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: result.assessment }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 153,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 151,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs text-slate-400 font-mono",
										children: ["Scan ID: ", result.id]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 155,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 150,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("h2", {
									className: "text-2xl sm:text-3xl font-extrabold text-white tracking-tight [text-wrap:balance]",
									children: theme.headline
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 160,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm text-slate-300 leading-relaxed",
									children: result.summary
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 164,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-6 p-5 rounded-2xl bg-white/[0.03] border border-white/[0.08] shrink-0 w-full sm:w-auto justify-between sm:justify-start",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "relative flex items-center justify-center w-24 h-24",
									children: [/* @__PURE__ */ _jsxDEV("svg", {
										className: "w-24 h-24 -rotate-90",
										children: [/* @__PURE__ */ _jsxDEV("circle", {
											cx: "48",
											cy: "48",
											r: radius,
											stroke: "rgba(255, 255, 255, 0.08)",
											strokeWidth: "8",
											fill: "transparent"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 175,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("circle", {
											cx: "48",
											cy: "48",
											r: radius,
											stroke: theme.gaugeColor,
											strokeWidth: "8",
											strokeDasharray: circumference,
											strokeDashoffset,
											strokeLinecap: "round",
											fill: "transparent",
											className: "transition-all duration-1000 ease-out"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 183,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 174,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "absolute flex flex-col items-center justify-center text-center",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xl font-extrabold text-white font-mono tabular-nums leading-none",
											children: [result.confidenceScore, "%"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 197,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[9px] font-mono text-slate-400 mt-1",
											children: [
												"±",
												result.uncertaintyMargin,
												"%"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 200,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 196,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 173,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { className: "h-14 w-[1px] bg-white/[0.1]" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 206,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] font-mono uppercase tracking-wider text-slate-400",
											children: "Inspection Status"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 209,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-sm font-bold text-cyan-400 font-mono",
											children: "VERIFIED"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 212,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-xs text-slate-400 font-mono tabular-nums",
											children: [result.analysisDurationSeconds, "s scan duration"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 215,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-[11px] text-slate-500 font-mono",
											children: [result.indicators.length, " vectors audited"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 218,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 208,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 170,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 148,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-7 pt-4 border-t border-white/[0.08] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-slate-400",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Info, { className: "h-4 w-4 text-cyan-400 shrink-0" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 228,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: result.engineDisclaimer }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 229,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 227,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "font-mono text-[11px] text-slate-500 shrink-0",
							children: result.engineName
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 231,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 226,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 143,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-8 items-start",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-7 space-y-5",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "rounded-3xl border border-white/[0.08] bg-[#050816] p-6 backdrop-blur-2xl shadow-xl",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between mb-4 flex-wrap gap-2",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV(Layers, { className: "h-4 w-4 text-cyan-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 246,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-mono uppercase tracking-wider text-slate-200 font-semibold",
										children: "Forensic Visual Inspection"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 247,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 245,
									columnNumber: 17
								}, this), result.fileType === "image" && /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-1 p-1 bg-white/[0.04] rounded-xl border border-white/[0.06] overflow-x-auto",
									children: [
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => {
												setFilterMode("original");
												setIsSplitActive(false);
											},
											className: `px-3 py-1 text-[11px] font-semibold rounded-lg transition-colors cursor-pointer ${filterMode === "original" && !isSplitActive ? "bg-cyan-500/25 text-cyan-300 border border-cyan-500/40 shadow-sm" : "text-slate-400 hover:text-white"}`,
											children: "Original"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 255,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => {
												setFilterMode("ela");
												setIsSplitActive(false);
											},
											className: `px-3 py-1 text-[11px] font-semibold rounded-lg transition-colors cursor-pointer ${filterMode === "ela" && !isSplitActive ? "bg-cyan-500/25 text-cyan-300 border border-cyan-500/40 shadow-sm" : "text-slate-400 hover:text-white"}`,
											children: "ELA Heatmap"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 268,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => {
												setFilterMode("highpass");
												setIsSplitActive(false);
											},
											className: `px-3 py-1 text-[11px] font-semibold rounded-lg transition-colors cursor-pointer ${filterMode === "highpass" && !isSplitActive ? "bg-cyan-500/25 text-cyan-300 border border-cyan-500/40 shadow-sm" : "text-slate-400 hover:text-white"}`,
											children: "High-Pass Edge"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 281,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => {
												setFilterMode("luminance");
												setIsSplitActive(false);
											},
											className: `px-3 py-1 text-[11px] font-semibold rounded-lg transition-colors cursor-pointer ${filterMode === "luminance" && !isSplitActive ? "bg-cyan-500/25 text-cyan-300 border border-cyan-500/40 shadow-sm" : "text-slate-400 hover:text-white"}`,
											children: "Luminance"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 294,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setIsSplitActive(!isSplitActive),
											className: `px-3 py-1 text-[11px] font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-1 ${isSplitActive ? "bg-violet-500/30 text-violet-200 border border-violet-500/40 shadow-sm" : "text-slate-400 hover:text-white"}`,
											children: [/* @__PURE__ */ _jsxDEV(SlidersHorizontal, { className: "h-3 w-3" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 315,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Split Wipe" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 316,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 307,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 254,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 244,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "relative rounded-2xl border border-white/[0.1] bg-black/80 overflow-hidden flex items-center justify-center min-h-[380px] max-h-[520px]",
								children: [result.fileType === "image" ? isSplitActive && (elaUrl || highpassUrl) ? /* @__PURE__ */ _jsxDEV("div", {
									className: "relative w-full h-full min-h-[440px] flex items-center justify-center overflow-hidden",
									children: [
										/* @__PURE__ */ _jsxDEV("img", {
											src: previewUrl,
											alt: "Original",
											className: "max-h-[460px] max-w-full object-contain p-2"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 328,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute inset-0 flex items-center justify-center overflow-hidden",
											style: { clipPath: `polygon(${comparisonSplit}% 0, 100% 0, 100% 100%, ${comparisonSplit}% 100%)` },
											children: /* @__PURE__ */ _jsxDEV("img", {
												src: elaUrl || currentVisualSource,
												alt: "Forensic ELA",
												className: "max-h-[460px] max-w-full object-contain p-2"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 339,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 335,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute top-0 bottom-0 w-0.5 bg-cyan-400 shadow-[0_0_15px_#22d3ee] pointer-events-none z-20",
											style: { left: `${comparisonSplit}%` }
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 347,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											type: "range",
											min: "5",
											max: "95",
											value: comparisonSplit,
											onChange: (e) => setComparisonSplit(Number(e.target.value)),
											className: "absolute inset-x-0 bottom-8 h-8 opacity-0 cursor-ew-resize z-40",
											"aria-label": "Adjust split comparison"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 352,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 326,
									columnNumber: 21
								}, this) : /* @__PURE__ */ _jsxDEV("img", {
									src: currentVisualSource,
									alt: "Forensic layer view",
									className: "max-h-[460px] max-w-full object-contain p-2"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 363,
									columnNumber: 21
								}, this) : /* @__PURE__ */ _jsxDEV("video", {
									src: previewUrl,
									controls: true,
									className: "max-h-[460px] max-w-full object-contain"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 370,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "absolute bottom-3 left-3 text-[10px] font-mono px-3 py-1 rounded-lg bg-black/80 border border-white/15 text-cyan-300 backdrop-blur-md uppercase tracking-wider",
									children: ["Mode: ", isSplitActive ? "Split Wipe (Original / ELA)" : filterMode]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 378,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 323,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "mt-3.5 text-xs text-slate-400 leading-normal",
								children: [
									filterMode === "original" && !isSplitActive && "Standard source media rendering at native color-space.",
									filterMode === "ela" && !isSplitActive && "Error Level Analysis (ELA) highlights compression disparities. Regions saved at differing quality levels fluoresce as bright cyan/magenta contours.",
									filterMode === "highpass" && !isSplitActive && "High-pass filter isolates micro-edge gradients and sensor noise grain, exposing blurred generative transitions.",
									filterMode === "luminance" && !isSplitActive && "Pseudocolor luminance false-color mapping reveals unnatural lighting falloff gradients and specular discontinuities.",
									isSplitActive && "Split wipe mode: Drag horizontally across the image to evaluate differences between original photo and the ELA compression matrix."
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 384,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 242,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "rounded-3xl border border-white/[0.08] bg-[#050816] p-6 backdrop-blur-2xl shadow-xl",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between mb-4",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-mono uppercase tracking-wider text-slate-300 flex items-center gap-2 font-semibold",
								children: [/* @__PURE__ */ _jsxDEV(FileCode, { className: "h-4 w-4 text-cyan-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 397,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Metadata & Container Telemetry" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 398,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 396,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: `text-[10px] font-mono px-2.5 py-1 rounded-md font-semibold ${result.metadata.hasExif ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30" : "bg-slate-800 text-slate-400 border border-slate-700"}`,
								children: result.metadata.hasExif ? "EXIF Intact" : "No Hardware EXIF"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 400,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 395,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 sm:grid-cols-3 gap-3.5 text-xs font-mono pt-1",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "text-[10px] text-slate-500 uppercase",
										children: "Camera Make"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 407,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-white font-semibold truncate mt-1",
										children: result.metadata.cameraMake || "N/A (Synthetic)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 408,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 406,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "text-[10px] text-slate-500 uppercase",
										children: "Camera Model"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 412,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-white font-semibold truncate mt-1",
										children: result.metadata.cameraModel || "N/A"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 413,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 411,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "text-[10px] text-slate-500 uppercase",
										children: "Exposure / ISO"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 417,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-white font-semibold truncate mt-1",
										children: result.metadata.iso ? `ISO ${result.metadata.iso} · ${result.metadata.fNumber || ""}` : "None Recorded"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 418,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 416,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "text-[10px] text-slate-500 uppercase",
										children: "Dimensions"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 424,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-white font-semibold mt-1 tabular-nums",
										children: [
											result.metadata.dimensions.width,
											" × ",
											result.metadata.dimensions.height
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 425,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 423,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "text-[10px] text-slate-500 uppercase",
										children: "C2PA Manifest"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 431,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: `font-semibold mt-1 ${result.metadata.c2paPresent ? "text-emerald-400" : "text-slate-400"}`,
										children: result.metadata.c2paPresent ? "Cryptographically Signed" : "Not Present"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 432,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 430,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "text-[10px] text-slate-500 uppercase",
										children: "Software Tag"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 438,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-white font-semibold truncate mt-1",
										title: result.metadata.software || "None",
										children: result.metadata.software || "Standard Buffer"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 439,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 437,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 405,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 394,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 241,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-5 space-y-5",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "rounded-3xl border border-white/[0.08] bg-[#050816] p-6 backdrop-blur-2xl shadow-xl",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between mb-5",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-mono uppercase tracking-wider text-slate-200 flex items-center gap-2 font-semibold",
									children: [/* @__PURE__ */ _jsxDEV(Activity, { className: "h-4 w-4 text-cyan-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 454,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Potential Synthetic Indicators" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 455,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 453,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-slate-400 font-mono",
									children: [result.indicators.length, " vectors"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 457,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 452,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3.5",
								children: result.indicators.map((ind) => {
									const isExpanded = expandedIndicator === ind.id;
									const severityBadge = ind.severity === "high" ? "text-rose-400 bg-rose-500/10 border-rose-500/30" : ind.severity === "medium" ? "text-amber-400 bg-amber-500/10 border-amber-500/30" : "text-emerald-400 bg-emerald-500/10 border-emerald-500/30";
									return /* @__PURE__ */ _jsxDEV("div", {
										className: "rounded-2xl border border-white/[0.06] bg-white/[0.02] hover:bg-white/[0.04] transition-all overflow-hidden",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setExpandedIndicator(isExpanded ? null : ind.id),
											className: "w-full flex items-center justify-between p-4 text-left cursor-pointer",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "space-y-1.5 pr-3",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: `text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-md border uppercase ${severityBadge}`,
														children: ind.severity
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 484,
														columnNumber: 29
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "text-xs font-mono text-slate-400 uppercase",
														children: ind.category
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 487,
														columnNumber: 29
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 483,
													columnNumber: 27
												}, this), /* @__PURE__ */ _jsxDEV("h4", {
													className: "text-sm font-bold text-white",
													children: ind.title
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 491,
													columnNumber: 27
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 482,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2 shrink-0",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs font-mono font-bold text-cyan-400 tabular-nums",
													children: [ind.confidence, "%"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 497,
													columnNumber: 27
												}, this), isExpanded ? /* @__PURE__ */ _jsxDEV(ChevronUp, { className: "h-4 w-4 text-slate-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 501,
													columnNumber: 29
												}, this) : /* @__PURE__ */ _jsxDEV(ChevronDown, { className: "h-4 w-4 text-slate-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 503,
													columnNumber: 29
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 496,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 478,
											columnNumber: 23
										}, this), isExpanded && /* @__PURE__ */ _jsxDEV("div", {
											className: "px-4 pb-4 pt-1 border-t border-white/[0.04] space-y-3 text-xs",
											children: [/* @__PURE__ */ _jsxDEV("p", {
												className: "text-slate-300 leading-relaxed",
												children: ind.description
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 510,
												columnNumber: 27
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "p-3 rounded-xl bg-black/60 border border-white/[0.06] text-cyan-300 font-mono text-[11px] leading-relaxed",
												children: [/* @__PURE__ */ _jsxDEV("strong", {
													className: "text-white uppercase text-[9px] block mb-1",
													children: "Forensic Telemetry:"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 514,
													columnNumber: 29
												}, this), ind.technicalDetails]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 513,
												columnNumber: 27
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 509,
											columnNumber: 25
										}, this)]
									}, ind.id, true, {
										fileName: _jsxFileName,
										lineNumber: 474,
										columnNumber: 21
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 463,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mt-6 p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06] space-y-2",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "text-[10px] font-mono uppercase tracking-wider text-slate-400 font-semibold",
									children: "Comprehensive Verdict Rationale"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 526,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-300 leading-relaxed",
									children: result.verdictRationale
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 529,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 525,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mt-4 p-4 rounded-2xl bg-amber-950/20 border border-amber-500/25 space-y-1.5",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "text-xs font-semibold text-amber-300 flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "h-4 w-4 text-amber-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 537,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Understanding Detection Uncertainty" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 538,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 536,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-amber-200/80 leading-relaxed",
									children: "Post-processing, lossy compression transcoding, and camera filters can obscure fine sensor grain. All metrics indicate probabilistic heuristic correlation rather than infallible legal proof."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 540,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 535,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mt-6 pt-5 border-t border-white/[0.08] flex flex-col sm:flex-row items-center gap-3",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: onAnalyzeAnother,
										className: "w-full sm:flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 text-xs font-bold text-white bg-white/[0.06] hover:bg-white/[0.12] border border-white/[0.1] rounded-xl transition-all cursor-pointer active:scale-95",
										children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "h-4 w-4 text-cyan-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 551,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Analyze Another File" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 552,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 547,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: handleExportJSON,
										className: "w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-3 text-xs font-medium text-slate-200 hover:text-white bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] rounded-xl transition-colors cursor-pointer",
										title: "Download JSON Report",
										children: [/* @__PURE__ */ _jsxDEV(Download, { className: "h-4 w-4 text-cyan-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 560,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Export JSON" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 561,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 555,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: handleCopyReport,
										className: "w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-3 text-xs font-medium text-slate-200 hover:text-white bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] rounded-xl transition-colors cursor-pointer",
										title: "Copy Report Summary",
										children: [/* @__PURE__ */ _jsxDEV(Share2, { className: "h-4 w-4 text-cyan-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 569,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: copiedNotification ? "Copied!" : "Copy" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 570,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 564,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 546,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 451,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 449,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 238,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 140,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 139,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUNFLGFBQ0EsYUFDQSxZQUNBLFVBQ0EsV0FFQSxRQUNBLFVBQ0EsTUFDQSxhQUNBLFdBQ0EsVUFFQSxRQUNBLGFBSUEseUJBQ0s7OztBQWFQLE9BQU8sTUFBTSxvQkFBcUQsRUFDaEUsUUFDQSxZQUNBLFFBQ0EsYUFDQSxjQUNBLHVCQUNJO0NBQ0osTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQTZCLFVBQVU7Q0FDM0UsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FDaEQsT0FBTyxXQUFXLEVBQUUsRUFBRSxNQUFNLElBQzlCO0NBQ0EsTUFBTSxDQUFDLG9CQUFvQix5QkFBeUIsU0FBUyxLQUFLO0NBQ2xFLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQWlCLEVBQUU7Q0FDakUsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQWtCLEtBQUs7O0NBR2pFLE1BQU0sc0JBQ0osZUFBZSxTQUFTLFNBQ3BCLFNBQ0EsZUFBZSxjQUFjLGNBQzdCLGNBQ0EsZUFBZSxlQUFlLGVBQzlCLGVBQ0E7O0NBR04sTUFBTSx5QkFBeUI7RUFDN0IsUUFBUSxPQUFPLFlBQWY7R0FDRSxLQUFLLHVCQUNILE9BQU87SUFDTCxTQUFTO0lBQ1QsT0FBTztJQUNQLE1BQU0sd0JBQUMsYUFBRCxFQUFhLFdBQVUsd0JBQXlCOzs7OztJQUN0RCxVQUFVO0lBQ1YsWUFBWTtJQUNaLFlBQVk7SUFDWixhQUFhO0dBQ2Y7R0FDRixLQUFLLG9CQUNILE9BQU87SUFDTCxTQUFTO0lBQ1QsT0FBTztJQUNQLE1BQU0sd0JBQUMsYUFBRCxFQUFhLFdBQVUsMkJBQTRCOzs7OztJQUN6RCxVQUFVO0lBQ1YsWUFBWTtJQUNaLFlBQVk7SUFDWixhQUFhO0dBQ2Y7R0FDRixLQUFLO0dBQ0wsU0FDRSxPQUFPO0lBQ0wsU0FBUztJQUNULE9BQU87SUFDUCxNQUFNLHdCQUFDLFlBQUQsRUFBWSxXQUFVLHlCQUEwQjs7Ozs7SUFDdEQsVUFBVTtJQUNWLFlBQVk7SUFDWixZQUFZO0lBQ1osYUFBYTtHQUNmO0VBQ0o7Q0FDRjtDQUVBLE1BQU0sUUFBUSxpQkFBaUI7Q0FFL0IsTUFBTSx5QkFBeUI7RUFDN0IsTUFBTSxVQUFVLGtDQUFrQyxtQkFBbUIsS0FBSyxVQUFVLFFBQVEsTUFBTSxDQUFDLENBQUM7RUFDcEcsTUFBTSxpQkFBaUIsU0FBUyxjQUFjLEdBQUc7RUFDakQsZUFBZSxhQUFhLFFBQVEsT0FBTztFQUMzQyxlQUFlLGFBQWEsWUFBWSxrQkFBa0IsT0FBTyxTQUFTLFFBQVEsYUFBYSxFQUFFLEVBQUUsTUFBTTtFQUN6RyxTQUFTLEtBQUssWUFBWSxjQUFjO0VBQ3hDLGVBQWUsTUFBTTtFQUNyQixlQUFlLE9BQU87Q0FDeEI7Q0FFQSxNQUFNLHlCQUF5QjtFQUM3QixNQUFNLGFBQWE7UUFDZixPQUFPLFNBQVMsS0FBSyxPQUFPLFdBQVcsS0FBSSxDQUFFLFFBQVEsQ0FBQyxFQUFFO2NBQ2xELE9BQU8sV0FBVztjQUNsQixPQUFPLGdCQUFnQixNQUFNLE9BQU8sa0JBQWtCO2lCQUNuRCxPQUFPLHdCQUF3QjtVQUN0QyxPQUFPLFdBQVc7YUFDZixPQUFPLFVBQVU7OztFQUc1QixPQUFPLGlCQUFpQjs7O0VBR3hCLE9BQU8sV0FBVyxLQUFLLE1BQU0sTUFBTSxFQUFFLFNBQVMsWUFBWSxFQUFFLElBQUksRUFBRSxLQUFLLElBQUksRUFBRSxNQUFNLElBQUksRUFBRSxXQUFXLGNBQWMsQ0FBQyxDQUFDLEtBQUssSUFBSSxFQUFFOzs7RUFHL0gsT0FBTztFQUVMLFVBQVUsVUFBVSxVQUFVLFVBQVU7RUFDeEMsc0JBQXNCLElBQUk7RUFDMUIsaUJBQWlCLHNCQUFzQixLQUFLLEdBQUcsSUFBSTtDQUNyRDs7Q0FHQSxNQUFNLFNBQVM7Q0FDZixNQUFNLGdCQUFnQixJQUFJLEtBQUssS0FBSztDQUNwQyxNQUFNLG1CQUFtQixnQkFBaUIsT0FBTyxrQkFBa0IsTUFBTztDQUUxRSxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxJQUFHO0VBQW9CLFdBQVU7WUFDeEMsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUdFLHdCQUFDLE9BQUQ7SUFBSyxXQUFXLHNCQUFzQixNQUFNLFdBQVc7Y0FBdkQ7S0FHRSx3QkFBQyxPQUFELEVBQUssV0FBVSxnR0FBaUc7Ozs7O0tBRWhILHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFXLHVIQUF1SCxNQUFNO29CQUE5SSxDQUNFLHdCQUFDLFFBQUQsRUFBTSxXQUFXLDRCQUE0QixNQUFNLFFBQVU7Ozs7b0JBQzdELHdCQUFDLFFBQUQsWUFBTyxPQUFPLFdBQWlCOzs7O2tCQUMzQjs7Ozs7bUJBQ04sd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQW1ELGFBQ3ZDLE9BQU8sRUFDYjs7Ozs7aUJBQ0g7Ozs7OztRQUVMLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNYLE1BQU07UUFDTDs7Ozs7UUFFSix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFDVixPQUFPO1FBQ1A7Ozs7O09BQ0E7Ozs7O2dCQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBR0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFVBQUQ7V0FDRSxJQUFHO1dBQ0gsSUFBRztXQUNILEdBQUc7V0FDSCxRQUFPO1dBQ1AsYUFBWTtXQUNaLE1BQUs7VUFDTjs7OztvQkFDRCx3QkFBQyxVQUFEO1dBQ0UsSUFBRztXQUNILElBQUc7V0FDSCxHQUFHO1dBQ0gsUUFBUSxNQUFNO1dBQ2QsYUFBWTtXQUNaLGlCQUFpQjtXQUNDO1dBQ2xCLGVBQWM7V0FDZCxNQUFLO1dBQ0wsV0FBVTtVQUNYOzs7O2tCQUNFOzs7OzttQkFDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUNHLE9BQU8saUJBQWdCLEdBQ3BCOzs7OztvQkFDTix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEI7WUFBMkQ7WUFDdkQsT0FBTztZQUFrQjtXQUN2Qjs7Ozs7a0JBQ0g7Ozs7O2lCQUNGOzs7Ozs7UUFFTCx3QkFBQyxPQUFELEVBQUssV0FBVSw4QkFBK0I7Ozs7O1FBRTlDLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWdFO1VBRTFFOzs7OztVQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUE0QztVQUV0RDs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNHLE9BQU8seUJBQXdCLGlCQUM3Qjs7Ozs7O1VBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRyxPQUFPLFdBQVcsUUFBTyxrQkFDdkI7Ozs7OztTQUNGOzs7Ozs7T0FDRjs7Ozs7Y0FDRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLGlDQUFrQzs7OztpQkFDbEQsd0JBQUMsUUFBRCxZQUFPLE9BQU8saUJBQXVCOzs7O2VBQ2xDOzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWixPQUFPO01BQ0w7Ozs7Y0FDRjs7Ozs7O0lBQ0Y7Ozs7O2FBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUdFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUVFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSx3QkFBeUI7Ozs7bUJBQzNDLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUEwRTtTQUVwRjs7OztpQkFDSDs7Ozs7a0JBR0osT0FBTyxhQUFhLFdBQ25CLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsVUFBRDtXQUNFLGVBQWU7WUFDYixjQUFjLFVBQVU7WUFDeEIsaUJBQWlCLEtBQUs7V0FDeEI7V0FDQSxXQUFXLG1GQUNULGVBQWUsY0FBYyxDQUFDLGdCQUMxQixxRUFDQTtxQkFFUDtVQUVPOzs7OztVQUNSLHdCQUFDLFVBQUQ7V0FDRSxlQUFlO1lBQ2IsY0FBYyxLQUFLO1lBQ25CLGlCQUFpQixLQUFLO1dBQ3hCO1dBQ0EsV0FBVyxtRkFDVCxlQUFlLFNBQVMsQ0FBQyxnQkFDckIscUVBQ0E7cUJBRVA7VUFFTzs7Ozs7VUFDUix3QkFBQyxVQUFEO1dBQ0UsZUFBZTtZQUNiLGNBQWMsVUFBVTtZQUN4QixpQkFBaUIsS0FBSztXQUN4QjtXQUNBLFdBQVcsbUZBQ1QsZUFBZSxjQUFjLENBQUMsZ0JBQzFCLHFFQUNBO3FCQUVQO1VBRU87Ozs7O1VBQ1Isd0JBQUMsVUFBRDtXQUNFLGVBQWU7WUFDYixjQUFjLFdBQVc7WUFDekIsaUJBQWlCLEtBQUs7V0FDeEI7V0FDQSxXQUFXLG1GQUNULGVBQWUsZUFBZSxDQUFDLGdCQUMzQixxRUFDQTtxQkFFUDtVQUVPOzs7OztVQUNSLHdCQUFDLFVBQUQ7V0FDRSxlQUFlLGlCQUFpQixDQUFDLGFBQWE7V0FDOUMsV0FBVywyR0FDVCxnQkFDSSwyRUFDQTtxQkFMUixDQVFFLHdCQUFDLG1CQUFELEVBQW1CLFdBQVUsVUFBVzs7OztxQkFDeEMsd0JBQUMsUUFBRCxZQUFNLGFBQWdCOzs7O21CQUNoQjs7Ozs7O1NBQ0w7Ozs7O2dCQUVKOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNHLE9BQU8sYUFBYSxVQUNuQixrQkFBa0IsVUFBVSxlQUMxQix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUVFLHdCQUFDLE9BQUQ7V0FDRSxLQUFLO1dBQ0wsS0FBSTtXQUNKLFdBQVU7VUFDWDs7Ozs7VUFHRCx3QkFBQyxPQUFEO1dBQ0UsV0FBVTtXQUNWLE9BQU8sRUFBRSxVQUFVLFdBQVcsZ0JBQWdCLDBCQUEwQixnQkFBZ0IsU0FBUztxQkFFakcsd0JBQUMsT0FBRDtZQUNFLEtBQUssVUFBVTtZQUNmLEtBQUk7WUFDSixXQUFVO1dBQ1g7Ozs7O1VBQ0U7Ozs7O1VBR0wsd0JBQUMsT0FBRDtXQUNFLFdBQVU7V0FDVixPQUFPLEVBQUUsTUFBTSxHQUFHLGdCQUFnQixHQUFHO1VBQ3RDOzs7OztVQUVELHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsS0FBSTtXQUNKLEtBQUk7V0FDSixPQUFPO1dBQ1AsV0FBVyxNQUFNLG1CQUFtQixPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUM7V0FDMUQsV0FBVTtXQUNWLGNBQVc7VUFDWjs7Ozs7U0FDRTs7Ozs7bUJBRUwsd0JBQUMsT0FBRDtTQUNFLEtBQUs7U0FDTCxLQUFJO1NBQ0osV0FBVTtRQUNYOzs7O21CQUdILHdCQUFDLFNBQUQ7U0FDRSxLQUFLO1NBQ0w7U0FDQSxXQUFVO1FBQ1g7Ozs7a0JBSUgsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FBZ0wsVUFDdkssZ0JBQWdCLGdDQUFnQyxVQUNwRDs7Ozs7Z0JBQ0Y7Ozs7OztPQUdMLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFiO1NBQ0csZUFBZSxjQUFjLENBQUMsaUJBQWlCO1NBQy9DLGVBQWUsU0FBUyxDQUFDLGlCQUFpQjtTQUMxQyxlQUFlLGNBQWMsQ0FBQyxpQkFBaUI7U0FDL0MsZUFBZSxlQUFlLENBQUMsaUJBQWlCO1NBQ2hELGlCQUFpQjtRQUNqQjs7Ozs7O01BQ0E7Ozs7O2VBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHdCQUF5Qjs7OztrQkFDN0Msd0JBQUMsUUFBRCxZQUFNLGlDQUFvQzs7OztnQkFDdEM7Ozs7O2lCQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFXLDhEQUE4RCxPQUFPLFNBQVMsVUFBVSxvRUFBb0U7a0JBQzFLLE9BQU8sU0FBUyxVQUFVLGdCQUFnQjtPQUN2Qzs7OztlQUNIOzs7OztnQkFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQXVDO1NBQWdCOzs7O21CQUN0RSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBMEMsT0FBTyxTQUFTLGNBQWM7U0FBdUI7Ozs7aUJBQzNHOzs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUF1QztTQUFpQjs7OzttQkFDdkUsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQTBDLE9BQU8sU0FBUyxlQUFlO1NBQVc7Ozs7aUJBQ2hHOzs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUF1QztTQUFtQjs7OzttQkFDekUsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1osT0FBTyxTQUFTLE1BQU0sT0FBTyxPQUFPLFNBQVMsSUFBSSxLQUFLLE9BQU8sU0FBUyxXQUFXLE9BQU87U0FDdEY7Ozs7aUJBQ0Y7Ozs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQXVDO1NBQWU7Ozs7bUJBQ3JFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0csT0FBTyxTQUFTLFdBQVc7V0FBTTtXQUFJLE9BQU8sU0FBUyxXQUFXO1VBQzlEOzs7OztpQkFDRjs7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBdUM7U0FBa0I7Ozs7bUJBQ3hFLHdCQUFDLE9BQUQ7VUFBSyxXQUFXLHNCQUFzQixPQUFPLFNBQVMsY0FBYyxxQkFBcUI7b0JBQ3RGLE9BQU8sU0FBUyxjQUFjLDZCQUE2QjtTQUN6RDs7OztpQkFDRjs7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBdUM7U0FBaUI7Ozs7bUJBQ3ZFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO1VBQXlDLE9BQU8sT0FBTyxTQUFTLFlBQVk7b0JBQ3hGLE9BQU8sU0FBUyxZQUFZO1NBQzFCOzs7O2lCQUNGOzs7Ozs7T0FDRjs7Ozs7Y0FDRjs7Ozs7YUFFRjs7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUViLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEIsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSx3QkFBeUI7Ozs7bUJBQzdDLHdCQUFDLFFBQUQsWUFBTSxpQ0FBb0M7Ozs7aUJBQ3RDOzs7OztrQkFDTix3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEIsQ0FDRyxPQUFPLFdBQVcsUUFBTyxVQUN0Qjs7Ozs7Z0JBQ0g7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaLE9BQU8sV0FBVyxLQUFLLFFBQVE7U0FDOUIsTUFBTSxhQUFhLHNCQUFzQixJQUFJO1NBQzdDLE1BQU0sZ0JBQ0osSUFBSSxhQUFhLFNBQ2Isb0RBQ0EsSUFBSSxhQUFhLFdBQ2pCLHVEQUNBO1NBRU4sT0FDRSx3QkFBQyxPQUFEO1VBRUUsV0FBVTtvQkFGWixDQUlFLHdCQUFDLFVBQUQ7V0FDRSxlQUFlLHFCQUFxQixhQUFhLE9BQU8sSUFBSSxFQUFFO1dBQzlELFdBQVU7cUJBRlosQ0FJRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsUUFBRDtjQUFNLFdBQVcsNkVBQTZFO3dCQUMzRixJQUFJO2FBQ0Q7Ozs7dUJBQ04sd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQ2IsSUFBSTthQUNEOzs7O3FCQUNIOzs7OztzQkFDTCx3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFDWCxJQUFJO1lBQ0g7Ozs7b0JBQ0Q7Ozs7O3FCQUVMLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWhCLENBQ0csSUFBSSxZQUFXLEdBQ1o7Ozs7O3NCQUNMLGFBQ0Msd0JBQUMsV0FBRCxFQUFXLFdBQVUseUJBQTBCOzs7O3VCQUUvQyx3QkFBQyxhQUFELEVBQWEsV0FBVSx5QkFBMEI7Ozs7b0JBRWhEOzs7OzttQkFDQzs7Ozs7b0JBRVAsY0FDQyx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLEtBQUQ7WUFBRyxXQUFVO3NCQUNWLElBQUk7V0FDSjs7OztxQkFDSCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFVBQUQ7YUFBUSxXQUFVO3VCQUE2QztZQUEyQjs7OztzQkFDekYsSUFBSSxnQkFDRjs7Ozs7bUJBQ0Y7Ozs7O2tCQUVKO1lBNUNFLElBQUk7Ozs7Z0JBNENOO1FBRVQsQ0FBQztPQUNFOzs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQThFO1FBRXhGOzs7O2tCQUNMLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUNWLE9BQU87UUFDUDs7OztnQkFDQTs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLHlCQUEwQjs7OzttQkFDakQsd0JBQUMsUUFBRCxZQUFNLHNDQUF5Qzs7OztpQkFDNUM7Ozs7O2tCQUNMLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUE0QztRQUV0RDs7OztnQkFDQTs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxVQUFEO1VBQ0UsU0FBUztVQUNULFdBQVU7b0JBRlosQ0FJRSx3QkFBQyxXQUFELEVBQVcsV0FBVSx3QkFBeUI7Ozs7b0JBQzlDLHdCQUFDLFFBQUQsWUFBTSx1QkFBMEI7Ozs7a0JBQzFCOzs7Ozs7U0FFUix3QkFBQyxVQUFEO1VBQ0UsU0FBUztVQUNULFdBQVU7VUFDVixPQUFNO29CQUhSLENBS0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsd0JBQXlCOzs7O29CQUM3Qyx3QkFBQyxRQUFELFlBQU0sY0FBaUI7Ozs7a0JBQ2pCOzs7Ozs7U0FFUix3QkFBQyxVQUFEO1VBQ0UsU0FBUztVQUNULFdBQVU7VUFDVixPQUFNO29CQUhSLENBS0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsd0JBQXlCOzs7O29CQUMzQyx3QkFBQyxRQUFELFlBQU8scUJBQXFCLFlBQVksT0FBYTs7OztrQkFDL0M7Ozs7OztRQUNMOzs7Ozs7TUFFRjs7Ozs7O0lBRUY7Ozs7WUFFRjs7Ozs7V0FFRjs7Ozs7O0NBQ0U7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUmVzdWx0c0Rhc2hib2FyZC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHtcbiAgU2hpZWxkQWxlcnQsXG4gIFNoaWVsZENoZWNrLFxuICBIZWxwQ2lyY2xlLFxuICBEb3dubG9hZCxcbiAgUm90YXRlQ2N3LFxuICBTbGlkZXJzLFxuICBMYXllcnMsXG4gIEZpbGVDb2RlLFxuICBJbmZvLFxuICBDaGV2cm9uRG93bixcbiAgQ2hldnJvblVwLFxuICBBY3Rpdml0eSxcbiAgTWF4aW1pemUyLFxuICBTaGFyZTIsXG4gIEFsZXJ0Q2lyY2xlLFxuICBDb3B5LFxuICBDaGVjayxcbiAgRXllLFxuICBTbGlkZXJzSG9yaXpvbnRhbCxcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IEFuYWx5c2lzUmVzdWx0IH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHsgRm9yZW5zaWNGaWx0ZXJNb2RlIH0gZnJvbSAnLi4vdXRpbHMvZm9yZW5zaWNDYW52YXMnO1xuXG5pbnRlcmZhY2UgUmVzdWx0c0Rhc2hib2FyZFByb3BzIHtcbiAgcmVzdWx0OiBBbmFseXNpc1Jlc3VsdDtcbiAgcHJldmlld1VybDogc3RyaW5nO1xuICBlbGFVcmw/OiBzdHJpbmc7XG4gIGhpZ2hwYXNzVXJsPzogc3RyaW5nO1xuICBsdW1pbmFuY2VVcmw/OiBzdHJpbmc7XG4gIG9uQW5hbHl6ZUFub3RoZXI6ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBSZXN1bHRzRGFzaGJvYXJkOiBSZWFjdC5GQzxSZXN1bHRzRGFzaGJvYXJkUHJvcHM+ID0gKHtcbiAgcmVzdWx0LFxuICBwcmV2aWV3VXJsLFxuICBlbGFVcmwsXG4gIGhpZ2hwYXNzVXJsLFxuICBsdW1pbmFuY2VVcmwsXG4gIG9uQW5hbHl6ZUFub3RoZXIsXG59KSA9PiB7XG4gIGNvbnN0IFtmaWx0ZXJNb2RlLCBzZXRGaWx0ZXJNb2RlXSA9IHVzZVN0YXRlPEZvcmVuc2ljRmlsdGVyTW9kZT4oJ29yaWdpbmFsJyk7XG4gIGNvbnN0IFtleHBhbmRlZEluZGljYXRvciwgc2V0RXhwYW5kZWRJbmRpY2F0b3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4oXG4gICAgcmVzdWx0LmluZGljYXRvcnNbMF0/LmlkIHx8IG51bGxcbiAgKTtcbiAgY29uc3QgW2NvcGllZE5vdGlmaWNhdGlvbiwgc2V0Q29waWVkTm90aWZpY2F0aW9uXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2NvbXBhcmlzb25TcGxpdCwgc2V0Q29tcGFyaXNvblNwbGl0XSA9IHVzZVN0YXRlPG51bWJlcj4oNTApO1xuICBjb25zdCBbaXNTcGxpdEFjdGl2ZSwgc2V0SXNTcGxpdEFjdGl2ZV0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG5cbiAgLy8gRGV0ZXJtaW5lIGN1cnJlbnQgYWN0aXZlIHByZXZpZXcgaW1hZ2UgYmFzZWQgb24gZmlsdGVyIG1vZGVcbiAgY29uc3QgY3VycmVudFZpc3VhbFNvdXJjZSA9XG4gICAgZmlsdGVyTW9kZSA9PT0gJ2VsYScgJiYgZWxhVXJsXG4gICAgICA/IGVsYVVybFxuICAgICAgOiBmaWx0ZXJNb2RlID09PSAnaGlnaHBhc3MnICYmIGhpZ2hwYXNzVXJsXG4gICAgICA/IGhpZ2hwYXNzVXJsXG4gICAgICA6IGZpbHRlck1vZGUgPT09ICdsdW1pbmFuY2UnICYmIGx1bWluYW5jZVVybFxuICAgICAgPyBsdW1pbmFuY2VVcmxcbiAgICAgIDogcHJldmlld1VybDtcblxuICAvLyBDYXRlZ29yeSB2aXN1YWwgc3R5bGVzXG4gIGNvbnN0IGdldENhdGVnb3J5VGhlbWUgPSAoKSA9PiB7XG4gICAgc3dpdGNoIChyZXN1bHQuYXNzZXNzbWVudCkge1xuICAgICAgY2FzZSAnTGlrZWx5IEFJLWdlbmVyYXRlZCc6XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgYmFkZ2VCZzogJ2JnLXJvc2UtNTAwLzE1IGJvcmRlci1yb3NlLTUwMC80MCB0ZXh0LXJvc2UtMzAwJyxcbiAgICAgICAgICBkb3RCZzogJ2JnLXJvc2UtNTAwIHNoYWRvdy1bMF8wXzEycHhfI2Y0M2Y1ZV0nLFxuICAgICAgICAgIGljb246IDxTaGllbGRBbGVydCBjbGFzc05hbWU9XCJoLTYgdy02IHRleHQtcm9zZS00MDBcIiAvPixcbiAgICAgICAgICBoZWFkbGluZTogJ1N5bnRoZXRpYyBNZWRpYSBTaWduYWxzIERldGVjdGVkJyxcbiAgICAgICAgICBjYXJkQm9yZGVyOiAnYm9yZGVyLXJvc2UtNTAwLzMwJyxcbiAgICAgICAgICBnYXVnZUNvbG9yOiAnI2Y0M2Y1ZScsXG4gICAgICAgICAgYWNjZW50Q29sb3I6ICd0ZXh0LXJvc2UtNDAwJyxcbiAgICAgICAgfTtcbiAgICAgIGNhc2UgJ0xpa2VseSBhdXRoZW50aWMnOlxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGJhZGdlQmc6ICdiZy1lbWVyYWxkLTUwMC8xNSBib3JkZXItZW1lcmFsZC01MDAvNDAgdGV4dC1lbWVyYWxkLTMwMCcsXG4gICAgICAgICAgZG90Qmc6ICdiZy1lbWVyYWxkLTUwMCBzaGFkb3ctWzBfMF8xMnB4XyMxMGI5ODFdJyxcbiAgICAgICAgICBpY29uOiA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwiaC02IHctNiB0ZXh0LWVtZXJhbGQtNDAwXCIgLz4sXG4gICAgICAgICAgaGVhZGxpbmU6ICdPcHRpY2FsIEhhcmR3YXJlIENvbnNpc3RlbmN5IENvbmZpcm1lZCcsXG4gICAgICAgICAgY2FyZEJvcmRlcjogJ2JvcmRlci1lbWVyYWxkLTUwMC8zMCcsXG4gICAgICAgICAgZ2F1Z2VDb2xvcjogJyMxMGI5ODEnLFxuICAgICAgICAgIGFjY2VudENvbG9yOiAndGV4dC1lbWVyYWxkLTQwMCcsXG4gICAgICAgIH07XG4gICAgICBjYXNlICdJbmNvbmNsdXNpdmUnOlxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBiYWRnZUJnOiAnYmctYW1iZXItNTAwLzE1IGJvcmRlci1hbWJlci01MDAvNDAgdGV4dC1hbWJlci0zMDAnLFxuICAgICAgICAgIGRvdEJnOiAnYmctYW1iZXItNTAwIHNoYWRvdy1bMF8wXzEycHhfI2Y1OWUwYl0nLFxuICAgICAgICAgIGljb246IDxIZWxwQ2lyY2xlIGNsYXNzTmFtZT1cImgtNiB3LTYgdGV4dC1hbWJlci00MDBcIiAvPixcbiAgICAgICAgICBoZWFkbGluZTogJ0FtYmlndW91cyBGb3JlbnNpYyBQcm9maWxlJyxcbiAgICAgICAgICBjYXJkQm9yZGVyOiAnYm9yZGVyLWFtYmVyLTUwMC8zMCcsXG4gICAgICAgICAgZ2F1Z2VDb2xvcjogJyNmNTllMGInLFxuICAgICAgICAgIGFjY2VudENvbG9yOiAndGV4dC1hbWJlci00MDAnLFxuICAgICAgICB9O1xuICAgIH1cbiAgfTtcblxuICBjb25zdCB0aGVtZSA9IGdldENhdGVnb3J5VGhlbWUoKTtcblxuICBjb25zdCBoYW5kbGVFeHBvcnRKU09OID0gKCkgPT4ge1xuICAgIGNvbnN0IGRhdGFTdHIgPSAnZGF0YTp0ZXh0L2pzb247Y2hhcnNldD11dGYtOCwnICsgZW5jb2RlVVJJQ29tcG9uZW50KEpTT04uc3RyaW5naWZ5KHJlc3VsdCwgbnVsbCwgMikpO1xuICAgIGNvbnN0IGRvd25sb2FkQW5jaG9yID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICAgIGRvd25sb2FkQW5jaG9yLnNldEF0dHJpYnV0ZSgnaHJlZicsIGRhdGFTdHIpO1xuICAgIGRvd25sb2FkQW5jaG9yLnNldEF0dHJpYnV0ZSgnZG93bmxvYWQnLCBgVkVSSVRBU19SZXBvcnRfJHtyZXN1bHQuZmlsZU5hbWUucmVwbGFjZSgvXFwuW14vLl0rJC8sICcnKX0uanNvbmApO1xuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZG93bmxvYWRBbmNob3IpO1xuICAgIGRvd25sb2FkQW5jaG9yLmNsaWNrKCk7XG4gICAgZG93bmxvYWRBbmNob3IucmVtb3ZlKCk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ29weVJlcG9ydCA9ICgpID0+IHtcbiAgICBjb25zdCByZXBvcnRUZXh0ID0gYFtWRVJJVEFTIEFJIEZPUkVOU0lDIFJFUE9SVF1cbkZpbGU6ICR7cmVzdWx0LmZpbGVOYW1lfSAoJHsocmVzdWx0LmZpbGVTaXplIC8gMTAyNCkudG9GaXhlZCgxKX0gS0IpXG5Bc3Nlc3NtZW50OiAke3Jlc3VsdC5hc3Nlc3NtZW50fVxuQ29uZmlkZW5jZTogJHtyZXN1bHQuY29uZmlkZW5jZVNjb3JlfSUgKMKxJHtyZXN1bHQudW5jZXJ0YWludHlNYXJnaW59JSlcblNjYW4gRHVyYXRpb246ICR7cmVzdWx0LmFuYWx5c2lzRHVyYXRpb25TZWNvbmRzfXNcbkVuZ2luZTogJHtyZXN1bHQuZW5naW5lTmFtZX1cblRpbWVzdGFtcDogJHtyZXN1bHQudGltZXN0YW1wfVxuXG5WZXJkaWN0IFJhdGlvbmFsZTpcbiR7cmVzdWx0LnZlcmRpY3RSYXRpb25hbGV9XG5cbktleSBJbmRpY2F0b3JzOlxuJHtyZXN1bHQuaW5kaWNhdG9ycy5tYXAoKGkpID0+IGAtIFske2kuc2V2ZXJpdHkudG9VcHBlckNhc2UoKX1dICR7aS5uYW1lfTogJHtpLnRpdGxlfSAoJHtpLmNvbmZpZGVuY2V9JSBjb25maWRlbmNlKWApLmpvaW4oJ1xcbicpfVxuXG5VbmNlcnRhaW50eSBEaXNjbG9zdXJlOlxuJHtyZXN1bHQuZW5naW5lRGlzY2xhaW1lcn1gO1xuXG4gICAgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQocmVwb3J0VGV4dCk7XG4gICAgc2V0Q29waWVkTm90aWZpY2F0aW9uKHRydWUpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0Q29waWVkTm90aWZpY2F0aW9uKGZhbHNlKSwgMjQwMCk7XG4gIH07XG5cbiAgLy8gU1ZHIEdhdWdlIGNhbGN1bGF0aW9uc1xuICBjb25zdCByYWRpdXMgPSAzODtcbiAgY29uc3QgY2lyY3VtZmVyZW5jZSA9IDIgKiBNYXRoLlBJICogcmFkaXVzO1xuICBjb25zdCBzdHJva2VEYXNob2Zmc2V0ID0gY2lyY3VtZmVyZW5jZSAtIChyZXN1bHQuY29uZmlkZW5jZVNjb3JlIC8gMTAwKSAqIGNpcmN1bWZlcmVuY2U7XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBpZD1cInJlc3VsdHMtZGFzaGJvYXJkXCIgY2xhc3NOYW1lPVwicmVsYXRpdmUgc2Nyb2xsLW10LTIwIHB5LTIwIHB4LTYgbGc6cHgtOCBib3JkZXItdCBib3JkZXItd2hpdGUvWzAuMDhdIGJnLVsjMDMwNjE0XVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LTZ4bCBzcGFjZS15LThcIj5cbiAgICAgICAgXG4gICAgICAgIHsvKiBUb3AgU3VtbWFyeSBCYW5uZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcm91bmRlZC0zeGwgYm9yZGVyICR7dGhlbWUuY2FyZEJvcmRlcn0gYmctWyMwNjBhMWRdLzk1IGJhY2tkcm9wLWJsdXItMnhsIHAtNiBzbTpwLTkgc2hhZG93LTJ4bCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5gfT5cbiAgICAgICAgICBcbiAgICAgICAgICB7LyogQXRtb3NwaGVyaWMgYmFja2dyb3VuZCBnbG93ICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCB3LTk2IGgtOTYgYmctY3lhbi01MDAvMTAgcm91bmRlZC1mdWxsIGJsdXItWzEwMHB4XSBwb2ludGVyLWV2ZW50cy1ub25lXCIgLz5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBsZzpmbGV4LXJvdyBpdGVtcy1zdGFydCBsZzppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC04XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMy41IG1heC13LTJ4bFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMS41IHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtbW9ubyBmb250LWJvbGQgdHJhY2tpbmctd2lkZXIgdXBwZXJjYXNlIGJvcmRlciAke3RoZW1lLmJhZGdlQmd9YH0+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B3LTIuNSBoLTIuNSByb3VuZGVkLWZ1bGwgJHt0aGVtZS5kb3RCZ31gfSAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+e3Jlc3VsdC5hc3Nlc3NtZW50fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgIFNjYW4gSUQ6IHtyZXN1bHQuaWR9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgc206dGV4dC0zeGwgZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSB0cmFja2luZy10aWdodCBbdGV4dC13cmFwOmJhbGFuY2VdXCI+XG4gICAgICAgICAgICAgICAge3RoZW1lLmhlYWRsaW5lfVxuICAgICAgICAgICAgICA8L2gyPlxuXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1zbGF0ZS0zMDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAge3Jlc3VsdC5zdW1tYXJ5fVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIENpcmN1bGFyIENvbmZpZGVuY2UgR2F1Z2UgJiBTdGF0dXMgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC02IHAtNSByb3VuZGVkLTJ4bCBiZy13aGl0ZS9bMC4wM10gYm9yZGVyIGJvcmRlci13aGl0ZS9bMC4wOF0gc2hyaW5rLTAgdy1mdWxsIHNtOnctYXV0byBqdXN0aWZ5LWJldHdlZW4gc206anVzdGlmeS1zdGFydFwiPlxuICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgey8qIENpcmN1bGFyIEdhdWdlICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMjQgaC0yNFwiPlxuICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy0yNCBoLTI0IC1yb3RhdGUtOTBcIj5cbiAgICAgICAgICAgICAgICAgIDxjaXJjbGVcbiAgICAgICAgICAgICAgICAgICAgY3g9XCI0OFwiXG4gICAgICAgICAgICAgICAgICAgIGN5PVwiNDhcIlxuICAgICAgICAgICAgICAgICAgICByPXtyYWRpdXN9XG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cInJnYmEoMjU1LCAyNTUsIDI1NSwgMC4wOClcIlxuICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjhcIlxuICAgICAgICAgICAgICAgICAgICBmaWxsPVwidHJhbnNwYXJlbnRcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDxjaXJjbGVcbiAgICAgICAgICAgICAgICAgICAgY3g9XCI0OFwiXG4gICAgICAgICAgICAgICAgICAgIGN5PVwiNDhcIlxuICAgICAgICAgICAgICAgICAgICByPXtyYWRpdXN9XG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZT17dGhlbWUuZ2F1Z2VDb2xvcn1cbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCI4XCJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlRGFzaGFycmF5PXtjaXJjdW1mZXJlbmNlfVxuICAgICAgICAgICAgICAgICAgICBzdHJva2VEYXNob2Zmc2V0PXtzdHJva2VEYXNob2Zmc2V0fVxuICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxuICAgICAgICAgICAgICAgICAgICBmaWxsPVwidHJhbnNwYXJlbnRcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xMDAwIGVhc2Utb3V0XCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIGZvbnQtbW9ubyB0YWJ1bGFyLW51bXMgbGVhZGluZy1ub25lXCI+XG4gICAgICAgICAgICAgICAgICAgIHtyZXN1bHQuY29uZmlkZW5jZVNjb3JlfSVcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzlweF0gZm9udC1tb25vIHRleHQtc2xhdGUtNDAwIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgwrF7cmVzdWx0LnVuY2VydGFpbnR5TWFyZ2lufSVcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTE0IHctWzFweF0gYmctd2hpdGUvWzAuMV1cIiAvPlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LW1vbm8gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICBJbnNwZWN0aW9uIFN0YXR1c1xuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1jeWFuLTQwMCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgIFZFUklGSUVEXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ubyB0YWJ1bGFyLW51bXNcIj5cbiAgICAgICAgICAgICAgICAgIHtyZXN1bHQuYW5hbHlzaXNEdXJhdGlvblNlY29uZHN9cyBzY2FuIGR1cmF0aW9uXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgIHtyZXN1bHQuaW5kaWNhdG9ycy5sZW5ndGh9IHZlY3RvcnMgYXVkaXRlZFxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEVuZ2luZSBEaXNjbGFpbWVyIC8gRGVtb25zdHJhdGlvbiBEaXNjbG9zdXJlICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNyBwdC00IGJvcmRlci10IGJvcmRlci13aGl0ZS9bMC4wOF0gZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBpdGVtcy1zdGFydCBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPEluZm8gY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWN5YW4tNDAwIHNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+e3Jlc3VsdC5lbmdpbmVEaXNjbGFpbWVyfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAge3Jlc3VsdC5lbmdpbmVOYW1lfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiAyLUNvbHVtbiBTcGxpdDogRm9yZW5zaWMgVmlzdWFsaXplciAoTGVmdCkgYW5kIEluZGljYXRvcnMgKFJpZ2h0KSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0xMiBnYXAtOCBpdGVtcy1zdGFydFwiPlxuICAgICAgICAgIFxuICAgICAgICAgIHsvKiBMZWZ0IENvbHVtbjogSW50ZXJhY3RpdmUgRm9yZW5zaWMgVmlzdWFsaXplciAoNyBjb2xzKSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTcgc3BhY2UteS01XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtM3hsIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMDhdIGJnLVsjMDUwODE2XSBwLTYgYmFja2Ryb3AtYmx1ci0yeGwgc2hhZG93LXhsXCI+XG4gICAgICAgICAgICAgIFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00IGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxMYXllcnMgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWN5YW4tNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTIwMCBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgIEZvcmVuc2ljIFZpc3VhbCBJbnNwZWN0aW9uXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogRmlsdGVyIE1vZGUgQnV0dG9ucyAqL31cbiAgICAgICAgICAgICAgICB7cmVzdWx0LmZpbGVUeXBlID09PSAnaW1hZ2UnICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcC0xIGJnLXdoaXRlL1swLjA0XSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMDZdIG92ZXJmbG93LXgtYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0RmlsdGVyTW9kZSgnb3JpZ2luYWwnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldElzU3BsaXRBY3RpdmUoZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0xIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyTW9kZSA9PT0gJ29yaWdpbmFsJyAmJiAhaXNTcGxpdEFjdGl2ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1jeWFuLTUwMC8yNSB0ZXh0LWN5YW4tMzAwIGJvcmRlciBib3JkZXItY3lhbi01MDAvNDAgc2hhZG93LXNtJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgT3JpZ2luYWxcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRGaWx0ZXJNb2RlKCdlbGEnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldElzU3BsaXRBY3RpdmUoZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0xIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyTW9kZSA9PT0gJ2VsYScgJiYgIWlzU3BsaXRBY3RpdmVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctY3lhbi01MDAvMjUgdGV4dC1jeWFuLTMwMCBib3JkZXIgYm9yZGVyLWN5YW4tNTAwLzQwIHNoYWRvdy1zbSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIEVMQSBIZWF0bWFwXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0RmlsdGVyTW9kZSgnaGlnaHBhc3MnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldElzU3BsaXRBY3RpdmUoZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0xIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyTW9kZSA9PT0gJ2hpZ2hwYXNzJyAmJiAhaXNTcGxpdEFjdGl2ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1jeWFuLTUwMC8yNSB0ZXh0LWN5YW4tMzAwIGJvcmRlciBib3JkZXItY3lhbi01MDAvNDAgc2hhZG93LXNtJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgSGlnaC1QYXNzIEVkZ2VcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRGaWx0ZXJNb2RlKCdsdW1pbmFuY2UnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldElzU3BsaXRBY3RpdmUoZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0xIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyTW9kZSA9PT0gJ2x1bWluYW5jZScgJiYgIWlzU3BsaXRBY3RpdmVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctY3lhbi01MDAvMjUgdGV4dC1jeWFuLTMwMCBib3JkZXIgYm9yZGVyLWN5YW4tNTAwLzQwIHNoYWRvdy1zbSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIEx1bWluYW5jZVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzU3BsaXRBY3RpdmUoIWlzU3BsaXRBY3RpdmUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMSB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzU3BsaXRBY3RpdmVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctdmlvbGV0LTUwMC8zMCB0ZXh0LXZpb2xldC0yMDAgYm9yZGVyIGJvcmRlci12aW9sZXQtNTAwLzQwIHNoYWRvdy1zbSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxTbGlkZXJzSG9yaXpvbnRhbCBjbGFzc05hbWU9XCJoLTMgdy0zXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5TcGxpdCBXaXBlPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBWaWV3cG9ydCBGcmFtZSAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXdoaXRlL1swLjFdIGJnLWJsYWNrLzgwIG92ZXJmbG93LWhpZGRlbiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtaW4taC1bMzgwcHhdIG1heC1oLVs1MjBweF1cIj5cbiAgICAgICAgICAgICAgICB7cmVzdWx0LmZpbGVUeXBlID09PSAnaW1hZ2UnID8gKFxuICAgICAgICAgICAgICAgICAgaXNTcGxpdEFjdGl2ZSAmJiAoZWxhVXJsIHx8IGhpZ2hwYXNzVXJsKSA/IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgaC1mdWxsIG1pbi1oLVs0NDBweF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgey8qIEJhc2U6IE9yaWdpbmFsICovfVxuICAgICAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17cHJldmlld1VybH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGFsdD1cIk9yaWdpbmFsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1heC1oLVs0NjBweF0gbWF4LXctZnVsbCBvYmplY3QtY29udGFpbiBwLTJcIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogT3ZlcmxhaWQgRUxBIGxheWVyIGNsaXBwZWQgdG8gY29tcGFyaXNvblNwbGl0ICovfVxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgb3ZlcmZsb3ctaGlkZGVuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGNsaXBQYXRoOiBgcG9seWdvbigke2NvbXBhcmlzb25TcGxpdH0lIDAsIDEwMCUgMCwgMTAwJSAxMDAlLCAke2NvbXBhcmlzb25TcGxpdH0lIDEwMCUpYCB9fVxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtlbGFVcmwgfHwgY3VycmVudFZpc3VhbFNvdXJjZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwiRm9yZW5zaWMgRUxBXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWF4LWgtWzQ2MHB4XSBtYXgtdy1mdWxsIG9iamVjdC1jb250YWluIHAtMlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEludGVyYWN0aXZlIERpdmlkZXIgTGluZSAqL31cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMCBib3R0b20tMCB3LTAuNSBiZy1jeWFuLTQwMCBzaGFkb3ctWzBfMF8xNXB4XyMyMmQzZWVdIHBvaW50ZXItZXZlbnRzLW5vbmUgei0yMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBsZWZ0OiBgJHtjb21wYXJpc29uU3BsaXR9JWAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgICAgICAgICAgICAgbWluPVwiNVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXg9XCI5NVwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y29tcGFyaXNvblNwbGl0fVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb21wYXJpc29uU3BsaXQoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC14LTAgYm90dG9tLTggaC04IG9wYWNpdHktMCBjdXJzb3ItZXctcmVzaXplIHotNDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkFkanVzdCBzcGxpdCBjb21wYXJpc29uXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgICBzcmM9e2N1cnJlbnRWaXN1YWxTb3VyY2V9XG4gICAgICAgICAgICAgICAgICAgICAgYWx0PVwiRm9yZW5zaWMgbGF5ZXIgdmlld1wiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWF4LWgtWzQ2MHB4XSBtYXgtdy1mdWxsIG9iamVjdC1jb250YWluIHAtMlwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDx2aWRlb1xuICAgICAgICAgICAgICAgICAgICBzcmM9e3ByZXZpZXdVcmx9XG4gICAgICAgICAgICAgICAgICAgIGNvbnRyb2xzXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1heC1oLVs0NjBweF0gbWF4LXctZnVsbCBvYmplY3QtY29udGFpblwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICB7LyogTGF5ZXIgd2F0ZXJtYXJrIHRhZyAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS0zIGxlZnQtMyB0ZXh0LVsxMHB4XSBmb250LW1vbm8gcHgtMyBweS0xIHJvdW5kZWQtbGcgYmctYmxhY2svODAgYm9yZGVyIGJvcmRlci13aGl0ZS8xNSB0ZXh0LWN5YW4tMzAwIGJhY2tkcm9wLWJsdXItbWQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgICAgICBNb2RlOiB7aXNTcGxpdEFjdGl2ZSA/ICdTcGxpdCBXaXBlIChPcmlnaW5hbCAvIEVMQSknIDogZmlsdGVyTW9kZX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIEV4cGxhbmF0aW9uIG9mIGN1cnJlbnQgdmlzdWFsIGxheWVyICovfVxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0zLjUgdGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBsZWFkaW5nLW5vcm1hbFwiPlxuICAgICAgICAgICAgICAgIHtmaWx0ZXJNb2RlID09PSAnb3JpZ2luYWwnICYmICFpc1NwbGl0QWN0aXZlICYmICdTdGFuZGFyZCBzb3VyY2UgbWVkaWEgcmVuZGVyaW5nIGF0IG5hdGl2ZSBjb2xvci1zcGFjZS4nfVxuICAgICAgICAgICAgICAgIHtmaWx0ZXJNb2RlID09PSAnZWxhJyAmJiAhaXNTcGxpdEFjdGl2ZSAmJiAnRXJyb3IgTGV2ZWwgQW5hbHlzaXMgKEVMQSkgaGlnaGxpZ2h0cyBjb21wcmVzc2lvbiBkaXNwYXJpdGllcy4gUmVnaW9ucyBzYXZlZCBhdCBkaWZmZXJpbmcgcXVhbGl0eSBsZXZlbHMgZmx1b3Jlc2NlIGFzIGJyaWdodCBjeWFuL21hZ2VudGEgY29udG91cnMuJ31cbiAgICAgICAgICAgICAgICB7ZmlsdGVyTW9kZSA9PT0gJ2hpZ2hwYXNzJyAmJiAhaXNTcGxpdEFjdGl2ZSAmJiAnSGlnaC1wYXNzIGZpbHRlciBpc29sYXRlcyBtaWNyby1lZGdlIGdyYWRpZW50cyBhbmQgc2Vuc29yIG5vaXNlIGdyYWluLCBleHBvc2luZyBibHVycmVkIGdlbmVyYXRpdmUgdHJhbnNpdGlvbnMuJ31cbiAgICAgICAgICAgICAgICB7ZmlsdGVyTW9kZSA9PT0gJ2x1bWluYW5jZScgJiYgIWlzU3BsaXRBY3RpdmUgJiYgJ1BzZXVkb2NvbG9yIGx1bWluYW5jZSBmYWxzZS1jb2xvciBtYXBwaW5nIHJldmVhbHMgdW5uYXR1cmFsIGxpZ2h0aW5nIGZhbGxvZmYgZ3JhZGllbnRzIGFuZCBzcGVjdWxhciBkaXNjb250aW51aXRpZXMuJ31cbiAgICAgICAgICAgICAgICB7aXNTcGxpdEFjdGl2ZSAmJiAnU3BsaXQgd2lwZSBtb2RlOiBEcmFnIGhvcml6b250YWxseSBhY3Jvc3MgdGhlIGltYWdlIHRvIGV2YWx1YXRlIGRpZmZlcmVuY2VzIGJldHdlZW4gb3JpZ2luYWwgcGhvdG8gYW5kIHRoZSBFTEEgY29tcHJlc3Npb24gbWF0cml4Lid9XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQ29udGFpbmVyIE1ldGFkYXRhIEJyZWFrZG93biBDYXJkICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTN4bCBib3JkZXIgYm9yZGVyLXdoaXRlL1swLjA4XSBiZy1bIzA1MDgxNl0gcC02IGJhY2tkcm9wLWJsdXItMnhsIHNoYWRvdy14bFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtMzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgIDxGaWxlQ29kZSBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtY3lhbi00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+TWV0YWRhdGEgJiBDb250YWluZXIgVGVsZW1ldHJ5PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LVsxMHB4XSBmb250LW1vbm8gcHgtMi41IHB5LTEgcm91bmRlZC1tZCBmb250LXNlbWlib2xkICR7cmVzdWx0Lm1ldGFkYXRhLmhhc0V4aWYgPyAnYmctZW1lcmFsZC01MDAvMjAgdGV4dC1lbWVyYWxkLTMwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwJyA6ICdiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS00MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAnfWB9PlxuICAgICAgICAgICAgICAgICAge3Jlc3VsdC5tZXRhZGF0YS5oYXNFeGlmID8gJ0VYSUYgSW50YWN0JyA6ICdObyBIYXJkd2FyZSBFWElGJ31cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBzbTpncmlkLWNvbHMtMyBnYXAtMy41IHRleHQteHMgZm9udC1tb25vIHB0LTFcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLXhsIGJnLXdoaXRlL1swLjAyXSBib3JkZXIgYm9yZGVyLXdoaXRlL1swLjA0XVwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2VcIj5DYW1lcmEgTWFrZTwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIGZvbnQtc2VtaWJvbGQgdHJ1bmNhdGUgbXQtMVwiPntyZXN1bHQubWV0YWRhdGEuY2FtZXJhTWFrZSB8fCAnTi9BIChTeW50aGV0aWMpJ308L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQteGwgYmctd2hpdGUvWzAuMDJdIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMDRdXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZVwiPkNhbWVyYSBNb2RlbDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIGZvbnQtc2VtaWJvbGQgdHJ1bmNhdGUgbXQtMVwiPntyZXN1bHQubWV0YWRhdGEuY2FtZXJhTW9kZWwgfHwgJ04vQSd9PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLXhsIGJnLXdoaXRlL1swLjAyXSBib3JkZXIgYm9yZGVyLXdoaXRlL1swLjA0XVwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2VcIj5FeHBvc3VyZSAvIElTTzwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIGZvbnQtc2VtaWJvbGQgdHJ1bmNhdGUgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICB7cmVzdWx0Lm1ldGFkYXRhLmlzbyA/IGBJU08gJHtyZXN1bHQubWV0YWRhdGEuaXNvfSDCtyAke3Jlc3VsdC5tZXRhZGF0YS5mTnVtYmVyIHx8ICcnfWAgOiAnTm9uZSBSZWNvcmRlZCd9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQteGwgYmctd2hpdGUvWzAuMDJdIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMDRdXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZVwiPkRpbWVuc2lvbnM8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBmb250LXNlbWlib2xkIG10LTEgdGFidWxhci1udW1zXCI+XG4gICAgICAgICAgICAgICAgICAgIHtyZXN1bHQubWV0YWRhdGEuZGltZW5zaW9ucy53aWR0aH0gw5cge3Jlc3VsdC5tZXRhZGF0YS5kaW1lbnNpb25zLmhlaWdodH1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC14bCBiZy13aGl0ZS9bMC4wMl0gYm9yZGVyIGJvcmRlci13aGl0ZS9bMC4wNF1cIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlXCI+QzJQQSBNYW5pZmVzdDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2Bmb250LXNlbWlib2xkIG10LTEgJHtyZXN1bHQubWV0YWRhdGEuYzJwYVByZXNlbnQgPyAndGV4dC1lbWVyYWxkLTQwMCcgOiAndGV4dC1zbGF0ZS00MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICB7cmVzdWx0Lm1ldGFkYXRhLmMycGFQcmVzZW50ID8gJ0NyeXB0b2dyYXBoaWNhbGx5IFNpZ25lZCcgOiAnTm90IFByZXNlbnQnfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLXhsIGJnLXdoaXRlL1swLjAyXSBib3JkZXIgYm9yZGVyLXdoaXRlL1swLjA0XVwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2VcIj5Tb2Z0d2FyZSBUYWc8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHRydW5jYXRlIG10LTFcIiB0aXRsZT17cmVzdWx0Lm1ldGFkYXRhLnNvZnR3YXJlIHx8ICdOb25lJ30+XG4gICAgICAgICAgICAgICAgICAgIHtyZXN1bHQubWV0YWRhdGEuc29mdHdhcmUgfHwgJ1N0YW5kYXJkIEJ1ZmZlcid9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFJpZ2h0IENvbHVtbjogRm9yZW5zaWMgSW5kaWNhdG9ycyAmIERlZXAgRGV0YWlscyAoNSBjb2xzKSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTUgc3BhY2UteS01XCI+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0zeGwgYm9yZGVyIGJvcmRlci13aGl0ZS9bMC4wOF0gYmctWyMwNTA4MTZdIHAtNiBiYWNrZHJvcC1ibHVyLTJ4bCBzaGFkb3cteGxcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICA8QWN0aXZpdHkgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWN5YW4tNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPlBvdGVudGlhbCBTeW50aGV0aWMgSW5kaWNhdG9yczwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgIHtyZXN1bHQuaW5kaWNhdG9ycy5sZW5ndGh9IHZlY3RvcnNcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBBY2NvcmRpb24gTGlzdCBvZiBJbmRpY2F0b3JzICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMy41XCI+XG4gICAgICAgICAgICAgICAge3Jlc3VsdC5pbmRpY2F0b3JzLm1hcCgoaW5kKSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBpc0V4cGFuZGVkID0gZXhwYW5kZWRJbmRpY2F0b3IgPT09IGluZC5pZDtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHNldmVyaXR5QmFkZ2UgPVxuICAgICAgICAgICAgICAgICAgICBpbmQuc2V2ZXJpdHkgPT09ICdoaWdoJ1xuICAgICAgICAgICAgICAgICAgICAgID8gJ3RleHQtcm9zZS00MDAgYmctcm9zZS01MDAvMTAgYm9yZGVyLXJvc2UtNTAwLzMwJ1xuICAgICAgICAgICAgICAgICAgICAgIDogaW5kLnNldmVyaXR5ID09PSAnbWVkaXVtJ1xuICAgICAgICAgICAgICAgICAgICAgID8gJ3RleHQtYW1iZXItNDAwIGJnLWFtYmVyLTUwMC8xMCBib3JkZXItYW1iZXItNTAwLzMwJ1xuICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtZW1lcmFsZC00MDAgYmctZW1lcmFsZC01MDAvMTAgYm9yZGVyLWVtZXJhbGQtNTAwLzMwJztcblxuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgIGtleT17aW5kLmlkfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMDZdIGJnLXdoaXRlL1swLjAyXSBob3ZlcjpiZy13aGl0ZS9bMC4wNF0gdHJhbnNpdGlvbi1hbGwgb3ZlcmZsb3ctaGlkZGVuXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEV4cGFuZGVkSW5kaWNhdG9yKGlzRXhwYW5kZWQgPyBudWxsIDogaW5kLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcC00IHRleHQtbGVmdCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNSBwci0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LVsxMHB4XSBmb250LW1vbm8gZm9udC1ib2xkIHB4LTIuNSBweS0wLjUgcm91bmRlZC1tZCBib3JkZXIgdXBwZXJjYXNlICR7c2V2ZXJpdHlCYWRnZX1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpbmQuc2V2ZXJpdHl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2luZC5jYXRlZ29yeX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpbmQudGl0bGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1jeWFuLTQwMCB0YWJ1bGFyLW51bXNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aW5kLmNvbmZpZGVuY2V9JVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0V4cGFuZGVkID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uVXAgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LXNsYXRlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25Eb3duIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1zbGF0ZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7aXNFeHBhbmRlZCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTQgcGItNCBwdC0xIGJvcmRlci10IGJvcmRlci13aGl0ZS9bMC4wNF0gc3BhY2UteS0zIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2luZC5kZXNjcmlwdGlvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLXhsIGJnLWJsYWNrLzYwIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMDZdIHRleHQtY3lhbi0zMDAgZm9udC1tb25vIHRleHQtWzExcHhdIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSB1cHBlcmNhc2UgdGV4dC1bOXB4XSBibG9jayBtYi0xXCI+Rm9yZW5zaWMgVGVsZW1ldHJ5Ojwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpbmQudGVjaG5pY2FsRGV0YWlsc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBWZXJkaWN0IFJhdGlvbmFsZSBDYXJkICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgcC00IHJvdW5kZWQtMnhsIGJnLXdoaXRlL1swLjAyXSBib3JkZXIgYm9yZGVyLXdoaXRlL1swLjA2XSBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtbW9ubyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgQ29tcHJlaGVuc2l2ZSBWZXJkaWN0IFJhdGlvbmFsZVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS0zMDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICB7cmVzdWx0LnZlcmRpY3RSYXRpb25hbGV9XG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogVW5jZXJ0YWludHkgRXhwbGFuYXRpb24gKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBwLTQgcm91bmRlZC0yeGwgYmctYW1iZXItOTUwLzIwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzI1IHNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1hbWJlci0zMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxBbGVydENpcmNsZSBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPlVuZGVyc3RhbmRpbmcgRGV0ZWN0aW9uIFVuY2VydGFpbnR5PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1hbWJlci0yMDAvODAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICBQb3N0LXByb2Nlc3NpbmcsIGxvc3N5IGNvbXByZXNzaW9uIHRyYW5zY29kaW5nLCBhbmQgY2FtZXJhIGZpbHRlcnMgY2FuIG9ic2N1cmUgZmluZSBzZW5zb3IgZ3JhaW4uIEFsbCBtZXRyaWNzIGluZGljYXRlIHByb2JhYmlsaXN0aWMgaGV1cmlzdGljIGNvcnJlbGF0aW9uIHJhdGhlciB0aGFuIGluZmFsbGlibGUgbGVnYWwgcHJvb2YuXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogQWN0aW9uIEJ1dHRvbnM6IEV4cG9ydCAmIEFuYWx5emUgQW5vdGhlciAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IHB0LTUgYm9yZGVyLXQgYm9yZGVyLXdoaXRlL1swLjA4XSBmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uQW5hbHl6ZUFub3RoZXJ9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgc206ZmxleC0xIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBweC00IHB5LTMgdGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSBiZy13aGl0ZS9bMC4wNl0gaG92ZXI6Ymctd2hpdGUvWzAuMTJdIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMV0gcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBhY3RpdmU6c2NhbGUtOTVcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxSb3RhdGVDY3cgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWN5YW4tNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPkFuYWx5emUgQW5vdGhlciBGaWxlPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRXhwb3J0SlNPTn1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBzbTp3LWF1dG8gaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgcHgtNCBweS0zIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS0yMDAgaG92ZXI6dGV4dC13aGl0ZSBiZy13aGl0ZS9bMC4wNF0gaG92ZXI6Ymctd2hpdGUvWzAuMDhdIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMDhdIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEb3dubG9hZCBKU09OIFJlcG9ydFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1jeWFuLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5FeHBvcnQgSlNPTjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNvcHlSZXBvcnR9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgc206dy1hdXRvIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IHB4LTQgcHktMyB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtMjAwIGhvdmVyOnRleHQtd2hpdGUgYmctd2hpdGUvWzAuMDRdIGhvdmVyOmJnLXdoaXRlL1swLjA4XSBib3JkZXIgYm9yZGVyLXdoaXRlL1swLjA4XSByb3VuZGVkLXhsIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQ29weSBSZXBvcnQgU3VtbWFyeVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFNoYXJlMiBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtY3lhbi00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+e2NvcGllZE5vdGlmaWNhdGlvbiA/ICdDb3BpZWQhJyA6ICdDb3B5J308L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDwvZGl2PlxuXG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59O1xuIl19