const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4c5f34d3";
import { Upload, Image as ImageIcon, Video as VideoIcon, X, AlertCircle, Play, Pause, Sparkles, Info, FileCheck2, Grid } from "/node_modules/.vite/deps/lucide-react.js?v=4c5f34d3";
import { SAMPLE_MEDIA_ITEMS } from "/src/utils/sampleData.ts";
import { analyzeUploadedMedia } from "/src/utils/analyzer.ts";
var _jsxFileName = "/app/applet/src/components/MediaUploadSection.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4c5f34d3";
export const MediaUploadSection = ({ onAnalysisComplete, isAnalyzing, setIsAnalyzing }) => {
	const [activeTab, setActiveTab] = useState("image");
	const [selectedFile, setSelectedFile] = useState(null);
	const [previewUrl, setPreviewUrl] = useState(null);
	const [errorMessage, setErrorMessage] = useState(null);
	const [isDragOver, setIsDragOver] = useState(false);
	const [showGridOverlay, setShowGridOverlay] = useState(false);
	// Video playback state
	const [isPlaying, setIsPlaying] = useState(false);
	const [videoDuration, setVideoDuration] = useState(0);
	const [videoCurrentTime, setVideoCurrentTime] = useState(0);
	const videoRef = useRef(null);
	// Analysis progress
	const [scanStep, setScanStep] = useState("");
	const [scanPercent, setScanPercent] = useState(0);
	const fileInputRef = useRef(null);
	const imageAccept = ".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp";
	const videoAccept = ".mp4,.mov,.webm,video/mp4,video/quicktime,video/webm";
	const validateAndSetFile = (file) => {
		setErrorMessage(null);
		const isImg = file.type.startsWith("image/") || /\.(jpg|jpeg|png|webp)$/i.test(file.name);
		const isVid = file.type.startsWith("video/") || /\.(mp4|mov|webm)$/i.test(file.name);
		if (activeTab === "image" && !isImg) {
			setErrorMessage("Please select a valid image file (JPG, JPEG, PNG, or WEBP).");
			return;
		}
		if (activeTab === "video" && !isVid) {
			setErrorMessage("Please select a valid video file (MP4, MOV, or WEBM).");
			return;
		}
		const maxImgSize = 25 * 1024 * 1024;
		const maxVidSize = 60 * 1024 * 1024;
		if (isImg && file.size > maxImgSize) {
			setErrorMessage("Image size exceeds 25MB limit. Please upload a smaller file.");
			return;
		}
		if (isVid && file.size > maxVidSize) {
			setErrorMessage("Video size exceeds 60MB limit. Please upload a shorter or compressed clip.");
			return;
		}
		setSelectedFile(file);
		const objectUrl = URL.createObjectURL(file);
		setPreviewUrl(objectUrl);
	};
	const handleDrop = useCallback((e) => {
		e.preventDefault();
		setIsDragOver(false);
		if (e.dataTransfer.files && e.dataTransfer.files[0]) {
			validateAndSetFile(e.dataTransfer.files[0]);
		}
	}, [activeTab]);
	const handleFileChange = (e) => {
		if (e.target.files && e.target.files[0]) {
			validateAndSetFile(e.target.files[0]);
		}
	};
	const handleRemoveFile = () => {
		setSelectedFile(null);
		if (previewUrl && !previewUrl.startsWith("http")) {
			URL.revokeObjectURL(previewUrl);
		}
		setPreviewUrl(null);
		setErrorMessage(null);
		setIsPlaying(false);
		if (fileInputRef.current) fileInputRef.current.value = "";
	};
	const handleSelectSample = (sample) => {
		setActiveTab(sample.type);
		setSelectedFile(null);
		setPreviewUrl(sample.previewUrl);
		setErrorMessage(null);
		onAnalysisComplete({
			result: sample.mockResult,
			previewUrl: sample.previewUrl
		});
		const el = document.getElementById("results-dashboard");
		if (el) el.scrollIntoView({ behavior: "smooth" });
	};
	const handleStartAnalysis = async () => {
		if (!selectedFile && !previewUrl) return;
		setIsAnalyzing(true);
		setScanStep("Initializing forensic scan sequence...");
		setScanPercent(6);
		try {
			if (selectedFile && previewUrl) {
				const progressHandler = (step, percent) => {
					setScanStep(step);
					setScanPercent(percent);
				};
				const analysisOutput = await analyzeUploadedMedia(selectedFile, previewUrl, progressHandler);
				onAnalysisComplete({
					result: analysisOutput.result,
					previewUrl,
					elaUrl: analysisOutput.elaUrl,
					highpassUrl: analysisOutput.highpassUrl,
					luminanceUrl: analysisOutput.luminanceUrl
				});
			}
		} catch (err) {
			setErrorMessage(err?.message || "Analysis encountered an error during scan.");
		} finally {
			setIsAnalyzing(false);
			const el = document.getElementById("results-dashboard");
			if (el) el.scrollIntoView({ behavior: "smooth" });
		}
	};
	// Video playback
	const togglePlay = () => {
		if (!videoRef.current) return;
		if (isPlaying) {
			videoRef.current.pause();
			setIsPlaying(false);
		} else {
			videoRef.current.play();
			setIsPlaying(true);
		}
	};
	const handleTimeUpdate = () => {
		if (videoRef.current) {
			setVideoCurrentTime(videoRef.current.currentTime);
		}
	};
	const handleLoadedMetadata = () => {
		if (videoRef.current) {
			setVideoDuration(videoRef.current.duration);
		}
	};
	const handleSeek = (e) => {
		const time = parseFloat(e.target.value);
		setVideoCurrentTime(time);
		if (videoRef.current) {
			videoRef.current.currentTime = time;
		}
	};
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "analyze",
		className: "relative scroll-mt-20 py-20 px-6 lg:px-8 border-t border-white/[0.08] bg-[#020409]",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "mx-auto max-w-6xl",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "text-center max-w-2xl mx-auto mb-12",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "text-xs font-mono text-cyan-400 uppercase tracking-wider mb-2",
						children: "Forensic Inspection Studio"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 209,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-3xl sm:text-4xl font-extrabold text-white tracking-tight [text-wrap:balance]",
						children: "Analyze Media for Synthetic Signals"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 212,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-3 text-sm sm:text-base text-slate-400",
						children: "Upload images or videos to inspect multi-vector forensic indicators, compression heatmaps, and container provenance."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 215,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-5 inline-flex items-center gap-2.5 px-4 py-2 rounded-xl bg-cyan-950/40 border border-cyan-500/25 text-cyan-200 text-xs text-left backdrop-blur-md",
						children: [/* @__PURE__ */ _jsxDEV(Info, { className: "h-4 w-4 shrink-0 text-cyan-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 221,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", {
							className: "text-white font-semibold",
							children: "Inspection Pipeline (Demonstration Mode)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 223,
							columnNumber: 15
						}, this), ": Analyzes container metadata, spatial Discrete Cosine Transform (DCT) quantization, and physical noise profiles."] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 222,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 220,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 208,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-3xl border border-white/[0.08] bg-[#050816]/90 backdrop-blur-2xl p-6 sm:p-8 shadow-[0_0_50px_rgba(0,0,0,0.5)]",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between flex-wrap gap-4 border-b border-white/[0.08] pb-6 mb-6",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1.5 p-1 bg-white/[0.04] rounded-xl border border-white/[0.06]",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									setActiveTab("image");
									handleRemoveFile();
								},
								className: `flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${activeTab === "image" ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm" : "text-slate-400 hover:text-white"}`,
								children: [/* @__PURE__ */ _jsxDEV(ImageIcon, { className: "h-4 w-4 text-cyan-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 245,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Image Inspection (JPG, PNG, WEBP)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 246,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 234,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									setActiveTab("video");
									handleRemoveFile();
								},
								className: `flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${activeTab === "video" ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm" : "text-slate-400 hover:text-white"}`,
								children: [/* @__PURE__ */ _jsxDEV(VideoIcon, { className: "h-4 w-4 text-violet-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 260,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Video Inspection (MP4, MOV, WEBM)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 261,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 249,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 233,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "text-xs text-slate-400 font-mono",
							children: ["Container Limit: ", activeTab === "image" ? "25 MB" : "60 MB"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 265,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 232,
						columnNumber: 11
					}, this),
					errorMessage && /* @__PURE__ */ _jsxDEV("div", {
						className: "mb-6 flex items-center gap-3 rounded-xl bg-rose-950/60 border border-rose-500/40 p-4 text-sm text-rose-200",
						children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "h-5 w-5 shrink-0 text-rose-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 273,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", { children: errorMessage }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 274,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 272,
						columnNumber: 13
					}, this),
					!previewUrl ? /* @__PURE__ */ _jsxDEV("div", {
						onDragOver: (e) => {
							e.preventDefault();
							setIsDragOver(true);
						},
						onDragLeave: () => setIsDragOver(false),
						onDrop: handleDrop,
						onClick: () => fileInputRef.current?.click(),
						className: `relative flex flex-col items-center justify-center rounded-2xl border-2 border-dashed p-10 sm:p-16 text-center cursor-pointer transition-all overflow-hidden ${isDragOver ? "border-cyan-400 bg-cyan-950/30 scale-[0.99] shadow-[0_0_30px_rgba(6,182,212,0.25)]" : "border-white/[0.12] hover:border-cyan-500/40 bg-white/[0.015] hover:bg-white/[0.03]"}`,
						children: [
							/* @__PURE__ */ _jsxDEV("input", {
								ref: fileInputRef,
								type: "file",
								accept: activeTab === "image" ? imageAccept : videoAccept,
								onChange: handleFileChange,
								className: "hidden"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 294,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { className: "absolute top-3 left-3 w-4 h-4 border-t-2 border-l-2 border-cyan-500/40" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 303,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { className: "absolute top-3 right-3 w-4 h-4 border-t-2 border-r-2 border-cyan-500/40" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 304,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { className: "absolute bottom-3 left-3 w-4 h-4 border-b-2 border-l-2 border-cyan-500/40" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 305,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { className: "absolute bottom-3 right-3 w-4 h-4 border-b-2 border-r-2 border-cyan-500/40" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 306,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex h-16 w-16 items-center justify-center rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 mb-4 group-hover:scale-105 transition-transform shadow-[0_0_20px_rgba(6,182,212,0.15)]",
								children: /* @__PURE__ */ _jsxDEV(Upload, { className: "h-8 w-8" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 309,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 308,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-lg font-semibold text-white",
								children: [
									"Drag and drop your ",
									activeTab,
									" here, or ",
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-cyan-400 underline underline-offset-4",
										children: "browse files"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 313,
										columnNumber: 57
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 312,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "mt-2 text-xs text-slate-400 max-w-sm",
								children: [
									"Supported formats: ",
									activeTab === "image" ? "JPG, JPEG, PNG, WEBP" : "MP4, MOV, WEBM",
									". All file processing stays private in your browser session."
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 315,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mt-6 flex items-center gap-2 text-[11px] font-mono text-slate-500",
								children: [
									/* @__PURE__ */ _jsxDEV("span", { children: "Deterministic hashing" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 321,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "·" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 322,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "EXIF parsing" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 323,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "·" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 324,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "Zero data retention" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 325,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 320,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 280,
						columnNumber: 13
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-6",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "relative rounded-2xl border border-white/[0.1] bg-black/70 overflow-hidden flex flex-col items-center justify-center min-h-[340px] max-h-[540px]",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "absolute top-4 right-4 z-20 flex items-center gap-2",
										children: [activeTab === "image" && /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setShowGridOverlay(!showGridOverlay),
											className: `flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono transition-colors backdrop-blur-md border ${showGridOverlay ? "bg-cyan-500/30 border-cyan-400 text-cyan-200" : "bg-black/70 border-white/15 text-slate-300 hover:text-white"}`,
											title: "Toggle grid overlay",
											children: [/* @__PURE__ */ _jsxDEV(Grid, { className: "h-3.5 w-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 345,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Grid" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 346,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 336,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: handleRemoveFile,
											disabled: isAnalyzing,
											className: "flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-black/80 hover:bg-rose-950/80 border border-white/20 hover:border-rose-500/50 text-xs text-slate-200 hover:text-rose-200 transition-colors backdrop-blur-md cursor-pointer",
											children: [/* @__PURE__ */ _jsxDEV(X, { className: "h-4 w-4" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 355,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Remove File" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 356,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 350,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 334,
										columnNumber: 17
									}, this),
									activeTab === "image" && /* @__PURE__ */ _jsxDEV("div", {
										className: "relative w-full h-full max-h-[500px] flex items-center justify-center p-4",
										children: [/* @__PURE__ */ _jsxDEV("img", {
											src: previewUrl,
											alt: "Uploaded media preview",
											className: "max-h-[460px] max-w-full rounded-xl object-contain shadow-2xl"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 363,
											columnNumber: 21
										}, this), showGridOverlay && /* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0 pointer-events-none cyber-grid-pattern opacity-40" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 371,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 362,
										columnNumber: 19
									}, this),
									activeTab === "video" && /* @__PURE__ */ _jsxDEV("div", {
										className: "relative w-full h-full flex flex-col items-center justify-center",
										children: [/* @__PURE__ */ _jsxDEV("video", {
											ref: videoRef,
											src: previewUrl,
											onTimeUpdate: handleTimeUpdate,
											onLoadedMetadata: handleLoadedMetadata,
											onEnded: () => setIsPlaying(false),
											className: "max-h-[440px] w-full object-contain"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 379,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "w-full bg-slate-950/95 border-t border-white/[0.1] p-3.5 flex items-center gap-4 z-10 backdrop-blur-md",
											children: [
												/* @__PURE__ */ _jsxDEV("button", {
													onClick: togglePlay,
													className: "p-2 rounded-lg bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 transition-colors cursor-pointer",
													"aria-label": isPlaying ? "Pause video" : "Play video",
													children: isPlaying ? /* @__PURE__ */ _jsxDEV(Pause, { className: "h-4 w-4" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 395,
														columnNumber: 38
													}, this) : /* @__PURE__ */ _jsxDEV(Play, { className: "h-4 w-4" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 395,
														columnNumber: 70
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 390,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("input", {
													type: "range",
													min: "0",
													max: videoDuration || 100,
													step: "0.05",
													value: videoCurrentTime,
													onChange: handleSeek,
													className: "flex-1 accent-cyan-400 cursor-pointer h-1.5 rounded-lg bg-slate-800"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 398,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "text-xs font-mono text-slate-300 shrink-0",
													children: [
														Math.floor(videoCurrentTime),
														"s / ",
														Math.floor(videoDuration),
														"s"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 408,
													columnNumber: 23
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 389,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 378,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 331,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-2xl bg-white/[0.03] border border-white/[0.08]",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 shrink-0",
										children: /* @__PURE__ */ _jsxDEV(FileCheck2, { className: "h-5 w-5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 420,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 419,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-xs",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "font-semibold text-white truncate max-w-xs sm:max-w-md",
											children: selectedFile ? selectedFile.name : "Benchmark Sample File Loaded"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 423,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-slate-400 font-mono mt-0.5",
											children: selectedFile ? `${(selectedFile.size / (1024 * 1024)).toFixed(2)} MB · ${selectedFile.type}` : "Ready for Forensic Evaluation"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 426,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 422,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 418,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleStartAnalysis,
									disabled: isAnalyzing,
									className: "w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-3.5 text-xs font-bold uppercase tracking-wider text-black bg-gradient-to-r from-cyan-400 via-cyan-300 to-teal-300 hover:from-cyan-300 hover:to-white rounded-xl shadow-[0_0_28px_rgba(6,182,212,0.35)] transition-all cursor-pointer disabled:opacity-50 active:scale-95",
									children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "h-4 w-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 439,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: isAnalyzing ? "Inspecting Signals..." : "Execute Forensic Analysis" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 440,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 434,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 417,
								columnNumber: 15
							}, this),
							isAnalyzing && /* @__PURE__ */ _jsxDEV("div", {
								className: "rounded-2xl border border-cyan-500/40 bg-cyan-950/30 p-6 space-y-4 backdrop-blur-xl shadow-[0_0_40px_rgba(6,182,212,0.15)]",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between text-xs font-mono",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-cyan-300 flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 449,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "font-semibold",
												children: scanStep
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 450,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 448,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-cyan-400 font-bold text-sm",
											children: [scanPercent, "%"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 452,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 447,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "w-full h-2 rounded-full bg-slate-900 overflow-hidden border border-cyan-500/30",
										children: /* @__PURE__ */ _jsxDEV("div", {
											className: "h-full bg-gradient-to-r from-cyan-400 via-teal-300 to-violet-400 transition-all duration-300",
											style: { width: `${scanPercent}%` }
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 456,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 455,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px] font-mono text-slate-400 pt-1",
										children: [
											/* @__PURE__ */ _jsxDEV("span", {
												className: scanPercent >= 20 ? "text-cyan-300 font-semibold" : "text-slate-600",
												children: "01. EXIF Integrity"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 463,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: scanPercent >= 45 ? "text-cyan-300 font-semibold" : "text-slate-600",
												children: "02. DCT Disparity"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 466,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: scanPercent >= 70 ? "text-cyan-300 font-semibold" : "text-slate-600",
												children: "03. Glare Vectors"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 469,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: scanPercent >= 90 ? "text-cyan-300 font-semibold" : "text-slate-600",
												children: "04. Uncertainty Model"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 472,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 462,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 446,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 329,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-10 pt-8 border-t border-white/[0.08]",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between mb-5 flex-wrap gap-2",
							children: /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-mono uppercase text-slate-300 tracking-wider font-semibold block",
								children: "Benchmark Sample Library — Instant Test Run"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 485,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-slate-500",
								children: "Select any pre-indexed media to evaluate forensic signals instantly"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 488,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 484,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 483,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
							children: SAMPLE_MEDIA_ITEMS.map((sample) => /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => handleSelectSample(sample),
								className: "group flex flex-col text-left p-3.5 rounded-2xl bg-white/[0.02] hover:bg-white/[0.05] border border-white/[0.06] hover:border-cyan-500/40 transition-all cursor-pointer relative overflow-hidden",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "relative aspect-video w-full rounded-xl overflow-hidden bg-slate-900 mb-3 border border-white/[0.06]",
										children: [/* @__PURE__ */ _jsxDEV("img", {
											src: sample.previewUrl,
											alt: sample.title,
											className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 502,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "absolute top-2 left-2 text-[10px] font-mono px-2 py-0.5 rounded-md bg-black/80 border border-white/10 text-cyan-300 backdrop-blur-md",
											children: sample.type.toUpperCase()
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 507,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 501,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between gap-1 mb-1.5",
										children: /* @__PURE__ */ _jsxDEV("h4", {
											className: "text-xs font-bold text-white group-hover:text-cyan-300 transition-colors truncate",
											children: sample.title
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 513,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 512,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-400 line-clamp-2 leading-relaxed",
										children: sample.description
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 518,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "mt-4 pt-2.5 border-t border-white/[0.04] flex items-center justify-between text-[10px] font-mono",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: sample.badge === "Likely AI-generated" ? "text-rose-400 font-semibold" : sample.badge === "Likely authentic" ? "text-emerald-400 font-semibold" : "text-amber-400 font-semibold",
											children: sample.badge
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 523,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-cyan-400 group-hover:underline flex items-center gap-1 font-semibold",
											children: "Inspect →"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 532,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 522,
										columnNumber: 19
									}, this)
								]
							}, sample.id, true, {
								fileName: _jsxFileName,
								lineNumber: 496,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 494,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 482,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 229,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 205,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 204,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsUUFBUSxtQkFBbUI7QUFDckQsU0FDRSxRQUNBLFNBQVMsV0FDVCxTQUFTLFdBQ1QsR0FDQSxhQUNBLE1BQ0EsT0FFQSxVQUNBLE1BRUEsWUFJQSxZQUNLO0FBQ1AsU0FBUywwQkFBMEI7QUFDbkMsU0FBbUMsNEJBQTRCOzs7QUFlL0QsT0FBTyxNQUFNLHNCQUF5RCxFQUNwRSxvQkFDQSxhQUNBLHFCQUNJO0NBQ0osTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQTRCLE9BQU87Q0FDckUsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQXNCLElBQUk7Q0FDbEUsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQXdCLElBQUk7Q0FDaEUsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQXdCLElBQUk7Q0FDcEUsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsS0FBSztDQUNsRCxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLEtBQUs7O0NBRzVELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEtBQUs7Q0FDaEQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsQ0FBQztDQUNwRCxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFTLENBQUM7Q0FDMUQsTUFBTSxXQUFXLE9BQWdDLElBQUk7O0NBR3JELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBaUIsRUFBRTtDQUNuRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBaUIsQ0FBQztDQUV4RCxNQUFNLGVBQWUsT0FBZ0MsSUFBSTtDQUV6RCxNQUFNLGNBQWM7Q0FDcEIsTUFBTSxjQUFjO0NBRXBCLE1BQU0sc0JBQXNCLFNBQWU7RUFDekMsZ0JBQWdCLElBQUk7RUFFcEIsTUFBTSxRQUFRLEtBQUssS0FBSyxXQUFXLFFBQVEsS0FBSywwQkFBMEIsS0FBSyxLQUFLLElBQUk7RUFDeEYsTUFBTSxRQUFRLEtBQUssS0FBSyxXQUFXLFFBQVEsS0FBSyxxQkFBcUIsS0FBSyxLQUFLLElBQUk7RUFFbkYsSUFBSSxjQUFjLFdBQVcsQ0FBQyxPQUFPO0dBQ25DLGdCQUFnQiw2REFBNkQ7R0FDN0U7RUFDRjtFQUNBLElBQUksY0FBYyxXQUFXLENBQUMsT0FBTztHQUNuQyxnQkFBZ0IsdURBQXVEO0dBQ3ZFO0VBQ0Y7RUFFQSxNQUFNLGFBQWEsS0FBSyxPQUFPO0VBQy9CLE1BQU0sYUFBYSxLQUFLLE9BQU87RUFFL0IsSUFBSSxTQUFTLEtBQUssT0FBTyxZQUFZO0dBQ25DLGdCQUFnQiw4REFBOEQ7R0FDOUU7RUFDRjtFQUNBLElBQUksU0FBUyxLQUFLLE9BQU8sWUFBWTtHQUNuQyxnQkFBZ0IsNEVBQTRFO0dBQzVGO0VBQ0Y7RUFFQSxnQkFBZ0IsSUFBSTtFQUNwQixNQUFNLFlBQVksSUFBSSxnQkFBZ0IsSUFBSTtFQUMxQyxjQUFjLFNBQVM7Q0FDekI7Q0FFQSxNQUFNLGFBQWEsYUFDaEIsTUFBdUM7RUFDdEMsRUFBRSxlQUFlO0VBQ2pCLGNBQWMsS0FBSztFQUNuQixJQUFJLEVBQUUsYUFBYSxTQUFTLEVBQUUsYUFBYSxNQUFNLElBQUk7R0FDbkQsbUJBQW1CLEVBQUUsYUFBYSxNQUFNLEVBQUU7RUFDNUM7Q0FDRixHQUNBLENBQUMsU0FBUyxDQUNaO0NBRUEsTUFBTSxvQkFBb0IsTUFBMkM7RUFDbkUsSUFBSSxFQUFFLE9BQU8sU0FBUyxFQUFFLE9BQU8sTUFBTSxJQUFJO0dBQ3ZDLG1CQUFtQixFQUFFLE9BQU8sTUFBTSxFQUFFO0VBQ3RDO0NBQ0Y7Q0FFQSxNQUFNLHlCQUF5QjtFQUM3QixnQkFBZ0IsSUFBSTtFQUNwQixJQUFJLGNBQWMsQ0FBQyxXQUFXLFdBQVcsTUFBTSxHQUFHO0dBQ2hELElBQUksZ0JBQWdCLFVBQVU7RUFDaEM7RUFDQSxjQUFjLElBQUk7RUFDbEIsZ0JBQWdCLElBQUk7RUFDcEIsYUFBYSxLQUFLO0VBQ2xCLElBQUksYUFBYSxTQUFTLGFBQWEsUUFBUSxRQUFRO0NBQ3pEO0NBRUEsTUFBTSxzQkFBc0IsV0FBd0I7RUFDbEQsYUFBYSxPQUFPLElBQUk7RUFDeEIsZ0JBQWdCLElBQUk7RUFDcEIsY0FBYyxPQUFPLFVBQVU7RUFDL0IsZ0JBQWdCLElBQUk7RUFFcEIsbUJBQW1CO0dBQ2pCLFFBQVEsT0FBTztHQUNmLFlBQVksT0FBTztFQUNyQixDQUFDO0VBRUQsTUFBTSxLQUFLLFNBQVMsZUFBZSxtQkFBbUI7RUFDdEQsSUFBSSxJQUFJLEdBQUcsZUFBZSxFQUFFLFVBQVUsU0FBUyxDQUFDO0NBQ2xEO0NBRUEsTUFBTSxzQkFBc0IsWUFBWTtFQUN0QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWTtFQUVsQyxlQUFlLElBQUk7RUFDbkIsWUFBWSx3Q0FBd0M7RUFDcEQsZUFBZSxDQUFDO0VBRWhCLElBQUk7R0FDRixJQUFJLGdCQUFnQixZQUFZO0lBQzlCLE1BQU0sbUJBQTZDLE1BQU0sWUFBWTtLQUNuRSxZQUFZLElBQUk7S0FDaEIsZUFBZSxPQUFPO0lBQ3hCO0lBRUEsTUFBTSxpQkFBaUIsTUFBTSxxQkFBcUIsY0FBYyxZQUFZLGVBQWU7SUFFM0YsbUJBQW1CO0tBQ2pCLFFBQVEsZUFBZTtLQUN2QjtLQUNBLFFBQVEsZUFBZTtLQUN2QixhQUFhLGVBQWU7S0FDNUIsY0FBYyxlQUFlO0lBQy9CLENBQUM7R0FDSDtFQUNGLFNBQVMsS0FBVTtHQUNqQixnQkFBZ0IsS0FBSyxXQUFXLDRDQUE0QztFQUM5RSxVQUFVO0dBQ1IsZUFBZSxLQUFLO0dBQ3BCLE1BQU0sS0FBSyxTQUFTLGVBQWUsbUJBQW1CO0dBQ3RELElBQUksSUFBSSxHQUFHLGVBQWUsRUFBRSxVQUFVLFNBQVMsQ0FBQztFQUNsRDtDQUNGOztDQUdBLE1BQU0sbUJBQW1CO0VBQ3ZCLElBQUksQ0FBQyxTQUFTLFNBQVM7RUFDdkIsSUFBSSxXQUFXO0dBQ2IsU0FBUyxRQUFRLE1BQU07R0FDdkIsYUFBYSxLQUFLO0VBQ3BCLE9BQU87R0FDTCxTQUFTLFFBQVEsS0FBSztHQUN0QixhQUFhLElBQUk7RUFDbkI7Q0FDRjtDQUVBLE1BQU0seUJBQXlCO0VBQzdCLElBQUksU0FBUyxTQUFTO0dBQ3BCLG9CQUFvQixTQUFTLFFBQVEsV0FBVztFQUNsRDtDQUNGO0NBRUEsTUFBTSw2QkFBNkI7RUFDakMsSUFBSSxTQUFTLFNBQVM7R0FDcEIsaUJBQWlCLFNBQVMsUUFBUSxRQUFRO0VBQzVDO0NBQ0Y7Q0FFQSxNQUFNLGNBQWMsTUFBMkM7RUFDN0QsTUFBTSxPQUFPLFdBQVcsRUFBRSxPQUFPLEtBQUs7RUFDdEMsb0JBQW9CLElBQUk7RUFDeEIsSUFBSSxTQUFTLFNBQVM7R0FDcEIsU0FBUyxRQUFRLGNBQWM7RUFDakM7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLElBQUc7RUFBVSxXQUFVO1lBQzlCLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FHRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWdFO0tBRTFFOzs7OztLQUNMLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFvRjtLQUU5Rjs7Ozs7S0FDSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBMkM7S0FFckQ7Ozs7O0tBR0gsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxpQ0FBa0M7Ozs7Z0JBQ2xELHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxVQUFEO09BQVEsV0FBVTtpQkFBMkI7TUFBZ0Q7Ozs7Z0JBQUMsbUhBQzNGOzs7O2NBQ0Y7Ozs7OztJQUNGOzs7OzthQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FHRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRDtRQUNFLGVBQWU7U0FDYixhQUFhLE9BQU87U0FDcEIsaUJBQWlCO1FBQ25CO1FBQ0EsV0FBVyxvR0FDVCxjQUFjLFVBQ1YscUVBQ0E7a0JBUlIsQ0FXRSx3QkFBQyxXQUFELEVBQVcsV0FBVSx3QkFBeUI7Ozs7a0JBQzlDLHdCQUFDLFFBQUQsWUFBTSxvQ0FBdUM7Ozs7Z0JBQ3ZDOzs7OztpQkFFUix3QkFBQyxVQUFEO1FBQ0UsZUFBZTtTQUNiLGFBQWEsT0FBTztTQUNwQixpQkFBaUI7UUFDbkI7UUFDQSxXQUFXLG9HQUNULGNBQWMsVUFDVixxRUFDQTtrQkFSUixDQVdFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLDBCQUEyQjs7OztrQkFDaEQsd0JBQUMsUUFBRCxZQUFNLG9DQUF1Qzs7OztnQkFDdkM7Ozs7O2VBQ0w7Ozs7O2dCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQWtELHFCQUM5QixjQUFjLFVBQVUsVUFBVSxPQUNqRDs7Ozs7Y0FDRjs7Ozs7O0tBR0osZ0JBQ0Msd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSxpQ0FBa0M7Ozs7Z0JBQ3pELHdCQUFDLEtBQUQsWUFBSSxhQUFnQjs7OztjQUNqQjs7Ozs7O0tBSU4sQ0FBQyxhQUNBLHdCQUFDLE9BQUQ7TUFDRSxhQUFhLE1BQU07T0FDakIsRUFBRSxlQUFlO09BQ2pCLGNBQWMsSUFBSTtNQUNwQjtNQUNBLG1CQUFtQixjQUFjLEtBQUs7TUFDdEMsUUFBUTtNQUNSLGVBQWUsYUFBYSxTQUFTLE1BQU07TUFDM0MsV0FBVyxnS0FDVCxhQUNJLHVGQUNBO2dCQVhSO09BY0Usd0JBQUMsU0FBRDtRQUNFLEtBQUs7UUFDTCxNQUFLO1FBQ0wsUUFBUSxjQUFjLFVBQVUsY0FBYztRQUM5QyxVQUFVO1FBQ1YsV0FBVTtPQUNYOzs7OztPQUdELHdCQUFDLE9BQUQsRUFBSyxXQUFVLHlFQUEwRTs7Ozs7T0FDekYsd0JBQUMsT0FBRCxFQUFLLFdBQVUsMEVBQTJFOzs7OztPQUMxRix3QkFBQyxPQUFELEVBQUssV0FBVSw0RUFBNkU7Ozs7O09BQzVGLHdCQUFDLE9BQUQsRUFBSyxXQUFVLDZFQUE4RTs7Ozs7T0FFN0Ysd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7Ozs7T0FDMUI7Ozs7O09BRUwsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQ7U0FBaUQ7U0FDM0I7U0FBVTtTQUFVLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE2QztTQUFrQjs7Ozs7UUFDckg7Ozs7OztPQUNKLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFiO1NBQW9EO1NBQzlCLGNBQWMsVUFBVSx5QkFBeUI7U0FBaUI7UUFFckY7Ozs7OztPQUVILHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsUUFBRCxZQUFNLHdCQUEyQjs7Ozs7U0FDakMsd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7O1NBQ2Isd0JBQUMsUUFBRCxZQUFNLGVBQWtCOzs7OztTQUN4Qix3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7U0FDYix3QkFBQyxRQUFELFlBQU0sc0JBQXlCOzs7OztRQUM1Qjs7Ozs7O01BQ0Y7Ozs7O2dCQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BRUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FHRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNHLGNBQWMsV0FDYix3QkFBQyxVQUFEO1dBQ0UsZUFBZSxtQkFBbUIsQ0FBQyxlQUFlO1dBQ2xELFdBQVcsZ0hBQ1Qsa0JBQ0ksaURBQ0E7V0FFTixPQUFNO3FCQVBSLENBU0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsY0FBZTs7OztxQkFDL0Isd0JBQUMsUUFBRCxZQUFNLE9BQVU7Ozs7bUJBQ1Y7Ozs7O29CQUdWLHdCQUFDLFVBQUQ7V0FDRSxTQUFTO1dBQ1QsVUFBVTtXQUNWLFdBQVU7cUJBSFosQ0FLRSx3QkFBQyxHQUFELEVBQUcsV0FBVSxVQUFXOzs7O3FCQUN4Qix3QkFBQyxRQUFELFlBQU0sY0FBaUI7Ozs7bUJBQ2pCOzs7OztrQkFDTDs7Ozs7O1NBR0osY0FBYyxXQUNiLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRDtXQUNFLEtBQUs7V0FDTCxLQUFJO1dBQ0osV0FBVTtVQUNYOzs7O29CQUdBLG1CQUNDLHdCQUFDLE9BQUQsRUFBSyxXQUFVLHFFQUFzRTs7OztrQkFFcEY7Ozs7OztTQUlOLGNBQWMsV0FDYix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFNBQUQ7V0FDRSxLQUFLO1dBQ0wsS0FBSztXQUNMLGNBQWM7V0FDZCxrQkFBa0I7V0FDbEIsZUFBZSxhQUFhLEtBQUs7V0FDakMsV0FBVTtVQUNYOzs7O29CQUdELHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmO1lBQ0Usd0JBQUMsVUFBRDthQUNFLFNBQVM7YUFDVCxXQUFVO2FBQ1YsY0FBWSxZQUFZLGdCQUFnQjt1QkFFdkMsWUFBWSx3QkFBQyxPQUFELEVBQU8sV0FBVSxVQUFXOzs7O3dCQUFJLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7O1lBQ2xFOzs7OztZQUVSLHdCQUFDLFNBQUQ7YUFDRSxNQUFLO2FBQ0wsS0FBSTthQUNKLEtBQUssaUJBQWlCO2FBQ3RCLE1BQUs7YUFDTCxPQUFPO2FBQ1AsVUFBVTthQUNWLFdBQVU7WUFDWDs7Ozs7WUFFRCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZjtjQUNHLEtBQUssTUFBTSxnQkFBZ0I7Y0FBRTtjQUFLLEtBQUssTUFBTSxhQUFhO2NBQUU7YUFDMUQ7Ozs7OztXQUNGOzs7OztrQkFDRjs7Ozs7O1FBRUo7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDYix3QkFBQyxZQUFELEVBQVksV0FBVSxVQUFXOzs7OztTQUM5Qjs7OzttQkFDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUNWLGVBQWUsYUFBYSxPQUFPO1VBQ25DOzs7O29CQUNILHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUNWLGVBQ0csSUFBSSxhQUFhLFFBQVEsT0FBTyxNQUFLLENBQUUsUUFBUSxDQUFDLEVBQUUsUUFBUSxhQUFhLFNBQ3ZFO1VBQ0g7Ozs7a0JBQ0E7Ozs7O2lCQUNGOzs7OztrQkFFTCx3QkFBQyxVQUFEO1NBQ0UsU0FBUztTQUNULFVBQVU7U0FDVixXQUFVO21CQUhaLENBS0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7OzttQkFDL0Isd0JBQUMsUUFBRCxZQUFPLGNBQWMsMEJBQTBCLDRCQUFrQzs7OztpQkFDM0U7Ozs7O2dCQUNMOzs7Ozs7T0FHSixlQUNDLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEIsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxvREFBcUQ7Ozs7cUJBQ3JFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFpQjtXQUFlOzs7O21CQUM1Qzs7Ozs7b0JBQ04sd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCLENBQW1ELGFBQVksR0FBTzs7Ozs7a0JBQ25FOzs7Ozs7U0FFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDYix3QkFBQyxPQUFEO1dBQ0UsV0FBVTtXQUNWLE9BQU8sRUFBRSxPQUFPLEdBQUcsWUFBWSxHQUFHO1VBQ25DOzs7OztTQUNFOzs7OztTQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVcsZUFBZSxLQUFLLGdDQUFnQztzQkFBa0I7V0FFakY7Ozs7O1dBQ04sd0JBQUMsUUFBRDtZQUFNLFdBQVcsZUFBZSxLQUFLLGdDQUFnQztzQkFBa0I7V0FFakY7Ozs7O1dBQ04sd0JBQUMsUUFBRDtZQUFNLFdBQVcsZUFBZSxLQUFLLGdDQUFnQztzQkFBa0I7V0FFakY7Ozs7O1dBQ04sd0JBQUMsUUFBRDtZQUFNLFdBQVcsZUFBZSxLQUFLLGdDQUFnQztzQkFBa0I7V0FFakY7Ozs7O1VBQ0g7Ozs7OztRQUNGOzs7Ozs7TUFFSjs7Ozs7O0tBSVAsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWdGO09BRTFGOzs7O2lCQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUE2QjtPQUV2Qzs7OztlQUNIOzs7OztNQUNGOzs7O2dCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLG1CQUFtQixLQUFLLFdBQ3ZCLHdCQUFDLFVBQUQ7UUFFRSxlQUFlLG1CQUFtQixNQUFNO1FBQ3hDLFdBQVU7a0JBSFo7U0FLRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQ7V0FDRSxLQUFLLE9BQU87V0FDWixLQUFLLE9BQU87V0FDWixXQUFVO1VBQ1g7Ozs7b0JBQ0Qsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ1osT0FBTyxLQUFLLFlBQVk7VUFDdEI7Ozs7a0JBQ0Y7Ozs7OztTQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUNYLE9BQU87VUFDTjs7Ozs7U0FDRDs7Ozs7U0FFTCx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFDVixPQUFPO1NBQ1A7Ozs7O1NBRUgsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FDSixPQUFPLFVBQVUsd0JBQ2IsZ0NBQ0EsT0FBTyxVQUFVLHFCQUNqQixtQ0FDQTtxQkFFSCxPQUFPO1VBQ0o7Ozs7b0JBQ04sd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTRFO1VBRXRGOzs7O2tCQUNIOzs7Ozs7UUFDQztVQXZDRCxPQUFPOzs7O2NBdUNOLENBQ1Q7TUFDRTs7OztjQUNGOzs7Ozs7SUFFRjs7Ozs7V0FDRjs7Ozs7O0NBQ0U7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTWVkaWFVcGxvYWRTZWN0aW9uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZVJlZiwgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQge1xuICBVcGxvYWQsXG4gIEltYWdlIGFzIEltYWdlSWNvbixcbiAgVmlkZW8gYXMgVmlkZW9JY29uLFxuICBYLFxuICBBbGVydENpcmNsZSxcbiAgUGxheSxcbiAgUGF1c2UsXG4gIFJvdGF0ZUNjdyxcbiAgU3BhcmtsZXMsXG4gIEluZm8sXG4gIENoZWNrLFxuICBGaWxlQ2hlY2syLFxuICBTbGlkZXJzLFxuICBNYXhpbWl6ZTIsXG4gIE1pbmltaXplMixcbiAgR3JpZCxcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IFNBTVBMRV9NRURJQV9JVEVNUyB9IGZyb20gJy4uL3V0aWxzL3NhbXBsZURhdGEnO1xuaW1wb3J0IHsgQW5hbHlzaXNQcm9ncmVzc0NhbGxiYWNrLCBhbmFseXplVXBsb2FkZWRNZWRpYSB9IGZyb20gJy4uL3V0aWxzL2FuYWx5emVyJztcbmltcG9ydCB7IEFuYWx5c2lzUmVzdWx0LCBTYW1wbGVNZWRpYSB9IGZyb20gJy4uL3R5cGVzJztcblxuaW50ZXJmYWNlIE1lZGlhVXBsb2FkU2VjdGlvblByb3BzIHtcbiAgb25BbmFseXNpc0NvbXBsZXRlOiAocmVzdWx0OiB7XG4gICAgcmVzdWx0OiBBbmFseXNpc1Jlc3VsdDtcbiAgICBwcmV2aWV3VXJsOiBzdHJpbmc7XG4gICAgZWxhVXJsPzogc3RyaW5nO1xuICAgIGhpZ2hwYXNzVXJsPzogc3RyaW5nO1xuICAgIGx1bWluYW5jZVVybD86IHN0cmluZztcbiAgfSkgPT4gdm9pZDtcbiAgaXNBbmFseXppbmc6IGJvb2xlYW47XG4gIHNldElzQW5hbHl6aW5nOiAodjogYm9vbGVhbikgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IE1lZGlhVXBsb2FkU2VjdGlvbjogUmVhY3QuRkM8TWVkaWFVcGxvYWRTZWN0aW9uUHJvcHM+ID0gKHtcbiAgb25BbmFseXNpc0NvbXBsZXRlLFxuICBpc0FuYWx5emluZyxcbiAgc2V0SXNBbmFseXppbmcsXG59KSA9PiB7XG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZTwnaW1hZ2UnIHwgJ3ZpZGVvJz4oJ2ltYWdlJyk7XG4gIGNvbnN0IFtzZWxlY3RlZEZpbGUsIHNldFNlbGVjdGVkRmlsZV0gPSB1c2VTdGF0ZTxGaWxlIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtwcmV2aWV3VXJsLCBzZXRQcmV2aWV3VXJsXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbZXJyb3JNZXNzYWdlLCBzZXRFcnJvck1lc3NhZ2VdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtpc0RyYWdPdmVyLCBzZXRJc0RyYWdPdmVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3Nob3dHcmlkT3ZlcmxheSwgc2V0U2hvd0dyaWRPdmVybGF5XSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAvLyBWaWRlbyBwbGF5YmFjayBzdGF0ZVxuICBjb25zdCBbaXNQbGF5aW5nLCBzZXRJc1BsYXlpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbdmlkZW9EdXJhdGlvbiwgc2V0VmlkZW9EdXJhdGlvbl0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW3ZpZGVvQ3VycmVudFRpbWUsIHNldFZpZGVvQ3VycmVudFRpbWVdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IHZpZGVvUmVmID0gdXNlUmVmPEhUTUxWaWRlb0VsZW1lbnQgfCBudWxsPihudWxsKTtcblxuICAvLyBBbmFseXNpcyBwcm9ncmVzc1xuICBjb25zdCBbc2NhblN0ZXAsIHNldFNjYW5TdGVwXSA9IHVzZVN0YXRlPHN0cmluZz4oJycpO1xuICBjb25zdCBbc2NhblBlcmNlbnQsIHNldFNjYW5QZXJjZW50XSA9IHVzZVN0YXRlPG51bWJlcj4oMCk7XG5cbiAgY29uc3QgZmlsZUlucHV0UmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQgfCBudWxsPihudWxsKTtcblxuICBjb25zdCBpbWFnZUFjY2VwdCA9ICcuanBnLC5qcGVnLC5wbmcsLndlYnAsaW1hZ2UvanBlZyxpbWFnZS9wbmcsaW1hZ2Uvd2VicCc7XG4gIGNvbnN0IHZpZGVvQWNjZXB0ID0gJy5tcDQsLm1vdiwud2VibSx2aWRlby9tcDQsdmlkZW8vcXVpY2t0aW1lLHZpZGVvL3dlYm0nO1xuXG4gIGNvbnN0IHZhbGlkYXRlQW5kU2V0RmlsZSA9IChmaWxlOiBGaWxlKSA9PiB7XG4gICAgc2V0RXJyb3JNZXNzYWdlKG51bGwpO1xuXG4gICAgY29uc3QgaXNJbWcgPSBmaWxlLnR5cGUuc3RhcnRzV2l0aCgnaW1hZ2UvJykgfHwgL1xcLihqcGd8anBlZ3xwbmd8d2VicCkkL2kudGVzdChmaWxlLm5hbWUpO1xuICAgIGNvbnN0IGlzVmlkID0gZmlsZS50eXBlLnN0YXJ0c1dpdGgoJ3ZpZGVvLycpIHx8IC9cXC4obXA0fG1vdnx3ZWJtKSQvaS50ZXN0KGZpbGUubmFtZSk7XG5cbiAgICBpZiAoYWN0aXZlVGFiID09PSAnaW1hZ2UnICYmICFpc0ltZykge1xuICAgICAgc2V0RXJyb3JNZXNzYWdlKCdQbGVhc2Ugc2VsZWN0IGEgdmFsaWQgaW1hZ2UgZmlsZSAoSlBHLCBKUEVHLCBQTkcsIG9yIFdFQlApLicpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoYWN0aXZlVGFiID09PSAndmlkZW8nICYmICFpc1ZpZCkge1xuICAgICAgc2V0RXJyb3JNZXNzYWdlKCdQbGVhc2Ugc2VsZWN0IGEgdmFsaWQgdmlkZW8gZmlsZSAoTVA0LCBNT1YsIG9yIFdFQk0pLicpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IG1heEltZ1NpemUgPSAyNSAqIDEwMjQgKiAxMDI0OyAvLyAyNU1CXG4gICAgY29uc3QgbWF4VmlkU2l6ZSA9IDYwICogMTAyNCAqIDEwMjQ7IC8vIDYwTUJcblxuICAgIGlmIChpc0ltZyAmJiBmaWxlLnNpemUgPiBtYXhJbWdTaXplKSB7XG4gICAgICBzZXRFcnJvck1lc3NhZ2UoJ0ltYWdlIHNpemUgZXhjZWVkcyAyNU1CIGxpbWl0LiBQbGVhc2UgdXBsb2FkIGEgc21hbGxlciBmaWxlLicpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoaXNWaWQgJiYgZmlsZS5zaXplID4gbWF4VmlkU2l6ZSkge1xuICAgICAgc2V0RXJyb3JNZXNzYWdlKCdWaWRlbyBzaXplIGV4Y2VlZHMgNjBNQiBsaW1pdC4gUGxlYXNlIHVwbG9hZCBhIHNob3J0ZXIgb3IgY29tcHJlc3NlZCBjbGlwLicpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHNldFNlbGVjdGVkRmlsZShmaWxlKTtcbiAgICBjb25zdCBvYmplY3RVcmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGZpbGUpO1xuICAgIHNldFByZXZpZXdVcmwob2JqZWN0VXJsKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVEcm9wID0gdXNlQ2FsbGJhY2soXG4gICAgKGU6IFJlYWN0LkRyYWdFdmVudDxIVE1MRGl2RWxlbWVudD4pID0+IHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIHNldElzRHJhZ092ZXIoZmFsc2UpO1xuICAgICAgaWYgKGUuZGF0YVRyYW5zZmVyLmZpbGVzICYmIGUuZGF0YVRyYW5zZmVyLmZpbGVzWzBdKSB7XG4gICAgICAgIHZhbGlkYXRlQW5kU2V0RmlsZShlLmRhdGFUcmFuc2Zlci5maWxlc1swXSk7XG4gICAgICB9XG4gICAgfSxcbiAgICBbYWN0aXZlVGFiXVxuICApO1xuXG4gIGNvbnN0IGhhbmRsZUZpbGVDaGFuZ2UgPSAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHtcbiAgICBpZiAoZS50YXJnZXQuZmlsZXMgJiYgZS50YXJnZXQuZmlsZXNbMF0pIHtcbiAgICAgIHZhbGlkYXRlQW5kU2V0RmlsZShlLnRhcmdldC5maWxlc1swXSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVJlbW92ZUZpbGUgPSAoKSA9PiB7XG4gICAgc2V0U2VsZWN0ZWRGaWxlKG51bGwpO1xuICAgIGlmIChwcmV2aWV3VXJsICYmICFwcmV2aWV3VXJsLnN0YXJ0c1dpdGgoJ2h0dHAnKSkge1xuICAgICAgVVJMLnJldm9rZU9iamVjdFVSTChwcmV2aWV3VXJsKTtcbiAgICB9XG4gICAgc2V0UHJldmlld1VybChudWxsKTtcbiAgICBzZXRFcnJvck1lc3NhZ2UobnVsbCk7XG4gICAgc2V0SXNQbGF5aW5nKGZhbHNlKTtcbiAgICBpZiAoZmlsZUlucHV0UmVmLmN1cnJlbnQpIGZpbGVJbnB1dFJlZi5jdXJyZW50LnZhbHVlID0gJyc7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU2VsZWN0U2FtcGxlID0gKHNhbXBsZTogU2FtcGxlTWVkaWEpID0+IHtcbiAgICBzZXRBY3RpdmVUYWIoc2FtcGxlLnR5cGUpO1xuICAgIHNldFNlbGVjdGVkRmlsZShudWxsKTtcbiAgICBzZXRQcmV2aWV3VXJsKHNhbXBsZS5wcmV2aWV3VXJsKTtcbiAgICBzZXRFcnJvck1lc3NhZ2UobnVsbCk7XG5cbiAgICBvbkFuYWx5c2lzQ29tcGxldGUoe1xuICAgICAgcmVzdWx0OiBzYW1wbGUubW9ja1Jlc3VsdCxcbiAgICAgIHByZXZpZXdVcmw6IHNhbXBsZS5wcmV2aWV3VXJsLFxuICAgIH0pO1xuXG4gICAgY29uc3QgZWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncmVzdWx0cy1kYXNoYm9hcmQnKTtcbiAgICBpZiAoZWwpIGVsLnNjcm9sbEludG9WaWV3KHsgYmVoYXZpb3I6ICdzbW9vdGgnIH0pO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVN0YXJ0QW5hbHlzaXMgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFzZWxlY3RlZEZpbGUgJiYgIXByZXZpZXdVcmwpIHJldHVybjtcblxuICAgIHNldElzQW5hbHl6aW5nKHRydWUpO1xuICAgIHNldFNjYW5TdGVwKCdJbml0aWFsaXppbmcgZm9yZW5zaWMgc2NhbiBzZXF1ZW5jZS4uLicpO1xuICAgIHNldFNjYW5QZXJjZW50KDYpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGlmIChzZWxlY3RlZEZpbGUgJiYgcHJldmlld1VybCkge1xuICAgICAgICBjb25zdCBwcm9ncmVzc0hhbmRsZXI6IEFuYWx5c2lzUHJvZ3Jlc3NDYWxsYmFjayA9IChzdGVwLCBwZXJjZW50KSA9PiB7XG4gICAgICAgICAgc2V0U2NhblN0ZXAoc3RlcCk7XG4gICAgICAgICAgc2V0U2NhblBlcmNlbnQocGVyY2VudCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgY29uc3QgYW5hbHlzaXNPdXRwdXQgPSBhd2FpdCBhbmFseXplVXBsb2FkZWRNZWRpYShzZWxlY3RlZEZpbGUsIHByZXZpZXdVcmwsIHByb2dyZXNzSGFuZGxlcik7XG5cbiAgICAgICAgb25BbmFseXNpc0NvbXBsZXRlKHtcbiAgICAgICAgICByZXN1bHQ6IGFuYWx5c2lzT3V0cHV0LnJlc3VsdCxcbiAgICAgICAgICBwcmV2aWV3VXJsLFxuICAgICAgICAgIGVsYVVybDogYW5hbHlzaXNPdXRwdXQuZWxhVXJsLFxuICAgICAgICAgIGhpZ2hwYXNzVXJsOiBhbmFseXNpc091dHB1dC5oaWdocGFzc1VybCxcbiAgICAgICAgICBsdW1pbmFuY2VVcmw6IGFuYWx5c2lzT3V0cHV0Lmx1bWluYW5jZVVybCxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgIHNldEVycm9yTWVzc2FnZShlcnI/Lm1lc3NhZ2UgfHwgJ0FuYWx5c2lzIGVuY291bnRlcmVkIGFuIGVycm9yIGR1cmluZyBzY2FuLicpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc0FuYWx5emluZyhmYWxzZSk7XG4gICAgICBjb25zdCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyZXN1bHRzLWRhc2hib2FyZCcpO1xuICAgICAgaWYgKGVsKSBlbC5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiAnc21vb3RoJyB9KTtcbiAgICB9XG4gIH07XG5cbiAgLy8gVmlkZW8gcGxheWJhY2tcbiAgY29uc3QgdG9nZ2xlUGxheSA9ICgpID0+IHtcbiAgICBpZiAoIXZpZGVvUmVmLmN1cnJlbnQpIHJldHVybjtcbiAgICBpZiAoaXNQbGF5aW5nKSB7XG4gICAgICB2aWRlb1JlZi5jdXJyZW50LnBhdXNlKCk7XG4gICAgICBzZXRJc1BsYXlpbmcoZmFsc2UpO1xuICAgIH0gZWxzZSB7XG4gICAgICB2aWRlb1JlZi5jdXJyZW50LnBsYXkoKTtcbiAgICAgIHNldElzUGxheWluZyh0cnVlKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlVGltZVVwZGF0ZSA9ICgpID0+IHtcbiAgICBpZiAodmlkZW9SZWYuY3VycmVudCkge1xuICAgICAgc2V0VmlkZW9DdXJyZW50VGltZSh2aWRlb1JlZi5jdXJyZW50LmN1cnJlbnRUaW1lKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlTG9hZGVkTWV0YWRhdGEgPSAoKSA9PiB7XG4gICAgaWYgKHZpZGVvUmVmLmN1cnJlbnQpIHtcbiAgICAgIHNldFZpZGVvRHVyYXRpb24odmlkZW9SZWYuY3VycmVudC5kdXJhdGlvbik7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVNlZWsgPSAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHtcbiAgICBjb25zdCB0aW1lID0gcGFyc2VGbG9hdChlLnRhcmdldC52YWx1ZSk7XG4gICAgc2V0VmlkZW9DdXJyZW50VGltZSh0aW1lKTtcbiAgICBpZiAodmlkZW9SZWYuY3VycmVudCkge1xuICAgICAgdmlkZW9SZWYuY3VycmVudC5jdXJyZW50VGltZSA9IHRpbWU7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gaWQ9XCJhbmFseXplXCIgY2xhc3NOYW1lPVwicmVsYXRpdmUgc2Nyb2xsLW10LTIwIHB5LTIwIHB4LTYgbGc6cHgtOCBib3JkZXItdCBib3JkZXItd2hpdGUvWzAuMDhdIGJnLVsjMDIwNDA5XVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LTZ4bFwiPlxuICAgICAgICBcbiAgICAgICAgey8qIFNlY3Rpb24gSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIG1heC13LTJ4bCBteC1hdXRvIG1iLTEyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LWN5YW4tNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0yXCI+XG4gICAgICAgICAgICBGb3JlbnNpYyBJbnNwZWN0aW9uIFN0dWRpb1xuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBzbTp0ZXh0LTR4bCBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIHRyYWNraW5nLXRpZ2h0IFt0ZXh0LXdyYXA6YmFsYW5jZV1cIj5cbiAgICAgICAgICAgIEFuYWx5emUgTWVkaWEgZm9yIFN5bnRoZXRpYyBTaWduYWxzXG4gICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0zIHRleHQtc20gc206dGV4dC1iYXNlIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICBVcGxvYWQgaW1hZ2VzIG9yIHZpZGVvcyB0byBpbnNwZWN0IG11bHRpLXZlY3RvciBmb3JlbnNpYyBpbmRpY2F0b3JzLCBjb21wcmVzc2lvbiBoZWF0bWFwcywgYW5kIGNvbnRhaW5lciBwcm92ZW5hbmNlLlxuICAgICAgICAgIDwvcD5cblxuICAgICAgICAgIHsvKiBFbmdpbmUgRGlzY2xhaW1lciAvIERlbW9uc3RyYXRpb24gRGlzY2xvc3VyZSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTUgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgcHgtNCBweS0yIHJvdW5kZWQteGwgYmctY3lhbi05NTAvNDAgYm9yZGVyIGJvcmRlci1jeWFuLTUwMC8yNSB0ZXh0LWN5YW4tMjAwIHRleHQteHMgdGV4dC1sZWZ0IGJhY2tkcm9wLWJsdXItbWRcIj5cbiAgICAgICAgICAgIDxJbmZvIGNsYXNzTmFtZT1cImgtNCB3LTQgc2hyaW5rLTAgdGV4dC1jeWFuLTQwMFwiIC8+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgZm9udC1zZW1pYm9sZFwiPkluc3BlY3Rpb24gUGlwZWxpbmUgKERlbW9uc3RyYXRpb24gTW9kZSk8L3N0cm9uZz46IEFuYWx5emVzIGNvbnRhaW5lciBtZXRhZGF0YSwgc3BhdGlhbCBEaXNjcmV0ZSBDb3NpbmUgVHJhbnNmb3JtIChEQ1QpIHF1YW50aXphdGlvbiwgYW5kIHBoeXNpY2FsIG5vaXNlIHByb2ZpbGVzLlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBTdHVkaW8gV29ya3NwYWNlIENhcmQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0zeGwgYm9yZGVyIGJvcmRlci13aGl0ZS9bMC4wOF0gYmctWyMwNTA4MTZdLzkwIGJhY2tkcm9wLWJsdXItMnhsIHAtNiBzbTpwLTggc2hhZG93LVswXzBfNTBweF9yZ2JhKDAsMCwwLDAuNSldXCI+XG4gICAgICAgICAgXG4gICAgICAgICAgey8qIE1lZGlhIFR5cGUgVGFicyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBmbGV4LXdyYXAgZ2FwLTQgYm9yZGVyLWIgYm9yZGVyLXdoaXRlL1swLjA4XSBwYi02IG1iLTZcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBwLTEgYmctd2hpdGUvWzAuMDRdIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci13aGl0ZS9bMC4wNl1cIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZVRhYignaW1hZ2UnKTtcbiAgICAgICAgICAgICAgICAgIGhhbmRsZVJlbW92ZUZpbGUoKTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSAnaW1hZ2UnXG4gICAgICAgICAgICAgICAgICAgID8gJ2JnLWN5YW4tNTAwLzIwIHRleHQtY3lhbi0zMDAgYm9yZGVyIGJvcmRlci1jeWFuLTUwMC80MCBzaGFkb3ctc20nXG4gICAgICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8SW1hZ2VJY29uIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1jeWFuLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+SW1hZ2UgSW5zcGVjdGlvbiAoSlBHLCBQTkcsIFdFQlApPC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlVGFiKCd2aWRlbycpO1xuICAgICAgICAgICAgICAgICAgaGFuZGxlUmVtb3ZlRmlsZSgpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNCBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09ICd2aWRlbydcbiAgICAgICAgICAgICAgICAgICAgPyAnYmctY3lhbi01MDAvMjAgdGV4dC1jeWFuLTMwMCBib3JkZXIgYm9yZGVyLWN5YW4tNTAwLzQwIHNoYWRvdy1zbSdcbiAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxWaWRlb0ljb24gY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LXZpb2xldC00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPlZpZGVvIEluc3BlY3Rpb24gKE1QNCwgTU9WLCBXRUJNKTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICBDb250YWluZXIgTGltaXQ6IHthY3RpdmVUYWIgPT09ICdpbWFnZScgPyAnMjUgTUInIDogJzYwIE1CJ31cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEVycm9yIE1lc3NhZ2UgQWxlcnQgKi99XG4gICAgICAgICAge2Vycm9yTWVzc2FnZSAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcm91bmRlZC14bCBiZy1yb3NlLTk1MC82MCBib3JkZXIgYm9yZGVyLXJvc2UtNTAwLzQwIHAtNCB0ZXh0LXNtIHRleHQtcm9zZS0yMDBcIj5cbiAgICAgICAgICAgICAgPEFsZXJ0Q2lyY2xlIGNsYXNzTmFtZT1cImgtNSB3LTUgc2hyaW5rLTAgdGV4dC1yb3NlLTQwMFwiIC8+XG4gICAgICAgICAgICAgIDxwPntlcnJvck1lc3NhZ2V9PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBVcGxvYWQgQXJlYSAvIFByZXZpZXcgVmlld3BvcnQgKi99XG4gICAgICAgICAgeyFwcmV2aWV3VXJsID8gKFxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBvbkRyYWdPdmVyPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgICBzZXRJc0RyYWdPdmVyKHRydWUpO1xuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICBvbkRyYWdMZWF2ZT17KCkgPT4gc2V0SXNEcmFnT3ZlcihmYWxzZSl9XG4gICAgICAgICAgICAgIG9uRHJvcD17aGFuZGxlRHJvcH1cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZmlsZUlucHV0UmVmLmN1cnJlbnQ/LmNsaWNrKCl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtMnhsIGJvcmRlci0yIGJvcmRlci1kYXNoZWQgcC0xMCBzbTpwLTE2IHRleHQtY2VudGVyIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tYWxsIG92ZXJmbG93LWhpZGRlbiAke1xuICAgICAgICAgICAgICAgIGlzRHJhZ092ZXJcbiAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1jeWFuLTQwMCBiZy1jeWFuLTk1MC8zMCBzY2FsZS1bMC45OV0gc2hhZG93LVswXzBfMzBweF9yZ2JhKDYsMTgyLDIxMiwwLjI1KV0nXG4gICAgICAgICAgICAgICAgICA6ICdib3JkZXItd2hpdGUvWzAuMTJdIGhvdmVyOmJvcmRlci1jeWFuLTUwMC80MCBiZy13aGl0ZS9bMC4wMTVdIGhvdmVyOmJnLXdoaXRlL1swLjAzXSdcbiAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHJlZj17ZmlsZUlucHV0UmVmfVxuICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcbiAgICAgICAgICAgICAgICBhY2NlcHQ9e2FjdGl2ZVRhYiA9PT0gJ2ltYWdlJyA/IGltYWdlQWNjZXB0IDogdmlkZW9BY2NlcHR9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUZpbGVDaGFuZ2V9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcbiAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICB7LyogQ29ybmVyIEN5YmVyIEJyYWNrZXRzICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0zIGxlZnQtMyB3LTQgaC00IGJvcmRlci10LTIgYm9yZGVyLWwtMiBib3JkZXItY3lhbi01MDAvNDBcIiAvPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0zIHJpZ2h0LTMgdy00IGgtNCBib3JkZXItdC0yIGJvcmRlci1yLTIgYm9yZGVyLWN5YW4tNTAwLzQwXCIgLz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMyBsZWZ0LTMgdy00IGgtNCBib3JkZXItYi0yIGJvcmRlci1sLTIgYm9yZGVyLWN5YW4tNTAwLzQwXCIgLz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMyByaWdodC0zIHctNCBoLTQgYm9yZGVyLWItMiBib3JkZXItci0yIGJvcmRlci1jeWFuLTUwMC80MFwiIC8+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtMTYgdy0xNiBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC0yeGwgYmctY3lhbi01MDAvMTAgYm9yZGVyIGJvcmRlci1jeWFuLTUwMC8zMCB0ZXh0LWN5YW4tNDAwIG1iLTQgZ3JvdXAtaG92ZXI6c2NhbGUtMTA1IHRyYW5zaXRpb24tdHJhbnNmb3JtIHNoYWRvdy1bMF8wXzIwcHhfcmdiYSg2LDE4MiwyMTIsMC4xNSldXCI+XG4gICAgICAgICAgICAgICAgPFVwbG9hZCBjbGFzc05hbWU9XCJoLTggdy04XCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgRHJhZyBhbmQgZHJvcCB5b3VyIHthY3RpdmVUYWJ9IGhlcmUsIG9yIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtY3lhbi00MDAgdW5kZXJsaW5lIHVuZGVybGluZS1vZmZzZXQtNFwiPmJyb3dzZSBmaWxlczwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG1heC13LXNtXCI+XG4gICAgICAgICAgICAgICAgU3VwcG9ydGVkIGZvcm1hdHM6IHthY3RpdmVUYWIgPT09ICdpbWFnZScgPyAnSlBHLCBKUEVHLCBQTkcsIFdFQlAnIDogJ01QNCwgTU9WLCBXRUJNJ30uXG4gICAgICAgICAgICAgICAgQWxsIGZpbGUgcHJvY2Vzc2luZyBzdGF5cyBwcml2YXRlIGluIHlvdXIgYnJvd3NlciBzZXNzaW9uLlxuICAgICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtWzExcHhdIGZvbnQtbW9ubyB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuPkRldGVybWluaXN0aWMgaGFzaGluZzwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3Bhbj7Ctzwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3Bhbj5FWElGIHBhcnNpbmc8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4+wrc8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4+WmVybyBkYXRhIHJldGVudGlvbjwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICAgICAgey8qIE1lZGlhIFByZXZpZXcgQm94ICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMV0gYmctYmxhY2svNzAgb3ZlcmZsb3ctaGlkZGVuIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1pbi1oLVszNDBweF0gbWF4LWgtWzU0MHB4XVwiPlxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIHsvKiBWaWV3cG9ydCBUb3AgQ29udHJvbHMgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtNCByaWdodC00IHotMjAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdpbWFnZScgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0dyaWRPdmVybGF5KCFzaG93R3JpZE92ZXJsYXkpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtbW9ubyB0cmFuc2l0aW9uLWNvbG9ycyBiYWNrZHJvcC1ibHVyLW1kIGJvcmRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgc2hvd0dyaWRPdmVybGF5XG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWN5YW4tNTAwLzMwIGJvcmRlci1jeWFuLTQwMCB0ZXh0LWN5YW4tMjAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1ibGFjay83MCBib3JkZXItd2hpdGUvMTUgdGV4dC1zbGF0ZS0zMDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlRvZ2dsZSBncmlkIG92ZXJsYXlcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPEdyaWQgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkdyaWQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVSZW1vdmVGaWxlfVxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNBbmFseXppbmd9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgcm91bmRlZC1sZyBiZy1ibGFjay84MCBob3ZlcjpiZy1yb3NlLTk1MC84MCBib3JkZXIgYm9yZGVyLXdoaXRlLzIwIGhvdmVyOmJvcmRlci1yb3NlLTUwMC81MCB0ZXh0LXhzIHRleHQtc2xhdGUtMjAwIGhvdmVyOnRleHQtcm9zZS0yMDAgdHJhbnNpdGlvbi1jb2xvcnMgYmFja2Ryb3AtYmx1ci1tZCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5SZW1vdmUgRmlsZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIEltYWdlIFByZXZpZXcgd2l0aCBvcHRpb25hbCBhbGlnbm1lbnQgZ3JpZCAqL31cbiAgICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSAnaW1hZ2UnICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIGgtZnVsbCBtYXgtaC1bNTAwcHhdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgICAgICAgc3JjPXtwcmV2aWV3VXJsfVxuICAgICAgICAgICAgICAgICAgICAgIGFsdD1cIlVwbG9hZGVkIG1lZGlhIHByZXZpZXdcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1heC1oLVs0NjBweF0gbWF4LXctZnVsbCByb3VuZGVkLXhsIG9iamVjdC1jb250YWluIHNoYWRvdy0yeGxcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBJbnNwZWN0aW9uIEdyaWQgT3ZlcmxheSAqL31cbiAgICAgICAgICAgICAgICAgICAge3Nob3dHcmlkT3ZlcmxheSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIHBvaW50ZXItZXZlbnRzLW5vbmUgY3liZXItZ3JpZC1wYXR0ZXJuIG9wYWNpdHktNDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIHsvKiBWaWRlbyBQcmV2aWV3IHdpdGggUGxheWVyIENvbnRyb2xzICovfVxuICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICd2aWRlbycgJiYgKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgaC1mdWxsIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDx2aWRlb1xuICAgICAgICAgICAgICAgICAgICAgIHJlZj17dmlkZW9SZWZ9XG4gICAgICAgICAgICAgICAgICAgICAgc3JjPXtwcmV2aWV3VXJsfVxuICAgICAgICAgICAgICAgICAgICAgIG9uVGltZVVwZGF0ZT17aGFuZGxlVGltZVVwZGF0ZX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkxvYWRlZE1ldGFkYXRhPXtoYW5kbGVMb2FkZWRNZXRhZGF0YX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkVuZGVkPXsoKSA9PiBzZXRJc1BsYXlpbmcoZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1heC1oLVs0NDBweF0gdy1mdWxsIG9iamVjdC1jb250YWluXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICAgICAgICB7LyogQ3VzdG9tIFZpZGVvIFBsYXliYWNrIEJhciAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwLzk1IGJvcmRlci10IGJvcmRlci13aGl0ZS9bMC4xXSBwLTMuNSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCB6LTEwIGJhY2tkcm9wLWJsdXItbWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXt0b2dnbGVQbGF5fVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQtbGcgYmctY3lhbi01MDAvMjAgdGV4dC1jeWFuLTMwMCBob3ZlcjpiZy1jeWFuLTUwMC8zMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtpc1BsYXlpbmcgPyAnUGF1c2UgdmlkZW8nIDogJ1BsYXkgdmlkZW8nfVxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpc1BsYXlpbmcgPyA8UGF1c2UgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+IDogPFBsYXkgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXg9e3ZpZGVvRHVyYXRpb24gfHwgMTAwfVxuICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3ZpZGVvQ3VycmVudFRpbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU2Vla31cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBhY2NlbnQtY3lhbi00MDAgY3Vyc29yLXBvaW50ZXIgaC0xLjUgcm91bmRlZC1sZyBiZy1zbGF0ZS04MDBcIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIHRleHQtc2xhdGUtMzAwIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7TWF0aC5mbG9vcih2aWRlb0N1cnJlbnRUaW1lKX1zIC8ge01hdGguZmxvb3IodmlkZW9EdXJhdGlvbil9c1xuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBGaWxlIEluZm8gU3RyaXAgJiBBY3Rpb25zICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBwLTQgcm91bmRlZC0yeGwgYmctd2hpdGUvWzAuMDNdIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMDhdXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtMTAgdy0xMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBiZy1jeWFuLTUwMC8xMCBib3JkZXIgYm9yZGVyLWN5YW4tNTAwLzMwIHRleHQtY3lhbi00MDAgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPEZpbGVDaGVjazIgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtd2hpdGUgdHJ1bmNhdGUgbWF4LXcteHMgc206bWF4LXctbWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRGaWxlID8gc2VsZWN0ZWRGaWxlLm5hbWUgOiAnQmVuY2htYXJrIFNhbXBsZSBGaWxlIExvYWRlZCd9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgZm9udC1tb25vIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZEZpbGVcbiAgICAgICAgICAgICAgICAgICAgICAgID8gYCR7KHNlbGVjdGVkRmlsZS5zaXplIC8gKDEwMjQgKiAxMDI0KSkudG9GaXhlZCgyKX0gTUIgwrcgJHtzZWxlY3RlZEZpbGUudHlwZX1gXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdSZWFkeSBmb3IgRm9yZW5zaWMgRXZhbHVhdGlvbid9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU3RhcnRBbmFseXNpc31cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0FuYWx5emluZ31cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBzbTp3LWF1dG8gaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yLjUgcHgtOCBweS0zLjUgdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtYmxhY2sgYmctZ3JhZGllbnQtdG8tciBmcm9tLWN5YW4tNDAwIHZpYS1jeWFuLTMwMCB0by10ZWFsLTMwMCBob3Zlcjpmcm9tLWN5YW4tMzAwIGhvdmVyOnRvLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LVswXzBfMjhweF9yZ2JhKDYsMTgyLDIxMiwwLjM1KV0gdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS01MCBhY3RpdmU6c2NhbGUtOTVcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPntpc0FuYWx5emluZyA/ICdJbnNwZWN0aW5nIFNpZ25hbHMuLi4nIDogJ0V4ZWN1dGUgRm9yZW5zaWMgQW5hbHlzaXMnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIExpdmUgU2Nhbm5pbmcgUHJvZ3Jlc3MgSFVEICovfVxuICAgICAgICAgICAgICB7aXNBbmFseXppbmcgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1jeWFuLTUwMC80MCBiZy1jeWFuLTk1MC8zMCBwLTYgc3BhY2UteS00IGJhY2tkcm9wLWJsdXIteGwgc2hhZG93LVswXzBfNDBweF9yZ2JhKDYsMTgyLDIxMiwwLjE1KV1cIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQteHMgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtY3lhbi0zMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTIuNSBoLTIuNSByb3VuZGVkLWZ1bGwgYmctY3lhbi00MDAgYW5pbWF0ZS1waW5nXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+e3NjYW5TdGVwfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWN5YW4tNDAwIGZvbnQtYm9sZCB0ZXh0LXNtXCI+e3NjYW5QZXJjZW50fSU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0yIHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS05MDAgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlciBib3JkZXItY3lhbi01MDAvMzBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtZnVsbCBiZy1ncmFkaWVudC10by1yIGZyb20tY3lhbi00MDAgdmlhLXRlYWwtMzAwIHRvLXZpb2xldC00MDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXCJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7c2NhblBlcmNlbnR9JWAgfX1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgc206Z3JpZC1jb2xzLTQgZ2FwLTIgdGV4dC1bMTBweF0gZm9udC1tb25vIHRleHQtc2xhdGUtNDAwIHB0LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtzY2FuUGVyY2VudCA+PSAyMCA/ICd0ZXh0LWN5YW4tMzAwIGZvbnQtc2VtaWJvbGQnIDogJ3RleHQtc2xhdGUtNjAwJ30+XG4gICAgICAgICAgICAgICAgICAgICAgMDEuIEVYSUYgSW50ZWdyaXR5XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtzY2FuUGVyY2VudCA+PSA0NSA/ICd0ZXh0LWN5YW4tMzAwIGZvbnQtc2VtaWJvbGQnIDogJ3RleHQtc2xhdGUtNjAwJ30+XG4gICAgICAgICAgICAgICAgICAgICAgMDIuIERDVCBEaXNwYXJpdHlcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3NjYW5QZXJjZW50ID49IDcwID8gJ3RleHQtY3lhbi0zMDAgZm9udC1zZW1pYm9sZCcgOiAndGV4dC1zbGF0ZS02MDAnfT5cbiAgICAgICAgICAgICAgICAgICAgICAwMy4gR2xhcmUgVmVjdG9yc1xuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17c2NhblBlcmNlbnQgPj0gOTAgPyAndGV4dC1jeWFuLTMwMCBmb250LXNlbWlib2xkJyA6ICd0ZXh0LXNsYXRlLTYwMCd9PlxuICAgICAgICAgICAgICAgICAgICAgIDA0LiBVbmNlcnRhaW50eSBNb2RlbFxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogQmVuY2htYXJrIFNhbXBsZSBNZWRpYSBMaWJyYXJ5IChJbnN0YW50IDEtQ2xpY2sgVmVyaWZpY2F0aW9uKSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwIHB0LTggYm9yZGVyLXQgYm9yZGVyLXdoaXRlL1swLjA4XVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNSBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyB1cHBlcmNhc2UgdGV4dC1zbGF0ZS0zMDAgdHJhY2tpbmctd2lkZXIgZm9udC1zZW1pYm9sZCBibG9ja1wiPlxuICAgICAgICAgICAgICAgICAgQmVuY2htYXJrIFNhbXBsZSBMaWJyYXJ5IOKAlCBJbnN0YW50IFRlc3QgUnVuXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICAgICAgICBTZWxlY3QgYW55IHByZS1pbmRleGVkIG1lZGlhIHRvIGV2YWx1YXRlIGZvcmVuc2ljIHNpZ25hbHMgaW5zdGFudGx5XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cbiAgICAgICAgICAgICAge1NBTVBMRV9NRURJQV9JVEVNUy5tYXAoKHNhbXBsZSkgPT4gKFxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIGtleT17c2FtcGxlLmlkfVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2VsZWN0U2FtcGxlKHNhbXBsZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBmbGV4IGZsZXgtY29sIHRleHQtbGVmdCBwLTMuNSByb3VuZGVkLTJ4bCBiZy13aGl0ZS9bMC4wMl0gaG92ZXI6Ymctd2hpdGUvWzAuMDVdIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMDZdIGhvdmVyOmJvcmRlci1jeWFuLTUwMC80MCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgYXNwZWN0LXZpZGVvIHctZnVsbCByb3VuZGVkLXhsIG92ZXJmbG93LWhpZGRlbiBiZy1zbGF0ZS05MDAgbWItMyBib3JkZXIgYm9yZGVyLXdoaXRlL1swLjA2XVwiPlxuICAgICAgICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgICAgICAgc3JjPXtzYW1wbGUucHJldmlld1VybH1cbiAgICAgICAgICAgICAgICAgICAgICBhbHQ9e3NhbXBsZS50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlciBncm91cC1ob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMiBsZWZ0LTIgdGV4dC1bMTBweF0gZm9udC1tb25vIHB4LTIgcHktMC41IHJvdW5kZWQtbWQgYmctYmxhY2svODAgYm9yZGVyIGJvcmRlci13aGl0ZS8xMCB0ZXh0LWN5YW4tMzAwIGJhY2tkcm9wLWJsdXItbWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c2FtcGxlLnR5cGUudG9VcHBlckNhc2UoKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTEgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGdyb3VwLWhvdmVyOnRleHQtY3lhbi0zMDAgdHJhbnNpdGlvbi1jb2xvcnMgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c2FtcGxlLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGxpbmUtY2xhbXAtMiBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAge3NhbXBsZS5kZXNjcmlwdGlvbn1cbiAgICAgICAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHB0LTIuNSBib3JkZXItdCBib3JkZXItd2hpdGUvWzAuMDRdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LVsxMHB4XSBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtcbiAgICAgICAgICAgICAgICAgICAgICBzYW1wbGUuYmFkZ2UgPT09ICdMaWtlbHkgQUktZ2VuZXJhdGVkJ1xuICAgICAgICAgICAgICAgICAgICAgICAgPyAndGV4dC1yb3NlLTQwMCBmb250LXNlbWlib2xkJ1xuICAgICAgICAgICAgICAgICAgICAgICAgOiBzYW1wbGUuYmFkZ2UgPT09ICdMaWtlbHkgYXV0aGVudGljJ1xuICAgICAgICAgICAgICAgICAgICAgICAgPyAndGV4dC1lbWVyYWxkLTQwMCBmb250LXNlbWlib2xkJ1xuICAgICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1hbWJlci00MDAgZm9udC1zZW1pYm9sZCdcbiAgICAgICAgICAgICAgICAgICAgfT5cbiAgICAgICAgICAgICAgICAgICAgICB7c2FtcGxlLmJhZGdlfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtY3lhbi00MDAgZ3JvdXAtaG92ZXI6dW5kZXJsaW5lIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICBJbnNwZWN0ICZyYXJyO1xuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn07XG4iXX0=