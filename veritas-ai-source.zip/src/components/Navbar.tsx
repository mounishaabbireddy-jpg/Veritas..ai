const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4c5f34d3";
import { ShieldAlert, Menu, X, Smartphone, Download, Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=4c5f34d3";
import { downloadProjectZip } from "/src/utils/projectDownloader.ts";
var _jsxFileName = "/app/applet/src/components/Navbar.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4c5f34d3";
export const Navbar = ({ onAnalyzeClick, onOpenMobileGuide }) => {
	const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
	const [isDownloading, setIsDownloading] = useState(false);
	const handleDownloadZip = async () => {
		try {
			setIsDownloading(true);
			await downloadProjectZip();
		} catch (e) {
			console.error("Download error:", e);
		} finally {
			setIsDownloading(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("header", {
		className: "sticky top-0 z-50 w-full border-b border-white/[0.08] bg-[#03050a]/80 backdrop-blur-xl",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "mx-auto flex h-18 max-w-7xl items-center justify-between gap-8 px-6 lg:px-8",
			children: [
				/* @__PURE__ */ _jsxDEV("a", {
					href: "#",
					className: "flex items-center gap-2.5 whitespace-nowrap shrink-0 group",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-500/20 to-violet-500/20 border border-cyan-500/30 text-cyan-400 group-hover:border-cyan-400 transition-colors",
						children: /* @__PURE__ */ _jsxDEV(ShieldAlert, { className: "h-5 w-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 31,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 30,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-xl font-bold tracking-tight text-white group-hover:text-cyan-300 transition-colors",
						children: ["VERITAS", /* @__PURE__ */ _jsxDEV("span", {
							className: "text-cyan-400 ml-1 font-mono text-sm tracking-wider font-semibold",
							children: "AI"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 34,
							columnNumber: 20
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 33,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("nav", {
					className: "hidden md:flex items-center gap-8 text-sm font-medium text-slate-300",
					children: [
						/* @__PURE__ */ _jsxDEV("a", {
							href: "#analyze",
							className: "hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0",
							children: "Detection Studio"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 40,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("a", {
							href: "#how-it-works",
							className: "hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0",
							children: "How It Works"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 43,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("a", {
							href: "#features",
							className: "hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0",
							children: "Features"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("a", {
							href: "#technology",
							className: "hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0",
							children: "Technology"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 49,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("a", {
							href: "#pricing",
							className: "hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0",
							children: "Pricing"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 52,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("a", {
							href: "#faq",
							className: "hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0",
							children: "FAQ"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 55,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "hidden md:flex items-center gap-3 shrink-0",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleDownloadZip,
							disabled: isDownloading,
							className: "flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] rounded-lg transition-colors whitespace-nowrap cursor-pointer disabled:opacity-50",
							title: "Download complete project ZIP to upload to GitHub",
							children: [isDownloading ? /* @__PURE__ */ _jsxDEV(Loader2, { className: "h-3.5 w-3.5 text-cyan-400 animate-spin" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 69,
								columnNumber: 15
							}, this) : /* @__PURE__ */ _jsxDEV(Download, { className: "h-3.5 w-3.5 text-cyan-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 71,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: isDownloading ? "Packing ZIP..." : "Download ZIP" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 73,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 62,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: onOpenMobileGuide,
							className: "flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] rounded-lg transition-colors whitespace-nowrap cursor-pointer",
							title: "Mobile Public URL Instructions",
							children: [/* @__PURE__ */ _jsxDEV(Smartphone, { className: "h-3.5 w-3.5 text-cyan-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 80,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Mobile URL" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 81,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 75,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: onAnalyzeClick,
							className: "px-5 py-2 text-xs font-semibold text-black bg-gradient-to-r from-cyan-400 to-cyan-300 hover:from-cyan-300 hover:to-white rounded-lg shadow-[0_0_20px_rgba(6,182,212,0.3)] transition-all whitespace-nowrap cursor-pointer active:scale-95",
							children: "Analyze Media"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 83,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex md:hidden items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: onOpenMobileGuide,
						className: "p-2 text-slate-300 hover:text-cyan-400 bg-white/[0.05] rounded-lg border border-white/[0.08]",
						"aria-label": "Mobile Instructions",
						children: /* @__PURE__ */ _jsxDEV(Smartphone, { className: "h-4 w-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 98,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 93,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setMobileMenuOpen(!mobileMenuOpen),
						className: "p-2 text-slate-300 hover:text-white",
						"aria-label": "Toggle navigation menu",
						children: mobileMenuOpen ? /* @__PURE__ */ _jsxDEV(X, { className: "h-6 w-6" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 105,
							columnNumber: 31
						}, this) : /* @__PURE__ */ _jsxDEV(Menu, { className: "h-6 w-6" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 105,
							columnNumber: 59
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 92,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 7
		}, this), mobileMenuOpen && /* @__PURE__ */ _jsxDEV("div", {
			className: "md:hidden border-b border-white/[0.08] bg-[#03050a]/95 backdrop-blur-xl px-6 py-4 space-y-3",
			children: [
				/* @__PURE__ */ _jsxDEV("a", {
					href: "#analyze",
					onClick: () => setMobileMenuOpen(false),
					className: "block py-2 text-sm font-medium text-slate-200 hover:text-cyan-400",
					children: "Detection Studio"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 113,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("a", {
					href: "#how-it-works",
					onClick: () => setMobileMenuOpen(false),
					className: "block py-2 text-sm font-medium text-slate-200 hover:text-cyan-400",
					children: "How It Works"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 120,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("a", {
					href: "#features",
					onClick: () => setMobileMenuOpen(false),
					className: "block py-2 text-sm font-medium text-slate-200 hover:text-cyan-400",
					children: "Features"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 127,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("a", {
					href: "#technology",
					onClick: () => setMobileMenuOpen(false),
					className: "block py-2 text-sm font-medium text-slate-200 hover:text-cyan-400",
					children: "Technology"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 134,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("a", {
					href: "#pricing",
					onClick: () => setMobileMenuOpen(false),
					className: "block py-2 text-sm font-medium text-slate-200 hover:text-cyan-400",
					children: "Pricing"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 141,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("a", {
					href: "#faq",
					onClick: () => setMobileMenuOpen(false),
					className: "block py-2 text-sm font-medium text-slate-200 hover:text-cyan-400",
					children: "FAQ"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 148,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "pt-2 flex flex-col gap-2",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => {
								setMobileMenuOpen(false);
								handleDownloadZip();
							},
							disabled: isDownloading,
							className: "w-full flex items-center justify-center gap-2 py-2.5 text-xs font-medium text-slate-200 bg-white/[0.05] border border-white/[0.1] rounded-lg cursor-pointer disabled:opacity-50",
							children: [isDownloading ? /* @__PURE__ */ _jsxDEV(Loader2, { className: "h-4 w-4 text-cyan-400 animate-spin" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 165,
								columnNumber: 17
							}, this) : /* @__PURE__ */ _jsxDEV(Download, { className: "h-4 w-4 text-cyan-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 167,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: isDownloading ? "Packing ZIP..." : "Download Project ZIP (for GitHub)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 169,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 156,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => {
								setMobileMenuOpen(false);
								onOpenMobileGuide();
							},
							className: "w-full flex items-center justify-center gap-2 py-2.5 text-xs font-medium text-slate-200 bg-white/[0.05] border border-white/[0.1] rounded-lg",
							children: [/* @__PURE__ */ _jsxDEV(Smartphone, { className: "h-4 w-4 text-cyan-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 178,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Mobile URL & Deployment" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 179,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 171,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => {
								setMobileMenuOpen(false);
								onAnalyzeClick();
							},
							className: "w-full py-2.5 text-xs font-semibold text-black bg-cyan-400 hover:bg-cyan-300 rounded-lg text-center cursor-pointer",
							children: "Analyze Media"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 181,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 155,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 112,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLGFBQWEsTUFBTSxHQUFHLFlBQVksVUFBVSxlQUFlO0FBQ3BFLFNBQVMsMEJBQTBCOzs7QUFPbkMsT0FBTyxNQUFNLFVBQWlDLEVBQUUsZ0JBQWdCLHdCQUF3QjtDQUN0RixNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLEtBQUs7Q0FDMUQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsS0FBSztDQUV4RCxNQUFNLG9CQUFvQixZQUFZO0VBQ3BDLElBQUk7R0FDRixpQkFBaUIsSUFBSTtHQUNyQixNQUFNLG1CQUFtQjtFQUMzQixTQUFTLEdBQUc7R0FDVixRQUFRLE1BQU0sbUJBQW1CLENBQUM7RUFDcEMsVUFBVTtHQUNSLGlCQUFpQixLQUFLO0VBQ3hCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLFVBQUQ7RUFBUSxXQUFVO1lBQWxCLENBQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUVFLHdCQUFDLEtBQUQ7S0FBRyxNQUFLO0tBQUksV0FBVTtlQUF0QixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLGFBQUQsRUFBYSxXQUFVLFVBQVc7Ozs7O0tBQy9COzs7O2VBQ0wsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCLENBQTBHLFdBQ2pHLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFvRTtNQUFROzs7O2NBQy9GOzs7OzthQUNMOzs7Ozs7SUFHSCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsS0FBRDtPQUFHLE1BQUs7T0FBVyxXQUFVO2lCQUFtRTtNQUU3Rjs7Ozs7TUFDSCx3QkFBQyxLQUFEO09BQUcsTUFBSztPQUFnQixXQUFVO2lCQUFtRTtNQUVsRzs7Ozs7TUFDSCx3QkFBQyxLQUFEO09BQUcsTUFBSztPQUFZLFdBQVU7aUJBQW1FO01BRTlGOzs7OztNQUNILHdCQUFDLEtBQUQ7T0FBRyxNQUFLO09BQWMsV0FBVTtpQkFBbUU7TUFFaEc7Ozs7O01BQ0gsd0JBQUMsS0FBRDtPQUFHLE1BQUs7T0FBVyxXQUFVO2lCQUFtRTtNQUU3Rjs7Ozs7TUFDSCx3QkFBQyxLQUFEO09BQUcsTUFBSztPQUFPLFdBQVU7aUJBQW1FO01BRXpGOzs7OztLQUNBOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsVUFBRDtPQUNFLFNBQVM7T0FDVCxVQUFVO09BQ1YsV0FBVTtPQUNWLE9BQU07aUJBSlIsQ0FNRyxnQkFDQyx3QkFBQyxTQUFELEVBQVMsV0FBVSx5Q0FBMEM7Ozs7a0JBRTdELHdCQUFDLFVBQUQsRUFBVSxXQUFVLDRCQUE2Qjs7OztpQkFFbkQsd0JBQUMsUUFBRCxZQUFPLGdCQUFnQixtQkFBbUIsZUFBcUI7Ozs7ZUFDekQ7Ozs7OztNQUNSLHdCQUFDLFVBQUQ7T0FDRSxTQUFTO09BQ1QsV0FBVTtPQUNWLE9BQU07aUJBSFIsQ0FLRSx3QkFBQyxZQUFELEVBQVksV0FBVSw0QkFBNkI7Ozs7aUJBQ25ELHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztlQUNoQjs7Ozs7O01BQ1Isd0JBQUMsVUFBRDtPQUNFLFNBQVM7T0FDVCxXQUFVO2lCQUNYO01BRU87Ozs7O0tBQ0w7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFdBQVU7TUFDVixjQUFXO2dCQUVYLHdCQUFDLFlBQUQsRUFBWSxXQUFVLFVBQVc7Ozs7O0tBQzNCOzs7O2VBQ1Isd0JBQUMsVUFBRDtNQUNFLGVBQWUsa0JBQWtCLENBQUMsY0FBYztNQUNoRCxXQUFVO01BQ1YsY0FBVztnQkFFVixpQkFBaUIsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7OztpQkFBSSx3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7OztLQUNuRTs7OzthQUNMOzs7Ozs7R0FDRjs7Ozs7WUFHSixrQkFDQyx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsS0FBRDtLQUNFLE1BQUs7S0FDTCxlQUFlLGtCQUFrQixLQUFLO0tBQ3RDLFdBQVU7ZUFDWDtJQUVFOzs7OztJQUNILHdCQUFDLEtBQUQ7S0FDRSxNQUFLO0tBQ0wsZUFBZSxrQkFBa0IsS0FBSztLQUN0QyxXQUFVO2VBQ1g7SUFFRTs7Ozs7SUFDSCx3QkFBQyxLQUFEO0tBQ0UsTUFBSztLQUNMLGVBQWUsa0JBQWtCLEtBQUs7S0FDdEMsV0FBVTtlQUNYO0lBRUU7Ozs7O0lBQ0gsd0JBQUMsS0FBRDtLQUNFLE1BQUs7S0FDTCxlQUFlLGtCQUFrQixLQUFLO0tBQ3RDLFdBQVU7ZUFDWDtJQUVFOzs7OztJQUNILHdCQUFDLEtBQUQ7S0FDRSxNQUFLO0tBQ0wsZUFBZSxrQkFBa0IsS0FBSztLQUN0QyxXQUFVO2VBQ1g7SUFFRTs7Ozs7SUFDSCx3QkFBQyxLQUFEO0tBQ0UsTUFBSztLQUNMLGVBQWUsa0JBQWtCLEtBQUs7S0FDdEMsV0FBVTtlQUNYO0lBRUU7Ozs7O0lBQ0gsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFVBQUQ7T0FDRSxlQUFlO1FBQ2Isa0JBQWtCLEtBQUs7UUFDdkIsa0JBQWtCO09BQ3BCO09BQ0EsVUFBVTtPQUNWLFdBQVU7aUJBTlosQ0FRRyxnQkFDQyx3QkFBQyxTQUFELEVBQVMsV0FBVSxxQ0FBc0M7Ozs7a0JBRXpELHdCQUFDLFVBQUQsRUFBVSxXQUFVLHdCQUF5Qjs7OztpQkFFL0Msd0JBQUMsUUFBRCxZQUFPLGdCQUFnQixtQkFBbUIsb0NBQTBDOzs7O2VBQzlFOzs7Ozs7TUFDUix3QkFBQyxVQUFEO09BQ0UsZUFBZTtRQUNiLGtCQUFrQixLQUFLO1FBQ3ZCLGtCQUFrQjtPQUNwQjtPQUNBLFdBQVU7aUJBTFosQ0FPRSx3QkFBQyxZQUFELEVBQVksV0FBVSx3QkFBeUI7Ozs7aUJBQy9DLHdCQUFDLFFBQUQsWUFBTSwwQkFBNkI7Ozs7ZUFDN0I7Ozs7OztNQUNSLHdCQUFDLFVBQUQ7T0FDRSxlQUFlO1FBQ2Isa0JBQWtCLEtBQUs7UUFDdkIsZUFBZTtPQUNqQjtPQUNBLFdBQVU7aUJBQ1g7TUFFTzs7Ozs7S0FDTDs7Ozs7O0dBQ0Y7Ozs7O1VBRUQ7Ozs7OztBQUVaIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk5hdmJhci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgU2hpZWxkQWxlcnQsIE1lbnUsIFgsIFNtYXJ0cGhvbmUsIERvd25sb2FkLCBMb2FkZXIyIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IGRvd25sb2FkUHJvamVjdFppcCB9IGZyb20gJy4uL3V0aWxzL3Byb2plY3REb3dubG9hZGVyJztcblxuaW50ZXJmYWNlIE5hdmJhclByb3BzIHtcbiAgb25BbmFseXplQ2xpY2s6ICgpID0+IHZvaWQ7XG4gIG9uT3Blbk1vYmlsZUd1aWRlOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgTmF2YmFyOiBSZWFjdC5GQzxOYXZiYXJQcm9wcz4gPSAoeyBvbkFuYWx5emVDbGljaywgb25PcGVuTW9iaWxlR3VpZGUgfSkgPT4ge1xuICBjb25zdCBbbW9iaWxlTWVudU9wZW4sIHNldE1vYmlsZU1lbnVPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2lzRG93bmxvYWRpbmcsIHNldElzRG93bmxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IGhhbmRsZURvd25sb2FkWmlwID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBzZXRJc0Rvd25sb2FkaW5nKHRydWUpO1xuICAgICAgYXdhaXQgZG93bmxvYWRQcm9qZWN0WmlwKCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcignRG93bmxvYWQgZXJyb3I6JywgZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzRG93bmxvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwic3RpY2t5IHRvcC0wIHotNTAgdy1mdWxsIGJvcmRlci1iIGJvcmRlci13aGl0ZS9bMC4wOF0gYmctWyMwMzA1MGFdLzgwIGJhY2tkcm9wLWJsdXIteGxcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXgtYXV0byBmbGV4IGgtMTggbWF4LXctN3hsIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTggcHgtNiBsZzpweC04XCI+XG4gICAgICAgIHsvKiBab25lIDE6IFNpbmdsZSB0ZXh0IGVsZW1lbnQgd29yZG1hcmsgKi99XG4gICAgICAgIDxhIGhyZWY9XCIjXCIgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSB3aGl0ZXNwYWNlLW5vd3JhcCBzaHJpbmstMCBncm91cFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTkgdy05IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWxnIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tY3lhbi01MDAvMjAgdG8tdmlvbGV0LTUwMC8yMCBib3JkZXIgYm9yZGVyLWN5YW4tNTAwLzMwIHRleHQtY3lhbi00MDAgZ3JvdXAtaG92ZXI6Ym9yZGVyLWN5YW4tNDAwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICA8U2hpZWxkQWxlcnQgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC13aGl0ZSBncm91cC1ob3Zlcjp0ZXh0LWN5YW4tMzAwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICBWRVJJVEFTPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1jeWFuLTQwMCBtbC0xIGZvbnQtbW9ubyB0ZXh0LXNtIHRyYWNraW5nLXdpZGVyIGZvbnQtc2VtaWJvbGRcIj5BSTwvc3Bhbj5cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvYT5cblxuICAgICAgICB7LyogWm9uZSAyOiA04oCTNSBjbGVhbiBzaW5nbGUtbGluZSB0ZXh0IG5hdmlnYXRpb24gbGlua3MgKi99XG4gICAgICAgIDxuYXYgY2xhc3NOYW1lPVwiaGlkZGVuIG1kOmZsZXggaXRlbXMtY2VudGVyIGdhcC04IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICA8YSBocmVmPVwiI2FuYWx5emVcIiBjbGFzc05hbWU9XCJob3Zlcjp0ZXh0LWN5YW4tNDAwIHRyYW5zaXRpb24tY29sb3JzIHdoaXRlc3BhY2Utbm93cmFwIHNocmluay0wXCI+XG4gICAgICAgICAgICBEZXRlY3Rpb24gU3R1ZGlvXG4gICAgICAgICAgPC9hPlxuICAgICAgICAgIDxhIGhyZWY9XCIjaG93LWl0LXdvcmtzXCIgY2xhc3NOYW1lPVwiaG92ZXI6dGV4dC1jeWFuLTQwMCB0cmFuc2l0aW9uLWNvbG9ycyB3aGl0ZXNwYWNlLW5vd3JhcCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgSG93IEl0IFdvcmtzXG4gICAgICAgICAgPC9hPlxuICAgICAgICAgIDxhIGhyZWY9XCIjZmVhdHVyZXNcIiBjbGFzc05hbWU9XCJob3Zlcjp0ZXh0LWN5YW4tNDAwIHRyYW5zaXRpb24tY29sb3JzIHdoaXRlc3BhY2Utbm93cmFwIHNocmluay0wXCI+XG4gICAgICAgICAgICBGZWF0dXJlc1xuICAgICAgICAgIDwvYT5cbiAgICAgICAgICA8YSBocmVmPVwiI3RlY2hub2xvZ3lcIiBjbGFzc05hbWU9XCJob3Zlcjp0ZXh0LWN5YW4tNDAwIHRyYW5zaXRpb24tY29sb3JzIHdoaXRlc3BhY2Utbm93cmFwIHNocmluay0wXCI+XG4gICAgICAgICAgICBUZWNobm9sb2d5XG4gICAgICAgICAgPC9hPlxuICAgICAgICAgIDxhIGhyZWY9XCIjcHJpY2luZ1wiIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtY3lhbi00MDAgdHJhbnNpdGlvbi1jb2xvcnMgd2hpdGVzcGFjZS1ub3dyYXAgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgIFByaWNpbmdcbiAgICAgICAgICA8L2E+XG4gICAgICAgICAgPGEgaHJlZj1cIiNmYXFcIiBjbGFzc05hbWU9XCJob3Zlcjp0ZXh0LWN5YW4tNDAwIHRyYW5zaXRpb24tY29sb3JzIHdoaXRlc3BhY2Utbm93cmFwIHNocmluay0wXCI+XG4gICAgICAgICAgICBGQVFcbiAgICAgICAgICA8L2E+XG4gICAgICAgIDwvbmF2PlxuXG4gICAgICAgIHsvKiBab25lIDM6IFByaW1hcnkgQWN0aW9uICsgRG93bmxvYWQgWklQICsgTW9iaWxlIEd1aWRlIGJ1dHRvbiAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gbWQ6ZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgc2hyaW5rLTBcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVEb3dubG9hZFppcH1cbiAgICAgICAgICAgIGRpc2FibGVkPXtpc0Rvd25sb2FkaW5nfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTIgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTMwMCBob3Zlcjp0ZXh0LXdoaXRlIGJnLXdoaXRlL1swLjA0XSBob3ZlcjpiZy13aGl0ZS9bMC4wOF0gYm9yZGVyIGJvcmRlci13aGl0ZS9bMC4wOF0gcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyB3aGl0ZXNwYWNlLW5vd3JhcCBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgIHRpdGxlPVwiRG93bmxvYWQgY29tcGxldGUgcHJvamVjdCBaSVAgdG8gdXBsb2FkIHRvIEdpdEh1YlwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAge2lzRG93bmxvYWRpbmcgPyAoXG4gICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cImgtMy41IHctMy41IHRleHQtY3lhbi00MDAgYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNSB0ZXh0LWN5YW4tNDAwXCIgLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8c3Bhbj57aXNEb3dubG9hZGluZyA/ICdQYWNraW5nIFpJUC4uLicgOiAnRG93bmxvYWQgWklQJ308L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17b25PcGVuTW9iaWxlR3VpZGV9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtMzAwIGhvdmVyOnRleHQtd2hpdGUgYmctd2hpdGUvWzAuMDRdIGhvdmVyOmJnLXdoaXRlL1swLjA4XSBib3JkZXIgYm9yZGVyLXdoaXRlL1swLjA4XSByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIHdoaXRlc3BhY2Utbm93cmFwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgIHRpdGxlPVwiTW9iaWxlIFB1YmxpYyBVUkwgSW5zdHJ1Y3Rpb25zXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8U21hcnRwaG9uZSBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNSB0ZXh0LWN5YW4tNDAwXCIgLz5cbiAgICAgICAgICAgIDxzcGFuPk1vYmlsZSBVUkw8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17b25BbmFseXplQ2xpY2t9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC01IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtYmxhY2sgYmctZ3JhZGllbnQtdG8tciBmcm9tLWN5YW4tNDAwIHRvLWN5YW4tMzAwIGhvdmVyOmZyb20tY3lhbi0zMDAgaG92ZXI6dG8td2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctWzBfMF8yMHB4X3JnYmEoNiwxODIsMjEyLDAuMyldIHRyYW5zaXRpb24tYWxsIHdoaXRlc3BhY2Utbm93cmFwIGN1cnNvci1wb2ludGVyIGFjdGl2ZTpzY2FsZS05NVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgQW5hbHl6ZSBNZWRpYVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogTW9iaWxlIG1lbnUgdHJpZ2dlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1kOmhpZGRlbiBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbk9wZW5Nb2JpbGVHdWlkZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXNsYXRlLTMwMCBob3Zlcjp0ZXh0LWN5YW4tNDAwIGJnLXdoaXRlL1swLjA1XSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMDhdXCJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJNb2JpbGUgSW5zdHJ1Y3Rpb25zXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8U21hcnRwaG9uZSBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNb2JpbGVNZW51T3BlbighbW9iaWxlTWVudU9wZW4pfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHRleHQtc2xhdGUtMzAwIGhvdmVyOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlRvZ2dsZSBuYXZpZ2F0aW9uIG1lbnVcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIHttb2JpbGVNZW51T3BlbiA/IDxYIGNsYXNzTmFtZT1cImgtNiB3LTZcIiAvPiA6IDxNZW51IGNsYXNzTmFtZT1cImgtNiB3LTZcIiAvPn1cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIE1vYmlsZSBkcmF3ZXIgKi99XG4gICAgICB7bW9iaWxlTWVudU9wZW4gJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmhpZGRlbiBib3JkZXItYiBib3JkZXItd2hpdGUvWzAuMDhdIGJnLVsjMDMwNTBhXS85NSBiYWNrZHJvcC1ibHVyLXhsIHB4LTYgcHktNCBzcGFjZS15LTNcIj5cbiAgICAgICAgICA8YVxuICAgICAgICAgICAgaHJlZj1cIiNhbmFseXplXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vYmlsZU1lbnVPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTIwMCBob3Zlcjp0ZXh0LWN5YW4tNDAwXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBEZXRlY3Rpb24gU3R1ZGlvXG4gICAgICAgICAgPC9hPlxuICAgICAgICAgIDxhXG4gICAgICAgICAgICBocmVmPVwiI2hvdy1pdC13b3Jrc1wiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNb2JpbGVNZW51T3BlbihmYWxzZSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS0yMDAgaG92ZXI6dGV4dC1jeWFuLTQwMFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgSG93IEl0IFdvcmtzXG4gICAgICAgICAgPC9hPlxuICAgICAgICAgIDxhXG4gICAgICAgICAgICBocmVmPVwiI2ZlYXR1cmVzXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vYmlsZU1lbnVPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTIwMCBob3Zlcjp0ZXh0LWN5YW4tNDAwXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBGZWF0dXJlc1xuICAgICAgICAgIDwvYT5cbiAgICAgICAgICA8YVxuICAgICAgICAgICAgaHJlZj1cIiN0ZWNobm9sb2d5XCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vYmlsZU1lbnVPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTIwMCBob3Zlcjp0ZXh0LWN5YW4tNDAwXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBUZWNobm9sb2d5XG4gICAgICAgICAgPC9hPlxuICAgICAgICAgIDxhXG4gICAgICAgICAgICBocmVmPVwiI3ByaWNpbmdcIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TW9iaWxlTWVudU9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtMjAwIGhvdmVyOnRleHQtY3lhbi00MDBcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIFByaWNpbmdcbiAgICAgICAgICA8L2E+XG4gICAgICAgICAgPGFcbiAgICAgICAgICAgIGhyZWY9XCIjZmFxXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vYmlsZU1lbnVPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTIwMCBob3Zlcjp0ZXh0LWN5YW4tNDAwXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBGQVFcbiAgICAgICAgICA8L2E+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIGZsZXggZmxleC1jb2wgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgIHNldE1vYmlsZU1lbnVPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgICAgICBoYW5kbGVEb3dubG9hZFppcCgpO1xuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICBkaXNhYmxlZD17aXNEb3dubG9hZGluZ31cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHB5LTIuNSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtMjAwIGJnLXdoaXRlL1swLjA1XSBib3JkZXIgYm9yZGVyLXdoaXRlL1swLjFdIHJvdW5kZWQtbGcgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtpc0Rvd25sb2FkaW5nID8gKFxuICAgICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1jeWFuLTQwMCBhbmltYXRlLXNwaW5cIiAvPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtY3lhbi00MDBcIiAvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8c3Bhbj57aXNEb3dubG9hZGluZyA/ICdQYWNraW5nIFpJUC4uLicgOiAnRG93bmxvYWQgUHJvamVjdCBaSVAgKGZvciBHaXRIdWIpJ308L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgIHNldE1vYmlsZU1lbnVPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgICAgICBvbk9wZW5Nb2JpbGVHdWlkZSgpO1xuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcHktMi41IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS0yMDAgYmctd2hpdGUvWzAuMDVdIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMV0gcm91bmRlZC1sZ1wiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxTbWFydHBob25lIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1jeWFuLTQwMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPk1vYmlsZSBVUkwgJiBEZXBsb3ltZW50PC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRNb2JpbGVNZW51T3BlbihmYWxzZSk7XG4gICAgICAgICAgICAgICAgb25BbmFseXplQ2xpY2soKTtcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ibGFjayBiZy1jeWFuLTQwMCBob3ZlcjpiZy1jeWFuLTMwMCByb3VuZGVkLWxnIHRleHQtY2VudGVyIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgQW5hbHl6ZSBNZWRpYVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2hlYWRlcj5cbiAgKTtcbn07XG4iXX0=