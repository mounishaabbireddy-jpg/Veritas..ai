const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4c5f34d3";
import { Check } from "/node_modules/.vite/deps/lucide-react.js?v=4c5f34d3";
var _jsxFileName = "/app/applet/src/components/PricingSection.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4c5f34d3";
export const PricingSection = ({ onSelectPlan }) => {
	const [billingCycle, setBillingCycle] = useState("monthly");
	const plans = [
		{
			name: "Community Researcher",
			description: "Ideal for journalists, students, and fact-checkers conducting ad-hoc media analysis.",
			priceMonthly: 0,
			priceAnnual: 0,
			badge: "Free Tier",
			highlight: false,
			features: [
				"Up to 25 Image Inspections / day",
				"Standard Error Level Analysis (ELA)",
				"EXIF & Container Header Inspection",
				"Standard Heuristics Engine",
				"Web Studio Access",
				"Zero Data Retention"
			],
			cta: "Start Analyzing Free"
		},
		{
			name: "Professional Investigator",
			description: "Engineered for investigative reporters, digital forensics teams, and legal professionals.",
			priceMonthly: 49,
			priceAnnual: 39,
			badge: "Most Popular",
			highlight: true,
			features: [
				"Unlimited Image & Video Inspections",
				"High-Resolution 4K Video Scrutiny",
				"Corneal Specular Raytracing Audit",
				"Automated C2PA Manifest Verification",
				"Downloadable JSON & PDF Forensic Reports",
				"Interactive Canvas Filter Layers",
				"Priority Processing Queue"
			],
			cta: "Begin 14-Day Trial"
		},
		{
			name: "Enterprise Newsroom & SecOps",
			description: "Tailored for global media networks, intelligence agencies, and platform moderation teams.",
			priceMonthly: 299,
			priceAnnual: 239,
			badge: "Enterprise",
			highlight: false,
			features: [
				"Everything in Professional",
				"High-Throughput REST / gRPC API Access",
				"Batch Video Frame Scrutiny Pipelines",
				"Custom Fine-Tuned Domain Detectors",
				"Dedicated On-Premise / VPC Deployment",
				"99.9% Availability SLA & 24/7 Support",
				"Cryptographic Legal Evidence Export"
			],
			cta: "Contact Forensic Solutions"
		}
	];
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "pricing",
		className: "relative scroll-mt-20 py-24 px-6 lg:px-8 border-t border-white/[0.06] bg-[#030612]",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "mx-auto max-w-7xl",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "text-center max-w-3xl mx-auto mb-12",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "text-xs font-mono text-cyan-400 uppercase tracking-wider mb-2",
						children: "Transparent Plans"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-3xl sm:text-4xl font-extrabold text-white tracking-tight [text-wrap:balance]",
						children: "Forensic Intelligence at Any Scale"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-3 text-base text-slate-400",
						children: "Choose the tier tailored to your workflow, from rapid single-file checks to high-throughput newsroom ingestion."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-8 inline-flex items-center gap-1.5 p-1.5 bg-white/[0.04] rounded-xl border border-white/[0.08]",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setBillingCycle("monthly"),
							className: `px-4 py-2 text-xs font-semibold rounded-lg transition-all ${billingCycle === "monthly" ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm" : "text-slate-400 hover:text-white"}`,
							children: "Monthly Billing"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 85,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setBillingCycle("annual"),
							className: `flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all ${billingCycle === "annual" ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm" : "text-slate-400 hover:text-white"}`,
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "Annual Billing" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 103,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/30",
								children: "Save 20%"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 104,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 95,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 72,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch",
				children: plans.map((plan) => {
					const price = billingCycle === "annual" ? plan.priceAnnual : plan.priceMonthly;
					return /* @__PURE__ */ _jsxDEV("div", {
						className: `relative rounded-2xl p-8 backdrop-blur-xl flex flex-col justify-between transition-all ${plan.highlight ? "border-2 border-cyan-500/50 bg-[#060c1c]/90 shadow-[0_0_40px_rgba(6,182,212,0.15)] md:-translate-y-2" : "border border-white/[0.08] bg-white/[0.02] hover:border-white/[0.15]"}`,
						children: [
							plan.highlight && /* @__PURE__ */ _jsxDEV("div", {
								className: "absolute -top-3.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-cyan-400 text-black text-[10px] font-mono font-bold uppercase tracking-wider shadow-md",
								children: plan.badge
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between mb-3",
									children: [/* @__PURE__ */ _jsxDEV("h3", {
										className: "text-lg font-bold text-white",
										children: plan.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 134,
										columnNumber: 21
									}, this), !plan.highlight && /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] font-mono text-slate-400",
										children: plan.badge
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 138,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 133,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400 leading-relaxed min-h-[36px]",
									children: plan.description
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 144,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "my-6 pb-6 border-b border-white/[0.08] flex items-baseline gap-2",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-4xl font-extrabold text-white font-mono tabular-nums",
										children: ["$", price]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 150,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs text-slate-400 font-mono",
										children: ["/ month ", billingCycle === "annual" && price > 0 ? "(billed annually)" : ""]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 153,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 149,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-3 text-xs",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "text-[10px] font-mono uppercase tracking-wider text-slate-400",
										children: "Included Capabilities:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 160,
										columnNumber: 21
									}, this), plan.features.map((feature, fIdx) => /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2.5 text-slate-300",
										children: [/* @__PURE__ */ _jsxDEV(Check, { className: "h-4 w-4 text-cyan-400 shrink-0" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 165,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: feature }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 166,
											columnNumber: 25
										}, this)]
									}, fIdx, true, {
										fileName: _jsxFileName,
										lineNumber: 164,
										columnNumber: 23
									}, this))]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 159,
									columnNumber: 19
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 132,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "pt-8",
								children: /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => onSelectPlan(plan.name),
									className: `w-full py-3 px-4 text-xs font-semibold rounded-xl transition-all cursor-pointer ${plan.highlight ? "bg-gradient-to-r from-cyan-400 to-cyan-300 hover:from-cyan-300 hover:to-white text-black shadow-[0_0_20px_rgba(6,182,212,0.3)]" : "bg-white/[0.05] hover:bg-white/[0.1] text-white border border-white/[0.1]"}`,
									children: plan.cta
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 174,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 173,
								columnNumber: 17
							}, this)
						]
					}, plan.name, true, {
						fileName: _jsxFileName,
						lineNumber: 117,
						columnNumber: 15
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 112,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 69,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 68,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLGFBQW9DOzs7QUFNN0MsT0FBTyxNQUFNLGtCQUFpRCxFQUFFLG1CQUFtQjtDQUNqRixNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBK0IsU0FBUztDQUVoRixNQUFNLFFBQVE7RUFDWjtHQUNFLE1BQU07R0FDTixhQUFhO0dBQ2IsY0FBYztHQUNkLGFBQWE7R0FDYixPQUFPO0dBQ1AsV0FBVztHQUNYLFVBQVU7SUFDUjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7R0FDRjtHQUNBLEtBQUs7RUFDUDtFQUNBO0dBQ0UsTUFBTTtHQUNOLGFBQWE7R0FDYixjQUFjO0dBQ2QsYUFBYTtHQUNiLE9BQU87R0FDUCxXQUFXO0dBQ1gsVUFBVTtJQUNSO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0Y7R0FDQSxLQUFLO0VBQ1A7RUFDQTtHQUNFLE1BQU07R0FDTixhQUFhO0dBQ2IsY0FBYztHQUNkLGFBQWE7R0FDYixPQUFPO0dBQ1AsV0FBVztHQUNYLFVBQVU7SUFDUjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtHQUNGO0dBQ0EsS0FBSztFQUNQO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxJQUFHO0VBQVUsV0FBVTtZQUM5Qix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBR0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFnRTtLQUUxRTs7Ozs7S0FDTCx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBb0Y7S0FFOUY7Ozs7O0tBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWdDO0tBRTFDOzs7OztLQUdILHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRDtPQUNFLGVBQWUsZ0JBQWdCLFNBQVM7T0FDeEMsV0FBVyw2REFDVCxpQkFBaUIsWUFDYixxRUFDQTtpQkFFUDtNQUVPOzs7O2dCQUNSLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGdCQUFnQixRQUFRO09BQ3ZDLFdBQVcscUZBQ1QsaUJBQWlCLFdBQ2IscUVBQ0E7aUJBTFIsQ0FRRSx3QkFBQyxRQUFELFlBQU0saUJBQW9COzs7O2lCQUMxQix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBOEc7T0FFeEg7Ozs7ZUFDQTs7Ozs7Y0FDTDs7Ozs7O0lBQ0Y7Ozs7O2FBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDWixNQUFNLEtBQUssU0FBUztLQUNuQixNQUFNLFFBQVEsaUJBQWlCLFdBQVcsS0FBSyxjQUFjLEtBQUs7S0FFbEUsT0FDRSx3QkFBQyxPQUFEO01BRUUsV0FBVywwRkFDVCxLQUFLLFlBQ0QseUdBQ0E7Z0JBTFI7T0FTRyxLQUFLLGFBQ0osd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1osS0FBSztPQUNIOzs7OztPQUdQLHdCQUFDLE9BQUQ7UUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNYLEtBQUs7U0FDSjs7OzttQkFDSCxDQUFDLEtBQUssYUFDTCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFDYixLQUFLO1NBQ0Y7Ozs7aUJBRUw7Ozs7OztRQUVMLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUNWLEtBQUs7UUFDTDs7Ozs7UUFHSCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUE0RSxLQUN4RSxLQUNFOzs7OzttQkFDTix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FBbUQsWUFDeEMsaUJBQWlCLFlBQVksUUFBUSxJQUFJLHNCQUFzQixFQUNwRTs7Ozs7aUJBQ0g7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWdFO1NBRTFFOzs7O21CQUNKLEtBQUssU0FBUyxLQUFLLFNBQVMsU0FDM0Isd0JBQUMsT0FBRDtVQUFnQixXQUFVO29CQUExQixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLGlDQUFrQzs7OztvQkFDbkQsd0JBQUMsUUFBRCxZQUFPLFFBQWM7Ozs7a0JBQ2xCO1lBSEs7Ozs7Z0JBR0wsQ0FDTixDQUNFOzs7Ozs7T0FDRjs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxVQUFEO1NBQ0UsZUFBZSxhQUFhLEtBQUssSUFBSTtTQUNyQyxXQUFXLG1GQUNULEtBQUssWUFDRCxtSUFDQTttQkFHTCxLQUFLO1FBQ0E7Ozs7O09BQ0w7Ozs7O01BQ0Y7UUFuRUUsS0FBSzs7OztZQW1FUDtJQUVULENBQUM7R0FDRTs7OztXQUVGOzs7Ozs7Q0FDRTs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQcmljaW5nU2VjdGlvbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQ2hlY2ssIFNoaWVsZCwgU3BhcmtsZXMsIFphcCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmludGVyZmFjZSBQcmljaW5nU2VjdGlvblByb3BzIHtcbiAgb25TZWxlY3RQbGFuOiAocGxhbk5hbWU6IHN0cmluZykgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IFByaWNpbmdTZWN0aW9uOiBSZWFjdC5GQzxQcmljaW5nU2VjdGlvblByb3BzPiA9ICh7IG9uU2VsZWN0UGxhbiB9KSA9PiB7XG4gIGNvbnN0IFtiaWxsaW5nQ3ljbGUsIHNldEJpbGxpbmdDeWNsZV0gPSB1c2VTdGF0ZTwnbW9udGhseScgfCAnYW5udWFsJz4oJ21vbnRobHknKTtcblxuICBjb25zdCBwbGFucyA9IFtcbiAgICB7XG4gICAgICBuYW1lOiAnQ29tbXVuaXR5IFJlc2VhcmNoZXInLFxuICAgICAgZGVzY3JpcHRpb246ICdJZGVhbCBmb3Igam91cm5hbGlzdHMsIHN0dWRlbnRzLCBhbmQgZmFjdC1jaGVja2VycyBjb25kdWN0aW5nIGFkLWhvYyBtZWRpYSBhbmFseXNpcy4nLFxuICAgICAgcHJpY2VNb250aGx5OiAwLFxuICAgICAgcHJpY2VBbm51YWw6IDAsXG4gICAgICBiYWRnZTogJ0ZyZWUgVGllcicsXG4gICAgICBoaWdobGlnaHQ6IGZhbHNlLFxuICAgICAgZmVhdHVyZXM6IFtcbiAgICAgICAgJ1VwIHRvIDI1IEltYWdlIEluc3BlY3Rpb25zIC8gZGF5JyxcbiAgICAgICAgJ1N0YW5kYXJkIEVycm9yIExldmVsIEFuYWx5c2lzIChFTEEpJyxcbiAgICAgICAgJ0VYSUYgJiBDb250YWluZXIgSGVhZGVyIEluc3BlY3Rpb24nLFxuICAgICAgICAnU3RhbmRhcmQgSGV1cmlzdGljcyBFbmdpbmUnLFxuICAgICAgICAnV2ViIFN0dWRpbyBBY2Nlc3MnLFxuICAgICAgICAnWmVybyBEYXRhIFJldGVudGlvbicsXG4gICAgICBdLFxuICAgICAgY3RhOiAnU3RhcnQgQW5hbHl6aW5nIEZyZWUnLFxuICAgIH0sXG4gICAge1xuICAgICAgbmFtZTogJ1Byb2Zlc3Npb25hbCBJbnZlc3RpZ2F0b3InLFxuICAgICAgZGVzY3JpcHRpb246ICdFbmdpbmVlcmVkIGZvciBpbnZlc3RpZ2F0aXZlIHJlcG9ydGVycywgZGlnaXRhbCBmb3JlbnNpY3MgdGVhbXMsIGFuZCBsZWdhbCBwcm9mZXNzaW9uYWxzLicsXG4gICAgICBwcmljZU1vbnRobHk6IDQ5LFxuICAgICAgcHJpY2VBbm51YWw6IDM5LFxuICAgICAgYmFkZ2U6ICdNb3N0IFBvcHVsYXInLFxuICAgICAgaGlnaGxpZ2h0OiB0cnVlLFxuICAgICAgZmVhdHVyZXM6IFtcbiAgICAgICAgJ1VubGltaXRlZCBJbWFnZSAmIFZpZGVvIEluc3BlY3Rpb25zJyxcbiAgICAgICAgJ0hpZ2gtUmVzb2x1dGlvbiA0SyBWaWRlbyBTY3J1dGlueScsXG4gICAgICAgICdDb3JuZWFsIFNwZWN1bGFyIFJheXRyYWNpbmcgQXVkaXQnLFxuICAgICAgICAnQXV0b21hdGVkIEMyUEEgTWFuaWZlc3QgVmVyaWZpY2F0aW9uJyxcbiAgICAgICAgJ0Rvd25sb2FkYWJsZSBKU09OICYgUERGIEZvcmVuc2ljIFJlcG9ydHMnLFxuICAgICAgICAnSW50ZXJhY3RpdmUgQ2FudmFzIEZpbHRlciBMYXllcnMnLFxuICAgICAgICAnUHJpb3JpdHkgUHJvY2Vzc2luZyBRdWV1ZScsXG4gICAgICBdLFxuICAgICAgY3RhOiAnQmVnaW4gMTQtRGF5IFRyaWFsJyxcbiAgICB9LFxuICAgIHtcbiAgICAgIG5hbWU6ICdFbnRlcnByaXNlIE5ld3Nyb29tICYgU2VjT3BzJyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnVGFpbG9yZWQgZm9yIGdsb2JhbCBtZWRpYSBuZXR3b3JrcywgaW50ZWxsaWdlbmNlIGFnZW5jaWVzLCBhbmQgcGxhdGZvcm0gbW9kZXJhdGlvbiB0ZWFtcy4nLFxuICAgICAgcHJpY2VNb250aGx5OiAyOTksXG4gICAgICBwcmljZUFubnVhbDogMjM5LFxuICAgICAgYmFkZ2U6ICdFbnRlcnByaXNlJyxcbiAgICAgIGhpZ2hsaWdodDogZmFsc2UsXG4gICAgICBmZWF0dXJlczogW1xuICAgICAgICAnRXZlcnl0aGluZyBpbiBQcm9mZXNzaW9uYWwnLFxuICAgICAgICAnSGlnaC1UaHJvdWdocHV0IFJFU1QgLyBnUlBDIEFQSSBBY2Nlc3MnLFxuICAgICAgICAnQmF0Y2ggVmlkZW8gRnJhbWUgU2NydXRpbnkgUGlwZWxpbmVzJyxcbiAgICAgICAgJ0N1c3RvbSBGaW5lLVR1bmVkIERvbWFpbiBEZXRlY3RvcnMnLFxuICAgICAgICAnRGVkaWNhdGVkIE9uLVByZW1pc2UgLyBWUEMgRGVwbG95bWVudCcsXG4gICAgICAgICc5OS45JSBBdmFpbGFiaWxpdHkgU0xBICYgMjQvNyBTdXBwb3J0JyxcbiAgICAgICAgJ0NyeXB0b2dyYXBoaWMgTGVnYWwgRXZpZGVuY2UgRXhwb3J0JyxcbiAgICAgIF0sXG4gICAgICBjdGE6ICdDb250YWN0IEZvcmVuc2ljIFNvbHV0aW9ucycsXG4gICAgfSxcbiAgXTtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGlkPVwicHJpY2luZ1wiIGNsYXNzTmFtZT1cInJlbGF0aXZlIHNjcm9sbC1tdC0yMCBweS0yNCBweC02IGxnOnB4LTggYm9yZGVyLXQgYm9yZGVyLXdoaXRlL1swLjA2XSBiZy1bIzAzMDYxMl1cIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXgtYXV0byBtYXgtdy03eGxcIj5cbiAgICAgICAgXG4gICAgICAgIHsvKiBTZWN0aW9uIEhlYWRlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBtYXgtdy0zeGwgbXgtYXV0byBtYi0xMlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdGV4dC1jeWFuLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMlwiPlxuICAgICAgICAgICAgVHJhbnNwYXJlbnQgUGxhbnNcbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0zeGwgc206dGV4dC00eGwgZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSB0cmFja2luZy10aWdodCBbdGV4dC13cmFwOmJhbGFuY2VdXCI+XG4gICAgICAgICAgICBGb3JlbnNpYyBJbnRlbGxpZ2VuY2UgYXQgQW55IFNjYWxlXG4gICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0zIHRleHQtYmFzZSB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgQ2hvb3NlIHRoZSB0aWVyIHRhaWxvcmVkIHRvIHlvdXIgd29ya2Zsb3csIGZyb20gcmFwaWQgc2luZ2xlLWZpbGUgY2hlY2tzIHRvIGhpZ2gtdGhyb3VnaHB1dCBuZXdzcm9vbSBpbmdlc3Rpb24uXG4gICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgey8qIEJpbGxpbmcgU3dpdGNoZXIgKEludGVyYWN0aXZlIFNlZ21lbnRlZCBDb250cm9sKSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTggaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcC0xLjUgYmctd2hpdGUvWzAuMDRdIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci13aGl0ZS9bMC4wOF1cIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QmlsbGluZ0N5Y2xlKCdtb250aGx5Jyl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgIGJpbGxpbmdDeWNsZSA9PT0gJ21vbnRobHknXG4gICAgICAgICAgICAgICAgICA/ICdiZy1jeWFuLTUwMC8yMCB0ZXh0LWN5YW4tMzAwIGJvcmRlciBib3JkZXItY3lhbi01MDAvNDAgc2hhZG93LXNtJ1xuICAgICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIE1vbnRobHkgQmlsbGluZ1xuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEJpbGxpbmdDeWNsZSgnYW5udWFsJyl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgIGJpbGxpbmdDeWNsZSA9PT0gJ2FubnVhbCdcbiAgICAgICAgICAgICAgICAgID8gJ2JnLWN5YW4tNTAwLzIwIHRleHQtY3lhbi0zMDAgYm9yZGVyIGJvcmRlci1jeWFuLTUwMC80MCBzaGFkb3ctc20nXG4gICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPHNwYW4+QW5udWFsIEJpbGxpbmc8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtbW9ubyB0ZXh0LWVtZXJhbGQtNDAwIGJnLWVtZXJhbGQtNTAwLzEwIHB4LTEuNSBweS0wLjUgcm91bmRlZCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwXCI+XG4gICAgICAgICAgICAgICAgU2F2ZSAyMCVcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBQcmljaW5nIENhcmRzIEdyaWQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtOCBpdGVtcy1zdHJldGNoXCI+XG4gICAgICAgICAge3BsYW5zLm1hcCgocGxhbikgPT4ge1xuICAgICAgICAgICAgY29uc3QgcHJpY2UgPSBiaWxsaW5nQ3ljbGUgPT09ICdhbm51YWwnID8gcGxhbi5wcmljZUFubnVhbCA6IHBsYW4ucHJpY2VNb250aGx5O1xuXG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAga2V5PXtwbGFuLm5hbWV9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcmVsYXRpdmUgcm91bmRlZC0yeGwgcC04IGJhY2tkcm9wLWJsdXIteGwgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgIHBsYW4uaGlnaGxpZ2h0XG4gICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci0yIGJvcmRlci1jeWFuLTUwMC81MCBiZy1bIzA2MGMxY10vOTAgc2hhZG93LVswXzBfNDBweF9yZ2JhKDYsMTgyLDIxMiwwLjE1KV0gbWQ6LXRyYW5zbGF0ZS15LTInXG4gICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlciBib3JkZXItd2hpdGUvWzAuMDhdIGJnLXdoaXRlL1swLjAyXSBob3Zlcjpib3JkZXItd2hpdGUvWzAuMTVdJ1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgey8qIFRvcCBCYWRnZSAqL31cbiAgICAgICAgICAgICAgICB7cGxhbi5oaWdobGlnaHQgJiYgKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtdG9wLTMuNSBsZWZ0LTEvMiAtdHJhbnNsYXRlLXgtMS8yIHB4LTMgcHktMSByb3VuZGVkLWZ1bGwgYmctY3lhbi00MDAgdGV4dC1ibGFjayB0ZXh0LVsxMHB4XSBmb250LW1vbm8gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBzaGFkb3ctbWRcIj5cbiAgICAgICAgICAgICAgICAgICAge3BsYW4uYmFkZ2V9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7cGxhbi5uYW1lfVxuICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICB7IXBsYW4uaGlnaGxpZ2h0ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtwbGFuLmJhZGdlfVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGxlYWRpbmctcmVsYXhlZCBtaW4taC1bMzZweF1cIj5cbiAgICAgICAgICAgICAgICAgICAge3BsYW4uZGVzY3JpcHRpb259XG4gICAgICAgICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBQcmljZSBCbG9jayB3aXRoIFRhYnVsYXIgRmlndXJlcyAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXktNiBwYi02IGJvcmRlci1iIGJvcmRlci13aGl0ZS9bMC4wOF0gZmxleCBpdGVtcy1iYXNlbGluZSBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIGZvbnQtbW9ubyB0YWJ1bGFyLW51bXNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAke3ByaWNlfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICAgICAgLyBtb250aCB7YmlsbGluZ0N5Y2xlID09PSAnYW5udWFsJyAmJiBwcmljZSA+IDAgPyAnKGJpbGxlZCBhbm51YWxseSknIDogJyd9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7LyogRmVhdHVyZXMgTGlzdCAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LW1vbm8gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgSW5jbHVkZWQgQ2FwYWJpbGl0aWVzOlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAge3BsYW4uZmVhdHVyZXMubWFwKChmZWF0dXJlLCBmSWR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2ZJZHh9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVjayBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtY3lhbi00MDAgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2ZlYXR1cmV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIFBsYW4gQWN0aW9uIENUQSAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LThcIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25TZWxlY3RQbGFuKHBsYW4ubmFtZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBweS0zIHB4LTQgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICBwbGFuLmhpZ2hsaWdodFxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZ3JhZGllbnQtdG8tciBmcm9tLWN5YW4tNDAwIHRvLWN5YW4tMzAwIGhvdmVyOmZyb20tY3lhbi0zMDAgaG92ZXI6dG8td2hpdGUgdGV4dC1ibGFjayBzaGFkb3ctWzBfMF8yMHB4X3JnYmEoNiwxODIsMjEyLDAuMyldJ1xuICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctd2hpdGUvWzAuMDVdIGhvdmVyOmJnLXdoaXRlL1swLjFdIHRleHQtd2hpdGUgYm9yZGVyIGJvcmRlci13aGl0ZS9bMC4xXSdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtwbGFuLmN0YX1cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59O1xuIl19