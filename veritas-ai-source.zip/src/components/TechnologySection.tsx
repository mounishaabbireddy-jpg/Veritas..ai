const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4c5f34d3";
import { Cpu, Terminal, Shield, Binary } from "/node_modules/.vite/deps/lucide-react.js?v=4c5f34d3";
var _jsxFileName = "/app/applet/src/components/TechnologySection.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4c5f34d3";
export const TechnologySection = () => {
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "technology",
		className: "relative scroll-mt-20 py-24 px-6 lg:px-8 border-t border-white/[0.06] bg-[#020409]",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "mx-auto max-w-7xl",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-3xl mb-16",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "text-xs font-mono text-cyan-400 uppercase tracking-wider mb-2",
						children: "Scientific Foundation"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 11,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-3xl sm:text-4xl font-extrabold text-white tracking-tight [text-wrap:balance]",
						children: "Forensic Principles & Architecture"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 14,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-3 text-base text-slate-400",
						children: "Engineered upon validated digital forensics and optical sensor physics to distinguish physical light captures from latent algorithmic synthesis."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 17,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 10,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 lg:grid-cols-2 gap-8",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "rounded-2xl border border-white/[0.08] bg-[#050814] p-8 backdrop-blur-xl space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400",
									children: /* @__PURE__ */ _jsxDEV(Binary, { className: "h-5 w-5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 29,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 28,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-lg font-bold text-white",
									children: "Error Level Analysis (ELA) & Compression Gradients"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 32,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "text-[11px] font-mono text-slate-500",
									children: "Discrete Cosine Transform (DCT) Quantization"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 35,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 31,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 27,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs sm:text-sm text-slate-300 leading-relaxed",
								children: "When an authentic photo is captured by a camera, every 8x8 block is compressed uniformly in a single pass. When synthetic elements are generated or in-painted into an existing frame, the modified boundaries exhibit higher error rates during intentional re-compression. VERITAS AI generates differential pixel maps to reveal these invisible boundary anomalies."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 41,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "rounded-xl bg-black/60 border border-white/[0.06] p-4 font-mono text-xs text-slate-300 space-y-1.5",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-cyan-400 font-semibold",
										children: "Algorithm Formula:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 46,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-slate-400",
										children: "ΔE(x,y) = |I_orig(x,y) - I_quant85(x,y)| × γ"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 47,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-[11px] text-slate-500 pt-1",
										children: "Where γ = 16.0 scaling factor across sRGB color channels."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 48,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 45,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "rounded-2xl border border-white/[0.08] bg-[#050814] p-8 backdrop-blur-xl space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex h-10 w-10 items-center justify-center rounded-lg bg-violet-500/10 border border-violet-500/30 text-violet-400",
									children: /* @__PURE__ */ _jsxDEV(Cpu, { className: "h-5 w-5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 58,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 57,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-lg font-bold text-white",
									children: "Sensor PRNU vs. Deconvolution Noise"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 61,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "text-[11px] font-mono text-slate-500",
									children: "Photo-Response Non-Uniformity Verification"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 64,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 60,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 56,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs sm:text-sm text-slate-300 leading-relaxed",
								children: "Real camera sensors possess microscopic silicon imperfections called PRNU—an unforgeable hardware fingerprint embedded into every pixel. Diffusion models (Flux, Midjourney, Stable Diffusion) generate images without physical sensor noise; instead, their transposed convolution layers produce mathematical Nyquist harmonic spikes that do not exist in camera captures."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 70,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "rounded-xl bg-black/60 border border-white/[0.06] p-4 font-mono text-xs text-slate-300 space-y-1.5",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-violet-400 font-semibold",
										children: "Nyquist Power Spectrum:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 75,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-slate-400",
										children: "P(f_x, f_y) = |FFT(HighPass(I))|²"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 76,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-[11px] text-slate-500 pt-1",
										children: "Monitors radial frequency spikes at f = 0.5 cycles/pixel."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 77,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 74,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "rounded-2xl border border-white/[0.08] bg-[#050814] p-8 backdrop-blur-xl space-y-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400",
								children: /* @__PURE__ */ _jsxDEV(Terminal, { className: "h-5 w-5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 87,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 86,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-lg font-bold text-white",
								children: "Temporal Optical Flow & Latent Space Drift"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 90,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[11px] font-mono text-slate-500",
								children: "Video Deepfake Frame Stability"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 93,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 85,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs sm:text-sm text-slate-300 leading-relaxed",
							children: "Video diffusion models generate sequences in temporal latent space chunks. Because 3D physical permanence is not inherently modeled, fine details such as earlobes, teeth, and background brickwork drift subtly from keyframe to keyframe. VERITAS tracks optical motion vectors across temporal slices to detect this latent distortion."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "rounded-2xl border border-white/[0.08] bg-[#050814] p-8 backdrop-blur-xl space-y-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex h-10 w-10 items-center justify-center rounded-lg bg-violet-500/10 border border-violet-500/30 text-violet-400",
								children: /* @__PURE__ */ _jsxDEV(Shield, { className: "h-5 w-5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 108,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 107,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-lg font-bold text-white",
								children: "Cryptographic Provenance (C2PA)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 111,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[11px] font-mono text-slate-500",
								children: "Coalition for Content Provenance and Authenticity"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 114,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 110,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 106,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs sm:text-sm text-slate-300 leading-relaxed",
							children: "While heuristic detection evaluates observable visual signals, true zero-trust media verification relies on cryptographic chains of custody. VERITAS audits embedded C2PA manifests signed by camera hardware (e.g., Leica M11-P, Sony α9 III) to verify authentic origin or uncover synthetic AI metadata markers."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 120,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 105,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 7,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 6,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsS0FBSyxVQUFVLFFBQW1CLGNBQWM7OztBQUV6RCxPQUFPLE1BQU0sMEJBQW9DO0NBQy9DLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLElBQUc7RUFBYSxXQUFVO1lBQ2pDLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FHRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWdFO0tBRTFFOzs7OztLQUNMLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFvRjtLQUU5Rjs7Ozs7S0FDSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBZ0M7S0FFMUM7Ozs7O0lBQ0E7Ozs7O2FBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUdFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7OztRQUMxQjs7OztrQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQStCO1FBRXpDOzs7O2tCQUNKLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUF1QztRQUVqRDs7OztnQkFDRjs7OztnQkFDRjs7Ozs7O09BRUwsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQW9EO09BRTlEOzs7OztPQUVILHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQThCO1NBQXVCOzs7OztTQUNwRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBaUI7U0FBaUQ7Ozs7O1NBQ2pGLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFrQztTQUU1Qzs7Ozs7UUFDRjs7Ozs7O01BQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxLQUFELEVBQUssV0FBVSxVQUFXOzs7OztRQUN2Qjs7OztrQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQStCO1FBRXpDOzs7O2tCQUNKLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUF1QztRQUVqRDs7OztnQkFDRjs7OztnQkFDRjs7Ozs7O09BRUwsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQW9EO09BRTlEOzs7OztPQUVILHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWdDO1NBQTRCOzs7OztTQUMzRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBaUI7U0FBc0M7Ozs7O1NBQ3RFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFrQztTQUU1Qzs7Ozs7UUFDRjs7Ozs7O01BQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7OztPQUM1Qjs7OztpQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQStCO09BRXpDOzs7O2lCQUNKLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUF1QztPQUVqRDs7OztlQUNGOzs7O2VBQ0Y7Ozs7O2dCQUVMLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFvRDtNQUU5RDs7OztjQUNBOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7Ozs7T0FDMUI7Ozs7aUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUErQjtPQUV6Qzs7OztpQkFDSix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBdUM7T0FFakQ7Ozs7ZUFDRjs7OztlQUNGOzs7OztnQkFFTCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBb0Q7TUFFOUQ7Ozs7Y0FDQTs7Ozs7O0lBRUY7Ozs7O1dBRUY7Ozs7OztDQUNFOzs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlRlY2hub2xvZ3lTZWN0aW9uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQ3B1LCBUZXJtaW5hbCwgU2hpZWxkLCBHaXRDb21taXQsIEJpbmFyeSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmV4cG9ydCBjb25zdCBUZWNobm9sb2d5U2VjdGlvbjogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gaWQ9XCJ0ZWNobm9sb2d5XCIgY2xhc3NOYW1lPVwicmVsYXRpdmUgc2Nyb2xsLW10LTIwIHB5LTI0IHB4LTYgbGc6cHgtOCBib3JkZXItdCBib3JkZXItd2hpdGUvWzAuMDZdIGJnLVsjMDIwNDA5XVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LTd4bFwiPlxuICAgICAgICBcbiAgICAgICAgey8qIFNlY3Rpb24gSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTN4bCBtYi0xNlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdGV4dC1jeWFuLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMlwiPlxuICAgICAgICAgICAgU2NpZW50aWZpYyBGb3VuZGF0aW9uXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtM3hsIHNtOnRleHQtNHhsIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHQgW3RleHQtd3JhcDpiYWxhbmNlXVwiPlxuICAgICAgICAgICAgRm9yZW5zaWMgUHJpbmNpcGxlcyAmIEFyY2hpdGVjdHVyZVxuICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LWJhc2UgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgIEVuZ2luZWVyZWQgdXBvbiB2YWxpZGF0ZWQgZGlnaXRhbCBmb3JlbnNpY3MgYW5kIG9wdGljYWwgc2Vuc29yIHBoeXNpY3MgdG8gZGlzdGluZ3Vpc2ggcGh5c2ljYWwgbGlnaHQgY2FwdHVyZXMgZnJvbSBsYXRlbnQgYWxnb3JpdGhtaWMgc3ludGhlc2lzLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIDItQ29sdW1uIERlZXAgRGl2ZSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0yIGdhcC04XCI+XG4gICAgICAgICAgXG4gICAgICAgICAgey8qIFRlY2ggQmxvY2sgMTogRXJyb3IgTGV2ZWwgQW5hbHlzaXMgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXdoaXRlL1swLjA4XSBiZy1bIzA1MDgxNF0gcC04IGJhY2tkcm9wLWJsdXIteGwgc3BhY2UteS00XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTEwIHctMTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbGcgYmctY3lhbi01MDAvMTAgYm9yZGVyIGJvcmRlci1jeWFuLTUwMC8zMCB0ZXh0LWN5YW4tNDAwXCI+XG4gICAgICAgICAgICAgICAgPEJpbmFyeSBjbGFzc05hbWU9XCJoLTUgdy01XCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgIEVycm9yIExldmVsIEFuYWx5c2lzIChFTEEpICYgQ29tcHJlc3Npb24gR3JhZGllbnRzXG4gICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtbW9ubyB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgRGlzY3JldGUgQ29zaW5lIFRyYW5zZm9ybSAoRENUKSBRdWFudGl6YXRpb25cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBzbTp0ZXh0LXNtIHRleHQtc2xhdGUtMzAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICBXaGVuIGFuIGF1dGhlbnRpYyBwaG90byBpcyBjYXB0dXJlZCBieSBhIGNhbWVyYSwgZXZlcnkgOHg4IGJsb2NrIGlzIGNvbXByZXNzZWQgdW5pZm9ybWx5IGluIGEgc2luZ2xlIHBhc3MuIFdoZW4gc3ludGhldGljIGVsZW1lbnRzIGFyZSBnZW5lcmF0ZWQgb3IgaW4tcGFpbnRlZCBpbnRvIGFuIGV4aXN0aW5nIGZyYW1lLCB0aGUgbW9kaWZpZWQgYm91bmRhcmllcyBleGhpYml0IGhpZ2hlciBlcnJvciByYXRlcyBkdXJpbmcgaW50ZW50aW9uYWwgcmUtY29tcHJlc3Npb24uIFZFUklUQVMgQUkgZ2VuZXJhdGVzIGRpZmZlcmVudGlhbCBwaXhlbCBtYXBzIHRvIHJldmVhbCB0aGVzZSBpbnZpc2libGUgYm91bmRhcnkgYW5vbWFsaWVzLlxuICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYmctYmxhY2svNjAgYm9yZGVyIGJvcmRlci13aGl0ZS9bMC4wNl0gcC00IGZvbnQtbW9ubyB0ZXh0LXhzIHRleHQtc2xhdGUtMzAwIHNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jeWFuLTQwMCBmb250LXNlbWlib2xkXCI+QWxnb3JpdGhtIEZvcm11bGE6PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj7OlEUoeCx5KSA9IHxJX29yaWcoeCx5KSAtIElfcXVhbnQ4NSh4LHkpfCDDlyDOszwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwIHB0LTFcIj5cbiAgICAgICAgICAgICAgICBXaGVyZSDOsyA9IDE2LjAgc2NhbGluZyBmYWN0b3IgYWNyb3NzIHNSR0IgY29sb3IgY2hhbm5lbHMuXG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogVGVjaCBCbG9jayAyOiBQUk5VIFNlbnNvciBOb2lzZSB2cyBHZW5lcmF0aXZlIFVwc2NhbGVycyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMDhdIGJnLVsjMDUwODE0XSBwLTggYmFja2Ryb3AtYmx1ci14bCBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtMTAgdy0xMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1sZyBiZy12aW9sZXQtNTAwLzEwIGJvcmRlciBib3JkZXItdmlvbGV0LTUwMC8zMCB0ZXh0LXZpb2xldC00MDBcIj5cbiAgICAgICAgICAgICAgICA8Q3B1IGNsYXNzTmFtZT1cImgtNSB3LTVcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgU2Vuc29yIFBSTlUgdnMuIERlY29udm9sdXRpb24gTm9pc2VcbiAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1tb25vIHRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICAgICAgICBQaG90by1SZXNwb25zZSBOb24tVW5pZm9ybWl0eSBWZXJpZmljYXRpb25cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBzbTp0ZXh0LXNtIHRleHQtc2xhdGUtMzAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICBSZWFsIGNhbWVyYSBzZW5zb3JzIHBvc3Nlc3MgbWljcm9zY29waWMgc2lsaWNvbiBpbXBlcmZlY3Rpb25zIGNhbGxlZCBQUk5V4oCUYW4gdW5mb3JnZWFibGUgaGFyZHdhcmUgZmluZ2VycHJpbnQgZW1iZWRkZWQgaW50byBldmVyeSBwaXhlbC4gRGlmZnVzaW9uIG1vZGVscyAoRmx1eCwgTWlkam91cm5leSwgU3RhYmxlIERpZmZ1c2lvbikgZ2VuZXJhdGUgaW1hZ2VzIHdpdGhvdXQgcGh5c2ljYWwgc2Vuc29yIG5vaXNlOyBpbnN0ZWFkLCB0aGVpciB0cmFuc3Bvc2VkIGNvbnZvbHV0aW9uIGxheWVycyBwcm9kdWNlIG1hdGhlbWF0aWNhbCBOeXF1aXN0IGhhcm1vbmljIHNwaWtlcyB0aGF0IGRvIG5vdCBleGlzdCBpbiBjYW1lcmEgY2FwdHVyZXMuXG4gICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC14bCBiZy1ibGFjay82MCBib3JkZXIgYm9yZGVyLXdoaXRlL1swLjA2XSBwLTQgZm9udC1tb25vIHRleHQteHMgdGV4dC1zbGF0ZS0zMDAgc3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC00MDAgZm9udC1zZW1pYm9sZFwiPk55cXVpc3QgUG93ZXIgU3BlY3RydW06PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj5QKGZfeCwgZl95KSA9IHxGRlQoSGlnaFBhc3MoSSkpfMKyPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgcHQtMVwiPlxuICAgICAgICAgICAgICAgIE1vbml0b3JzIHJhZGlhbCBmcmVxdWVuY3kgc3Bpa2VzIGF0IGYgPSAwLjUgY3ljbGVzL3BpeGVsLlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFRlY2ggQmxvY2sgMzogVmlkZW8gVGVtcG9yYWwgQ29uc2lzdGVuY3kgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXdoaXRlL1swLjA4XSBiZy1bIzA1MDgxNF0gcC04IGJhY2tkcm9wLWJsdXIteGwgc3BhY2UteS00XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTEwIHctMTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbGcgYmctY3lhbi01MDAvMTAgYm9yZGVyIGJvcmRlci1jeWFuLTUwMC8zMCB0ZXh0LWN5YW4tNDAwXCI+XG4gICAgICAgICAgICAgICAgPFRlcm1pbmFsIGNsYXNzTmFtZT1cImgtNSB3LTVcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgVGVtcG9yYWwgT3B0aWNhbCBGbG93ICYgTGF0ZW50IFNwYWNlIERyaWZ0XG4gICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtbW9ubyB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgVmlkZW8gRGVlcGZha2UgRnJhbWUgU3RhYmlsaXR5XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgc206dGV4dC1zbSB0ZXh0LXNsYXRlLTMwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgVmlkZW8gZGlmZnVzaW9uIG1vZGVscyBnZW5lcmF0ZSBzZXF1ZW5jZXMgaW4gdGVtcG9yYWwgbGF0ZW50IHNwYWNlIGNodW5rcy4gQmVjYXVzZSAzRCBwaHlzaWNhbCBwZXJtYW5lbmNlIGlzIG5vdCBpbmhlcmVudGx5IG1vZGVsZWQsIGZpbmUgZGV0YWlscyBzdWNoIGFzIGVhcmxvYmVzLCB0ZWV0aCwgYW5kIGJhY2tncm91bmQgYnJpY2t3b3JrIGRyaWZ0IHN1YnRseSBmcm9tIGtleWZyYW1lIHRvIGtleWZyYW1lLiBWRVJJVEFTIHRyYWNrcyBvcHRpY2FsIG1vdGlvbiB2ZWN0b3JzIGFjcm9zcyB0ZW1wb3JhbCBzbGljZXMgdG8gZGV0ZWN0IHRoaXMgbGF0ZW50IGRpc3RvcnRpb24uXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogVGVjaCBCbG9jayA0OiBDMlBBICYgQ29udGVudCBDcmVkZW50aWFscyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMDhdIGJnLVsjMDUwODE0XSBwLTggYmFja2Ryb3AtYmx1ci14bCBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtMTAgdy0xMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1sZyBiZy12aW9sZXQtNTAwLzEwIGJvcmRlciBib3JkZXItdmlvbGV0LTUwMC8zMCB0ZXh0LXZpb2xldC00MDBcIj5cbiAgICAgICAgICAgICAgICA8U2hpZWxkIGNsYXNzTmFtZT1cImgtNSB3LTVcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgQ3J5cHRvZ3JhcGhpYyBQcm92ZW5hbmNlIChDMlBBKVxuICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8gdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgIENvYWxpdGlvbiBmb3IgQ29udGVudCBQcm92ZW5hbmNlIGFuZCBBdXRoZW50aWNpdHlcbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBzbTp0ZXh0LXNtIHRleHQtc2xhdGUtMzAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICBXaGlsZSBoZXVyaXN0aWMgZGV0ZWN0aW9uIGV2YWx1YXRlcyBvYnNlcnZhYmxlIHZpc3VhbCBzaWduYWxzLCB0cnVlIHplcm8tdHJ1c3QgbWVkaWEgdmVyaWZpY2F0aW9uIHJlbGllcyBvbiBjcnlwdG9ncmFwaGljIGNoYWlucyBvZiBjdXN0b2R5LiBWRVJJVEFTIGF1ZGl0cyBlbWJlZGRlZCBDMlBBIG1hbmlmZXN0cyBzaWduZWQgYnkgY2FtZXJhIGhhcmR3YXJlIChlLmcuLCBMZWljYSBNMTEtUCwgU29ueSDOsTkgSUlJKSB0byB2ZXJpZnkgYXV0aGVudGljIG9yaWdpbiBvciB1bmNvdmVyIHN5bnRoZXRpYyBBSSBtZXRhZGF0YSBtYXJrZXJzLlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDwvZGl2PlxuXG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59O1xuIl19