const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4c5f34d3";
import { ChevronDown, ChevronUp } from "/node_modules/.vite/deps/lucide-react.js?v=4c5f34d3";
var _jsxFileName = "/app/applet/src/components/FaqSection.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4c5f34d3";
export const FaqSection = () => {
	const [openIdx, setOpenIdx] = useState(0);
	const faqs = [
		{
			question: "Can any automated AI detection engine be 100% accurate?",
			answer: "No. Anyone claiming 100% certainty in synthetic media detection is misrepresenting the technology. Generative models evolve rapidly, and benign post-processing (such as resizing, compression, or contrast tuning) can mimic or obscure synthetic markers. VERITAS AI intentionally provides transparent confidence intervals, uncertainty margins, and explainable signal vectors rather than opaque binary verdicts."
		},
		{
			question: "Why are verdicts categorized strictly into \"Likely AI-generated\", \"Likely authentic\", and \"Inconclusive\"?",
			answer: "Because responsible digital forensics requires acknowledging empirical limitations. \"Likely AI-generated\" signifies that multiple independent vectors (such as corneal reflection dissonance and frequency deconvolution spikes) corroborate synthetic origin. \"Likely authentic\" means the media conforms to physical sensor optics and intact hardware telemetry. \"Inconclusive\" is rendered when lossy compression or insufficient signal prevents reliable determination."
		},
		{
			question: "How does video analysis differ from static image analysis?",
			answer: "Video inspection introduces a temporal dimension. In addition to per-frame spatial deconstruction, VERITAS analyzes inter-frame optical flow consistency, micro-motion jitter, face warp variance, and biometric cadence (such as natural eye blink durations). Generative video models frequently struggle with 3D physical persistence across temporal latent space keyframes."
		},
		{
			question: "Does social media compression (e.g. WhatsApp, Instagram, X) interfere with detection?",
			answer: "Yes. Aggressive social media transcoding strips original EXIF metadata and applies heavy Discrete Cosine Transform (DCT) quantization, which can erase subtle CMOS sensor PRNU noise. In such situations, VERITAS correctly flags the result as \"Inconclusive\" to avoid deceptive false positives."
		},
		{
			question: "What role does C2PA (Content Credentials) play in media verification?",
			answer: "C2PA is an open technical standard developed by the Coalition for Content Provenance and Authenticity. It cryptographically binds origin metadata, edits, and author credentials directly into the media container using public-key cryptography. When present, C2PA provides tamper-evident provenance that surpasses heuristic analysis."
		},
		{
			question: "Is my media kept private when analyzed?",
			answer: "Yes. All file inspection, canvas Error Level Analysis, and metadata extractions occur ephemerally in your active browser session. Files are never stored on persistent disks, logged, or used to train any artificial intelligence models."
		}
	];
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "faq",
		className: "relative scroll-mt-20 py-24 px-6 lg:px-8 border-t border-white/[0.06] bg-[#020409]",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "mx-auto max-w-4xl",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "text-center max-w-2xl mx-auto mb-16",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "text-xs font-mono text-cyan-400 uppercase tracking-wider mb-2",
						children: "Verification Answers"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-3xl sm:text-4xl font-extrabold text-white tracking-tight [text-wrap:balance]",
						children: "Frequently Asked Questions"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-3 text-base text-slate-400",
						children: "Understand the capabilities, forensic methodologies, and scientific constraints of synthetic media detection."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 45,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-4",
				children: faqs.map((faq, idx) => {
					const isOpen = openIdx === idx;
					return /* @__PURE__ */ _jsxDEV("div", {
						className: "rounded-2xl border border-white/[0.08] bg-white/[0.02] hover:bg-white/[0.04] transition-all overflow-hidden",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setOpenIdx(isOpen ? null : idx),
							className: "w-full flex items-center justify-between p-6 text-left cursor-pointer",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-base font-semibold text-white pr-4",
								children: faq.question
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 70,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex h-8 w-8 items-center justify-center rounded-lg bg-white/[0.04] text-cyan-400 shrink-0",
								children: isOpen ? /* @__PURE__ */ _jsxDEV(ChevronUp, { className: "h-4 w-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 74,
									columnNumber: 31
								}, this) : /* @__PURE__ */ _jsxDEV(ChevronDown, { className: "h-4 w-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 74,
									columnNumber: 67
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 73,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 17
						}, this), isOpen && /* @__PURE__ */ _jsxDEV("div", {
							className: "px-6 pb-6 pt-2 border-t border-white/[0.04] text-sm text-slate-300 leading-relaxed",
							children: faq.answer
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 19
						}, this)]
					}, idx, true, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 15
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 42,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLGFBQWEsaUJBQTZCOzs7QUFFbkQsT0FBTyxNQUFNLG1CQUE2QjtDQUN4QyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQXdCLENBQUM7Q0FFdkQsTUFBTSxPQUFPO0VBQ1g7R0FDRSxVQUFVO0dBQ1YsUUFDRTtFQUNKO0VBQ0E7R0FDRSxVQUFVO0dBQ1YsUUFDRTtFQUNKO0VBQ0E7R0FDRSxVQUFVO0dBQ1YsUUFDRTtFQUNKO0VBQ0E7R0FDRSxVQUFVO0dBQ1YsUUFDRTtFQUNKO0VBQ0E7R0FDRSxVQUFVO0dBQ1YsUUFDRTtFQUNKO0VBQ0E7R0FDRSxVQUFVO0dBQ1YsUUFDRTtFQUNKO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxJQUFHO0VBQU0sV0FBVTtZQUMxQix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBR0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFnRTtLQUUxRTs7Ozs7S0FDTCx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBb0Y7S0FFOUY7Ozs7O0tBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWdDO0tBRTFDOzs7OztJQUNBOzs7OzthQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osS0FBSyxLQUFLLEtBQUssUUFBUTtLQUN0QixNQUFNLFNBQVMsWUFBWTtLQUMzQixPQUNFLHdCQUFDLE9BQUQ7TUFFRSxXQUFVO2dCQUZaLENBSUUsd0JBQUMsVUFBRDtPQUNFLGVBQWUsV0FBVyxTQUFTLE9BQU8sR0FBRztPQUM3QyxXQUFVO2lCQUZaLENBSUUsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsSUFBSTtPQUNEOzs7O2lCQUNOLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaLFNBQVMsd0JBQUMsV0FBRCxFQUFXLFdBQVUsVUFBVzs7OzttQkFBSSx3QkFBQyxhQUFELEVBQWEsV0FBVSxVQUFXOzs7OztPQUM3RTs7OztlQUNDOzs7OztnQkFFUCxVQUNDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLElBQUk7TUFDRjs7OztjQUVKO1FBcEJFOzs7O1lBb0JGO0lBRVQsQ0FBQztHQUNFOzs7O1dBRUY7Ozs7OztDQUNFOzs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkZhcVNlY3Rpb24udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IENoZXZyb25Eb3duLCBDaGV2cm9uVXAsIEhlbHBDaXJjbGUgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5leHBvcnQgY29uc3QgRmFxU2VjdGlvbjogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIGNvbnN0IFtvcGVuSWR4LCBzZXRPcGVuSWR4XSA9IHVzZVN0YXRlPG51bWJlciB8IG51bGw+KDApO1xuXG4gIGNvbnN0IGZhcXMgPSBbXG4gICAge1xuICAgICAgcXVlc3Rpb246ICdDYW4gYW55IGF1dG9tYXRlZCBBSSBkZXRlY3Rpb24gZW5naW5lIGJlIDEwMCUgYWNjdXJhdGU/JyxcbiAgICAgIGFuc3dlcjpcbiAgICAgICAgJ05vLiBBbnlvbmUgY2xhaW1pbmcgMTAwJSBjZXJ0YWludHkgaW4gc3ludGhldGljIG1lZGlhIGRldGVjdGlvbiBpcyBtaXNyZXByZXNlbnRpbmcgdGhlIHRlY2hub2xvZ3kuIEdlbmVyYXRpdmUgbW9kZWxzIGV2b2x2ZSByYXBpZGx5LCBhbmQgYmVuaWduIHBvc3QtcHJvY2Vzc2luZyAoc3VjaCBhcyByZXNpemluZywgY29tcHJlc3Npb24sIG9yIGNvbnRyYXN0IHR1bmluZykgY2FuIG1pbWljIG9yIG9ic2N1cmUgc3ludGhldGljIG1hcmtlcnMuIFZFUklUQVMgQUkgaW50ZW50aW9uYWxseSBwcm92aWRlcyB0cmFuc3BhcmVudCBjb25maWRlbmNlIGludGVydmFscywgdW5jZXJ0YWludHkgbWFyZ2lucywgYW5kIGV4cGxhaW5hYmxlIHNpZ25hbCB2ZWN0b3JzIHJhdGhlciB0aGFuIG9wYXF1ZSBiaW5hcnkgdmVyZGljdHMuJyxcbiAgICB9LFxuICAgIHtcbiAgICAgIHF1ZXN0aW9uOiAnV2h5IGFyZSB2ZXJkaWN0cyBjYXRlZ29yaXplZCBzdHJpY3RseSBpbnRvIFwiTGlrZWx5IEFJLWdlbmVyYXRlZFwiLCBcIkxpa2VseSBhdXRoZW50aWNcIiwgYW5kIFwiSW5jb25jbHVzaXZlXCI/JyxcbiAgICAgIGFuc3dlcjpcbiAgICAgICAgJ0JlY2F1c2UgcmVzcG9uc2libGUgZGlnaXRhbCBmb3JlbnNpY3MgcmVxdWlyZXMgYWNrbm93bGVkZ2luZyBlbXBpcmljYWwgbGltaXRhdGlvbnMuIFwiTGlrZWx5IEFJLWdlbmVyYXRlZFwiIHNpZ25pZmllcyB0aGF0IG11bHRpcGxlIGluZGVwZW5kZW50IHZlY3RvcnMgKHN1Y2ggYXMgY29ybmVhbCByZWZsZWN0aW9uIGRpc3NvbmFuY2UgYW5kIGZyZXF1ZW5jeSBkZWNvbnZvbHV0aW9uIHNwaWtlcykgY29ycm9ib3JhdGUgc3ludGhldGljIG9yaWdpbi4gXCJMaWtlbHkgYXV0aGVudGljXCIgbWVhbnMgdGhlIG1lZGlhIGNvbmZvcm1zIHRvIHBoeXNpY2FsIHNlbnNvciBvcHRpY3MgYW5kIGludGFjdCBoYXJkd2FyZSB0ZWxlbWV0cnkuIFwiSW5jb25jbHVzaXZlXCIgaXMgcmVuZGVyZWQgd2hlbiBsb3NzeSBjb21wcmVzc2lvbiBvciBpbnN1ZmZpY2llbnQgc2lnbmFsIHByZXZlbnRzIHJlbGlhYmxlIGRldGVybWluYXRpb24uJyxcbiAgICB9LFxuICAgIHtcbiAgICAgIHF1ZXN0aW9uOiAnSG93IGRvZXMgdmlkZW8gYW5hbHlzaXMgZGlmZmVyIGZyb20gc3RhdGljIGltYWdlIGFuYWx5c2lzPycsXG4gICAgICBhbnN3ZXI6XG4gICAgICAgICdWaWRlbyBpbnNwZWN0aW9uIGludHJvZHVjZXMgYSB0ZW1wb3JhbCBkaW1lbnNpb24uIEluIGFkZGl0aW9uIHRvIHBlci1mcmFtZSBzcGF0aWFsIGRlY29uc3RydWN0aW9uLCBWRVJJVEFTIGFuYWx5emVzIGludGVyLWZyYW1lIG9wdGljYWwgZmxvdyBjb25zaXN0ZW5jeSwgbWljcm8tbW90aW9uIGppdHRlciwgZmFjZSB3YXJwIHZhcmlhbmNlLCBhbmQgYmlvbWV0cmljIGNhZGVuY2UgKHN1Y2ggYXMgbmF0dXJhbCBleWUgYmxpbmsgZHVyYXRpb25zKS4gR2VuZXJhdGl2ZSB2aWRlbyBtb2RlbHMgZnJlcXVlbnRseSBzdHJ1Z2dsZSB3aXRoIDNEIHBoeXNpY2FsIHBlcnNpc3RlbmNlIGFjcm9zcyB0ZW1wb3JhbCBsYXRlbnQgc3BhY2Uga2V5ZnJhbWVzLicsXG4gICAgfSxcbiAgICB7XG4gICAgICBxdWVzdGlvbjogJ0RvZXMgc29jaWFsIG1lZGlhIGNvbXByZXNzaW9uIChlLmcuIFdoYXRzQXBwLCBJbnN0YWdyYW0sIFgpIGludGVyZmVyZSB3aXRoIGRldGVjdGlvbj8nLFxuICAgICAgYW5zd2VyOlxuICAgICAgICAnWWVzLiBBZ2dyZXNzaXZlIHNvY2lhbCBtZWRpYSB0cmFuc2NvZGluZyBzdHJpcHMgb3JpZ2luYWwgRVhJRiBtZXRhZGF0YSBhbmQgYXBwbGllcyBoZWF2eSBEaXNjcmV0ZSBDb3NpbmUgVHJhbnNmb3JtIChEQ1QpIHF1YW50aXphdGlvbiwgd2hpY2ggY2FuIGVyYXNlIHN1YnRsZSBDTU9TIHNlbnNvciBQUk5VIG5vaXNlLiBJbiBzdWNoIHNpdHVhdGlvbnMsIFZFUklUQVMgY29ycmVjdGx5IGZsYWdzIHRoZSByZXN1bHQgYXMgXCJJbmNvbmNsdXNpdmVcIiB0byBhdm9pZCBkZWNlcHRpdmUgZmFsc2UgcG9zaXRpdmVzLicsXG4gICAgfSxcbiAgICB7XG4gICAgICBxdWVzdGlvbjogJ1doYXQgcm9sZSBkb2VzIEMyUEEgKENvbnRlbnQgQ3JlZGVudGlhbHMpIHBsYXkgaW4gbWVkaWEgdmVyaWZpY2F0aW9uPycsXG4gICAgICBhbnN3ZXI6XG4gICAgICAgICdDMlBBIGlzIGFuIG9wZW4gdGVjaG5pY2FsIHN0YW5kYXJkIGRldmVsb3BlZCBieSB0aGUgQ29hbGl0aW9uIGZvciBDb250ZW50IFByb3ZlbmFuY2UgYW5kIEF1dGhlbnRpY2l0eS4gSXQgY3J5cHRvZ3JhcGhpY2FsbHkgYmluZHMgb3JpZ2luIG1ldGFkYXRhLCBlZGl0cywgYW5kIGF1dGhvciBjcmVkZW50aWFscyBkaXJlY3RseSBpbnRvIHRoZSBtZWRpYSBjb250YWluZXIgdXNpbmcgcHVibGljLWtleSBjcnlwdG9ncmFwaHkuIFdoZW4gcHJlc2VudCwgQzJQQSBwcm92aWRlcyB0YW1wZXItZXZpZGVudCBwcm92ZW5hbmNlIHRoYXQgc3VycGFzc2VzIGhldXJpc3RpYyBhbmFseXNpcy4nLFxuICAgIH0sXG4gICAge1xuICAgICAgcXVlc3Rpb246ICdJcyBteSBtZWRpYSBrZXB0IHByaXZhdGUgd2hlbiBhbmFseXplZD8nLFxuICAgICAgYW5zd2VyOlxuICAgICAgICAnWWVzLiBBbGwgZmlsZSBpbnNwZWN0aW9uLCBjYW52YXMgRXJyb3IgTGV2ZWwgQW5hbHlzaXMsIGFuZCBtZXRhZGF0YSBleHRyYWN0aW9ucyBvY2N1ciBlcGhlbWVyYWxseSBpbiB5b3VyIGFjdGl2ZSBicm93c2VyIHNlc3Npb24uIEZpbGVzIGFyZSBuZXZlciBzdG9yZWQgb24gcGVyc2lzdGVudCBkaXNrcywgbG9nZ2VkLCBvciB1c2VkIHRvIHRyYWluIGFueSBhcnRpZmljaWFsIGludGVsbGlnZW5jZSBtb2RlbHMuJyxcbiAgICB9LFxuICBdO1xuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gaWQ9XCJmYXFcIiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBzY3JvbGwtbXQtMjAgcHktMjQgcHgtNiBsZzpweC04IGJvcmRlci10IGJvcmRlci13aGl0ZS9bMC4wNl0gYmctWyMwMjA0MDldXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gbWF4LXctNHhsXCI+XG4gICAgICAgIFxuICAgICAgICB7LyogU2VjdGlvbiBIZWFkZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgbWF4LXctMnhsIG14LWF1dG8gbWItMTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIHRleHQtY3lhbi00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTJcIj5cbiAgICAgICAgICAgIFZlcmlmaWNhdGlvbiBBbnN3ZXJzXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtM3hsIHNtOnRleHQtNHhsIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHQgW3RleHQtd3JhcDpiYWxhbmNlXVwiPlxuICAgICAgICAgICAgRnJlcXVlbnRseSBBc2tlZCBRdWVzdGlvbnNcbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgdGV4dC1iYXNlIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICBVbmRlcnN0YW5kIHRoZSBjYXBhYmlsaXRpZXMsIGZvcmVuc2ljIG1ldGhvZG9sb2dpZXMsIGFuZCBzY2llbnRpZmljIGNvbnN0cmFpbnRzIG9mIHN5bnRoZXRpYyBtZWRpYSBkZXRlY3Rpb24uXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQWNjb3JkaW9uIExpc3QgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAge2ZhcXMubWFwKChmYXEsIGlkeCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgaXNPcGVuID0gb3BlbklkeCA9PT0gaWR4O1xuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGtleT17aWR4fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMDhdIGJnLXdoaXRlL1swLjAyXSBob3ZlcjpiZy13aGl0ZS9bMC4wNF0gdHJhbnNpdGlvbi1hbGwgb3ZlcmZsb3ctaGlkZGVuXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE9wZW5JZHgoaXNPcGVuID8gbnVsbCA6IGlkeCl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtNiB0ZXh0LWxlZnQgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtd2hpdGUgcHItNFwiPlxuICAgICAgICAgICAgICAgICAgICB7ZmFxLnF1ZXN0aW9ufVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtOCB3LTggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbGcgYmctd2hpdGUvWzAuMDRdIHRleHQtY3lhbi00MDAgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAge2lzT3BlbiA/IDxDaGV2cm9uVXAgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+IDogPENoZXZyb25Eb3duIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPn1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAge2lzT3BlbiAmJiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcGItNiBwdC0yIGJvcmRlci10IGJvcmRlci13aGl0ZS9bMC4wNF0gdGV4dC1zbSB0ZXh0LXNsYXRlLTMwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAge2ZhcS5hbnN3ZXJ9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59O1xuIl19