const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4c5f34d3";
import { Eye, Waves, Film, ShieldCheck, Lock } from "/node_modules/.vite/deps/lucide-react.js?v=4c5f34d3";
var _jsxFileName = "/app/applet/src/components/FeaturesSection.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4c5f34d3";
export const FeaturesSection = () => {
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "features",
		className: "relative scroll-mt-20 py-24 px-6 lg:px-8 border-t border-white/[0.06] bg-[#020409]",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "mx-auto max-w-7xl",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-3xl mb-16",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "text-xs font-mono text-cyan-400 uppercase tracking-wider mb-2",
						children: "Forensic Capabilities"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 11,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-3xl sm:text-4xl font-extrabold text-white tracking-tight [text-wrap:balance]",
						children: "Multi-Vector Forensic Signal Analysis"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 14,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-3 text-base text-slate-400 leading-relaxed",
						children: "Rather than relying on a single fallible classification metric, VERITAS AI examines media through multiple orthogonal forensic axes to illuminate structural irregularities."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 17,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 10,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "lg:col-span-2 rounded-2xl border border-white/[0.08] bg-gradient-to-br from-white/[0.04] to-transparent p-8 backdrop-blur-xl hover:border-cyan-500/30 transition-all group",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex h-12 w-12 items-center justify-center rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 mb-6 group-hover:scale-105 transition-transform",
								children: /* @__PURE__ */ _jsxDEV(Waves, { className: "h-6 w-6" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 28,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 27,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-xs font-mono text-cyan-400 uppercase tracking-wider",
										children: "01. Spatial & Frequency Domain Inspection"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 32,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("h3", {
										className: "text-xl sm:text-2xl font-bold text-white",
										children: "Error Level Analysis & Fourier Spectrum Deconvolution"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 35,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-sm text-slate-300 leading-relaxed max-w-xl",
										children: "Every camera lens and sensor introduces a unique, uniform physical noise signature. Generative diffusion networks leave periodic checkerboard residuals and quantization voids that become visible under Discrete Cosine Transform (DCT) deconstruction."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 38,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 31,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mt-6 pt-6 border-t border-white/[0.06] grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs font-mono",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 rounded-lg bg-black/40 border border-white/[0.04]",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-500 uppercase",
											children: "Quantization ELA"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 46,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-cyan-300 font-semibold mt-1",
											children: "Multi-Pass Resave"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 47,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 45,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 rounded-lg bg-black/40 border border-white/[0.04]",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-500 uppercase",
											children: "Nyquist Filter"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 50,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-violet-300 font-semibold mt-1",
											children: "8-Pixel Harmonics"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 51,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 49,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 rounded-lg bg-black/40 border border-white/[0.04] col-span-2 sm:col-span-1",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-500 uppercase",
											children: "PRNU Validation"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 54,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-slate-300 font-semibold mt-1",
											children: "Silicon Noise Delta"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 55,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 53,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 44,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "rounded-2xl border border-white/[0.08] bg-gradient-to-br from-white/[0.04] to-transparent p-8 backdrop-blur-xl hover:border-violet-500/30 transition-all group",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex h-12 w-12 items-center justify-center rounded-xl bg-violet-500/10 border border-violet-500/30 text-violet-400 mb-6 group-hover:scale-105 transition-transform",
							children: /* @__PURE__ */ _jsxDEV(Eye, { className: "h-6 w-6" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 63,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 62,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-xs font-mono text-violet-400 uppercase tracking-wider",
									children: "02. Specular Lighting"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 67,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-lg font-bold text-white",
									children: "Corneal Catchlight Geometry"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 70,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm text-slate-300 leading-relaxed",
									children: "Human eyes reflect identical 3D light sources. Diffusion models generate eyes independently, creating contradictory light angle vectors and impossible reflections."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 73,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "rounded-2xl border border-white/[0.08] bg-gradient-to-br from-white/[0.04] to-transparent p-8 backdrop-blur-xl hover:border-cyan-500/30 transition-all group",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex h-12 w-12 items-center justify-center rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 mb-6 group-hover:scale-105 transition-transform",
							children: /* @__PURE__ */ _jsxDEV(Film, { className: "h-6 w-6" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 82,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-xs font-mono text-cyan-400 uppercase tracking-wider",
									children: "03. Video Scrutiny"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 86,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-lg font-bold text-white",
									children: "Temporal Optical Flow & Jitter"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 89,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm text-slate-300 leading-relaxed",
									children: "Video deepfakes and AI video generators often suffer from micro-motion jitter, frame-to-frame skin texture morphing, and unnatural eyelid blink rates."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 92,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 85,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "rounded-2xl border border-white/[0.08] bg-gradient-to-br from-white/[0.04] to-transparent p-8 backdrop-blur-xl hover:border-cyan-500/30 transition-all group",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex h-12 w-12 items-center justify-center rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 mb-6 group-hover:scale-105 transition-transform",
							children: /* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "h-6 w-6" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 101,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 100,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-xs font-mono text-cyan-400 uppercase tracking-wider",
									children: "04. Provenance"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 105,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-lg font-bold text-white",
									children: "C2PA Content Credentials"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 108,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm text-slate-300 leading-relaxed",
									children: "Audits cryptographically signed digital manifests from hardware manufacturers (Leica, Sony, Nikon) and identifies software generation markers."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 111,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 104,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "rounded-2xl border border-white/[0.08] bg-gradient-to-br from-white/[0.04] to-transparent p-8 backdrop-blur-xl hover:border-violet-500/30 transition-all group",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex h-12 w-12 items-center justify-center rounded-xl bg-violet-500/10 border border-violet-500/30 text-violet-400 mb-6 group-hover:scale-105 transition-transform",
							children: /* @__PURE__ */ _jsxDEV(Lock, { className: "h-6 w-6" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-xs font-mono text-violet-400 uppercase tracking-wider",
									children: "05. Data Protection"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 124,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-lg font-bold text-white",
									children: "Ephemeral Processing"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 127,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm text-slate-300 leading-relaxed",
									children: "Your media is never stored, indexed, or used to train any model. Client-side canvas shaders execute directly in memory with zero residual telemetry."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 130,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 7,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 6,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsS0FBSyxPQUFPLE1BQU0sYUFBa0IsWUFBOEI7OztBQUUzRSxPQUFPLE1BQU0sd0JBQWtDO0NBQzdDLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLElBQUc7RUFBVyxXQUFVO1lBQy9CLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FHRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWdFO0tBRTFFOzs7OztLQUNMLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFvRjtLQUU5Rjs7Ozs7S0FDSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBZ0Q7S0FFMUQ7Ozs7O0lBQ0E7Ozs7O2FBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUdFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsT0FBRCxFQUFPLFdBQVUsVUFBVzs7Ozs7T0FDekI7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBMkQ7U0FFckU7Ozs7O1NBQ0wsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQTJDO1NBRXJEOzs7OztTQUNKLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFrRDtTQUU1RDs7Ozs7UUFDQTs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUF1QztVQUFxQjs7OztvQkFDM0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQW1DO1VBQXNCOzs7O2tCQUNyRTs7Ozs7O1NBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBdUM7VUFBbUI7Ozs7b0JBQ3pFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFxQztVQUFzQjs7OztrQkFDdkU7Ozs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQXVDO1VBQW9COzs7O29CQUMxRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBb0M7VUFBd0I7Ozs7a0JBQ3hFOzs7Ozs7UUFDRjs7Ozs7O01BQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsS0FBRCxFQUFLLFdBQVUsVUFBVzs7Ozs7TUFDdkI7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBNkQ7UUFFdkU7Ozs7O1FBQ0wsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQStCO1FBRXpDOzs7OztRQUNKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUF5QztRQUVuRDs7Ozs7T0FDQTs7Ozs7Y0FDRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7OztNQUN4Qjs7OztnQkFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUEyRDtRQUVyRTs7Ozs7UUFDTCx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBK0I7UUFFekM7Ozs7O1FBQ0osd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQXlDO1FBRW5EOzs7OztPQUNBOzs7OztjQUNGOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLGFBQUQsRUFBYSxXQUFVLFVBQVc7Ozs7O01BQy9COzs7O2dCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQTJEO1FBRXJFOzs7OztRQUNMLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUErQjtRQUV6Qzs7Ozs7UUFDSix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBeUM7UUFFbkQ7Ozs7O09BQ0E7Ozs7O2NBQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7Ozs7TUFDeEI7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBNkQ7UUFFdkU7Ozs7O1FBQ0wsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQStCO1FBRXpDOzs7OztRQUNKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUF5QztRQUVuRDs7Ozs7T0FDQTs7Ozs7Y0FDRjs7Ozs7O0lBRUY7Ozs7O1dBRUY7Ozs7OztDQUNFOzs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkZlYXR1cmVzU2VjdGlvbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEV5ZSwgV2F2ZXMsIEZpbG0sIFNoaWVsZENoZWNrLCBDcHUsIExvY2ssIFNwYXJrbGVzLCBMYXllcnMgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5leHBvcnQgY29uc3QgRmVhdHVyZXNTZWN0aW9uOiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBpZD1cImZlYXR1cmVzXCIgY2xhc3NOYW1lPVwicmVsYXRpdmUgc2Nyb2xsLW10LTIwIHB5LTI0IHB4LTYgbGc6cHgtOCBib3JkZXItdCBib3JkZXItd2hpdGUvWzAuMDZdIGJnLVsjMDIwNDA5XVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LTd4bFwiPlxuICAgICAgICBcbiAgICAgICAgey8qIFNlY3Rpb24gSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTN4bCBtYi0xNlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdGV4dC1jeWFuLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMlwiPlxuICAgICAgICAgICAgRm9yZW5zaWMgQ2FwYWJpbGl0aWVzXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtM3hsIHNtOnRleHQtNHhsIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHQgW3RleHQtd3JhcDpiYWxhbmNlXVwiPlxuICAgICAgICAgICAgTXVsdGktVmVjdG9yIEZvcmVuc2ljIFNpZ25hbCBBbmFseXNpc1xuICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LWJhc2UgdGV4dC1zbGF0ZS00MDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICBSYXRoZXIgdGhhbiByZWx5aW5nIG9uIGEgc2luZ2xlIGZhbGxpYmxlIGNsYXNzaWZpY2F0aW9uIG1ldHJpYywgVkVSSVRBUyBBSSBleGFtaW5lcyBtZWRpYSB0aHJvdWdoIG11bHRpcGxlIG9ydGhvZ29uYWwgZm9yZW5zaWMgYXhlcyB0byBpbGx1bWluYXRlIHN0cnVjdHVyYWwgaXJyZWd1bGFyaXRpZXMuXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQXN5bW1ldHJpYyBCZW50by1HcmlkICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTZcIj5cbiAgICAgICAgICBcbiAgICAgICAgICB7LyogQ2FyZCAxOiBMYXJnZSBDb2wtU3Bhbi0yIEhpZ2hsaWdodCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTIgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci13aGl0ZS9bMC4wOF0gYmctZ3JhZGllbnQtdG8tYnIgZnJvbS13aGl0ZS9bMC4wNF0gdG8tdHJhbnNwYXJlbnQgcC04IGJhY2tkcm9wLWJsdXIteGwgaG92ZXI6Ym9yZGVyLWN5YW4tNTAwLzMwIHRyYW5zaXRpb24tYWxsIGdyb3VwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC0xMiB3LTEyIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXhsIGJnLWN5YW4tNTAwLzEwIGJvcmRlciBib3JkZXItY3lhbi01MDAvMzAgdGV4dC1jeWFuLTQwMCBtYi02IGdyb3VwLWhvdmVyOnNjYWxlLTEwNSB0cmFuc2l0aW9uLXRyYW5zZm9ybVwiPlxuICAgICAgICAgICAgICA8V2F2ZXMgY2xhc3NOYW1lPVwiaC02IHctNlwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LWN5YW4tNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgICAgIDAxLiBTcGF0aWFsICYgRnJlcXVlbmN5IERvbWFpbiBJbnNwZWN0aW9uXG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBzbTp0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgIEVycm9yIExldmVsIEFuYWx5c2lzICYgRm91cmllciBTcGVjdHJ1bSBEZWNvbnZvbHV0aW9uXG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1zbGF0ZS0zMDAgbGVhZGluZy1yZWxheGVkIG1heC13LXhsXCI+XG4gICAgICAgICAgICAgICAgRXZlcnkgY2FtZXJhIGxlbnMgYW5kIHNlbnNvciBpbnRyb2R1Y2VzIGEgdW5pcXVlLCB1bmlmb3JtIHBoeXNpY2FsIG5vaXNlIHNpZ25hdHVyZS4gR2VuZXJhdGl2ZSBkaWZmdXNpb24gbmV0d29ya3MgbGVhdmUgcGVyaW9kaWMgY2hlY2tlcmJvYXJkIHJlc2lkdWFscyBhbmQgcXVhbnRpemF0aW9uIHZvaWRzIHRoYXQgYmVjb21lIHZpc2libGUgdW5kZXIgRGlzY3JldGUgQ29zaW5lIFRyYW5zZm9ybSAoRENUKSBkZWNvbnN0cnVjdGlvbi5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBWaXN1YWwgdGVsZW1ldHJ5IG1vY2t1cCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBwdC02IGJvcmRlci10IGJvcmRlci13aGl0ZS9bMC4wNl0gZ3JpZCBncmlkLWNvbHMtMiBzbTpncmlkLWNvbHMtMyBnYXAtNCB0ZXh0LXhzIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLWxnIGJnLWJsYWNrLzQwIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMDRdXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2VcIj5RdWFudGl6YXRpb24gRUxBPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWN5YW4tMzAwIGZvbnQtc2VtaWJvbGQgbXQtMVwiPk11bHRpLVBhc3MgUmVzYXZlPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLWxnIGJnLWJsYWNrLzQwIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMDRdXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2VcIj5OeXF1aXN0IEZpbHRlcjwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtMzAwIGZvbnQtc2VtaWJvbGQgbXQtMVwiPjgtUGl4ZWwgSGFybW9uaWNzPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLWxnIGJnLWJsYWNrLzQwIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMDRdIGNvbC1zcGFuLTIgc206Y29sLXNwYW4tMVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlXCI+UFJOVSBWYWxpZGF0aW9uPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTMwMCBmb250LXNlbWlib2xkIG10LTFcIj5TaWxpY29uIE5vaXNlIERlbHRhPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQ2FyZCAyOiBDb3JuZWFsIFNwZWN1bGFyIEdlb21ldHJ5ICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci13aGl0ZS9bMC4wOF0gYmctZ3JhZGllbnQtdG8tYnIgZnJvbS13aGl0ZS9bMC4wNF0gdG8tdHJhbnNwYXJlbnQgcC04IGJhY2tkcm9wLWJsdXIteGwgaG92ZXI6Ym9yZGVyLXZpb2xldC01MDAvMzAgdHJhbnNpdGlvbi1hbGwgZ3JvdXBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTEyIHctMTIgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgYmctdmlvbGV0LTUwMC8xMCBib3JkZXIgYm9yZGVyLXZpb2xldC01MDAvMzAgdGV4dC12aW9sZXQtNDAwIG1iLTYgZ3JvdXAtaG92ZXI6c2NhbGUtMTA1IHRyYW5zaXRpb24tdHJhbnNmb3JtXCI+XG4gICAgICAgICAgICAgIDxFeWUgY2xhc3NOYW1lPVwiaC02IHctNlwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LXZpb2xldC00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgICAgMDIuIFNwZWN1bGFyIExpZ2h0aW5nXG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgIENvcm5lYWwgQ2F0Y2hsaWdodCBHZW9tZXRyeVxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtMzAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgIEh1bWFuIGV5ZXMgcmVmbGVjdCBpZGVudGljYWwgM0QgbGlnaHQgc291cmNlcy4gRGlmZnVzaW9uIG1vZGVscyBnZW5lcmF0ZSBleWVzIGluZGVwZW5kZW50bHksIGNyZWF0aW5nIGNvbnRyYWRpY3RvcnkgbGlnaHQgYW5nbGUgdmVjdG9ycyBhbmQgaW1wb3NzaWJsZSByZWZsZWN0aW9ucy5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQ2FyZCAzOiBUZW1wb3JhbCBNb3Rpb24gRHJpZnQgZm9yIFZpZGVvcyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMDhdIGJnLWdyYWRpZW50LXRvLWJyIGZyb20td2hpdGUvWzAuMDRdIHRvLXRyYW5zcGFyZW50IHAtOCBiYWNrZHJvcC1ibHVyLXhsIGhvdmVyOmJvcmRlci1jeWFuLTUwMC8zMCB0cmFuc2l0aW9uLWFsbCBncm91cFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtMTIgdy0xMiBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBiZy1jeWFuLTUwMC8xMCBib3JkZXIgYm9yZGVyLWN5YW4tNTAwLzMwIHRleHQtY3lhbi00MDAgbWItNiBncm91cC1ob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIj5cbiAgICAgICAgICAgICAgPEZpbG0gY2xhc3NOYW1lPVwiaC02IHctNlwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LWN5YW4tNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgICAgIDAzLiBWaWRlbyBTY3J1dGlueVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICBUZW1wb3JhbCBPcHRpY2FsIEZsb3cgJiBKaXR0ZXJcbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTMwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICBWaWRlbyBkZWVwZmFrZXMgYW5kIEFJIHZpZGVvIGdlbmVyYXRvcnMgb2Z0ZW4gc3VmZmVyIGZyb20gbWljcm8tbW90aW9uIGppdHRlciwgZnJhbWUtdG8tZnJhbWUgc2tpbiB0ZXh0dXJlIG1vcnBoaW5nLCBhbmQgdW5uYXR1cmFsIGV5ZWxpZCBibGluayByYXRlcy5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQ2FyZCA0OiBDMlBBICYgUHJvdmVuYW5jZSBNZXRhZGF0YSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMDhdIGJnLWdyYWRpZW50LXRvLWJyIGZyb20td2hpdGUvWzAuMDRdIHRvLXRyYW5zcGFyZW50IHAtOCBiYWNrZHJvcC1ibHVyLXhsIGhvdmVyOmJvcmRlci1jeWFuLTUwMC8zMCB0cmFuc2l0aW9uLWFsbCBncm91cFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtMTIgdy0xMiBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBiZy1jeWFuLTUwMC8xMCBib3JkZXIgYm9yZGVyLWN5YW4tNTAwLzMwIHRleHQtY3lhbi00MDAgbWItNiBncm91cC1ob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIj5cbiAgICAgICAgICAgICAgPFNoaWVsZENoZWNrIGNsYXNzTmFtZT1cImgtNiB3LTZcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdGV4dC1jeWFuLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgICAgICAwNC4gUHJvdmVuYW5jZVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICBDMlBBIENvbnRlbnQgQ3JlZGVudGlhbHNcbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTMwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICBBdWRpdHMgY3J5cHRvZ3JhcGhpY2FsbHkgc2lnbmVkIGRpZ2l0YWwgbWFuaWZlc3RzIGZyb20gaGFyZHdhcmUgbWFudWZhY3R1cmVycyAoTGVpY2EsIFNvbnksIE5pa29uKSBhbmQgaWRlbnRpZmllcyBzb2Z0d2FyZSBnZW5lcmF0aW9uIG1hcmtlcnMuXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIENhcmQgNTogWmVybyBSZXRlbnRpb24gUHJpdmFjeSBHdWFyYW50ZWUgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXdoaXRlL1swLjA4XSBiZy1ncmFkaWVudC10by1iciBmcm9tLXdoaXRlL1swLjA0XSB0by10cmFuc3BhcmVudCBwLTggYmFja2Ryb3AtYmx1ci14bCBob3Zlcjpib3JkZXItdmlvbGV0LTUwMC8zMCB0cmFuc2l0aW9uLWFsbCBncm91cFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtMTIgdy0xMiBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBiZy12aW9sZXQtNTAwLzEwIGJvcmRlciBib3JkZXItdmlvbGV0LTUwMC8zMCB0ZXh0LXZpb2xldC00MDAgbWItNiBncm91cC1ob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIj5cbiAgICAgICAgICAgICAgPExvY2sgY2xhc3NOYW1lPVwiaC02IHctNlwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LXZpb2xldC00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgICAgMDUuIERhdGEgUHJvdGVjdGlvblxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICBFcGhlbWVyYWwgUHJvY2Vzc2luZ1xuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtMzAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgIFlvdXIgbWVkaWEgaXMgbmV2ZXIgc3RvcmVkLCBpbmRleGVkLCBvciB1c2VkIHRvIHRyYWluIGFueSBtb2RlbC4gQ2xpZW50LXNpZGUgY2FudmFzIHNoYWRlcnMgZXhlY3V0ZSBkaXJlY3RseSBpbiBtZW1vcnkgd2l0aCB6ZXJvIHJlc2lkdWFsIHRlbGVtZXRyeS5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn07XG4iXX0=