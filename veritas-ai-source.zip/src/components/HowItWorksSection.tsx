const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4c5f34d3";
var _jsxFileName = "/app/applet/src/components/HowItWorksSection.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4c5f34d3";
export const HowItWorksSection = () => {
	const steps = [
		{
			number: "01",
			title: "Container Ingestion & Hardware Telemetry",
			description: "The media file is parsed in-memory. Container atoms, JPEG APP1 segments, and PNG text chunks are scanned for hardware sensor profiles (ISO, aperture, shutter), lens calibration parameters, and C2PA cryptographic signatures.",
			metrics: "APP1 Exif · C2PA Manifests · PNG tEXt"
		},
		{
			number: "02",
			title: "Spatial Frequency & Error Level Analysis",
			description: "The image is re-encoded at controlled quantization levels to measure Discrete Cosine Transform (DCT) block dissipation. Generative models leave distinct deconvolution residue along synthetic boundaries.",
			metrics: "DCT Disparity · Nyquist Radial Power · ELA Heatmap"
		},
		{
			number: "03",
			title: "Optical Physics & Ocular Specular Audit",
			description: "Light direction vectors, ambient shadow falloffs, and corneal reflections are calculated against 3D ray-tracing physics. Bilateral discordance in eye catchlights exposes non-physical 2D latent synthesis.",
			metrics: "Corneal Normal Vectors · Shadow Consistency"
		},
		{
			number: "04",
			title: "Transparent Probabilistic Classification",
			description: "Signals are aggregated with explicit uncertainty bounds. Rather than a deceptive 100% verdict, the engine returns Likely AI-generated, Likely authentic, or Inconclusive with verifiable forensic rationale.",
			metrics: "Uncertainty Interval · Explainable Vectors"
		}
	];
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "how-it-works",
		className: "relative scroll-mt-20 py-24 px-6 lg:px-8 border-t border-white/[0.06] bg-[#030612]",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "mx-auto max-w-7xl",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "text-center max-w-3xl mx-auto mb-16",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "text-xs font-mono text-cyan-400 uppercase tracking-wider mb-2",
						children: "The Inspection Pipeline"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 42,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-3xl sm:text-4xl font-extrabold text-white tracking-tight [text-wrap:balance]",
						children: "How VERITAS AI Uncovers Synthetic Media"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 45,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "mt-3 text-base text-slate-400",
						children: "A methodical four-stage pipeline that interrogates visual artifacts, container integrity, and physical sensor physics."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 relative",
				children: steps.map((step, idx) => /* @__PURE__ */ _jsxDEV("div", {
					className: "relative rounded-2xl border border-white/[0.08] bg-white/[0.02] hover:bg-white/[0.04] p-6 backdrop-blur-xl flex flex-col justify-between transition-all group",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between mb-4",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-2xl font-black font-mono text-cyan-400 group-hover:text-cyan-300 transition-colors",
								children: step.number
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 63,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", { className: "h-2 w-2 rounded-full bg-cyan-400/50 group-hover:bg-cyan-300" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 66,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 62,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-base font-bold text-white mb-3 leading-snug",
							children: step.title
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 69,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400 leading-relaxed",
							children: step.description
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 73,
							columnNumber: 17
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "mt-6 pt-4 border-t border-white/[0.06]",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "text-[10px] font-mono text-cyan-400/90 truncate",
							children: step.metrics
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 15
					}, this)]
				}, step.number, true, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 13
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 38,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 37,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXOzs7QUFHbEIsT0FBTyxNQUFNLDBCQUFvQztDQUMvQyxNQUFNLFFBQVE7RUFDWjtHQUNFLFFBQVE7R0FDUixPQUFPO0dBQ1AsYUFDRTtHQUNGLFNBQVM7RUFDWDtFQUNBO0dBQ0UsUUFBUTtHQUNSLE9BQU87R0FDUCxhQUNFO0dBQ0YsU0FBUztFQUNYO0VBQ0E7R0FDRSxRQUFRO0dBQ1IsT0FBTztHQUNQLGFBQ0U7R0FDRixTQUFTO0VBQ1g7RUFDQTtHQUNFLFFBQVE7R0FDUixPQUFPO0dBQ1AsYUFDRTtHQUNGLFNBQVM7RUFDWDtDQUNGO0NBRUEsT0FDRSx3QkFBQyxXQUFEO0VBQVMsSUFBRztFQUFlLFdBQVU7WUFDbkMsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUdFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZ0U7S0FFMUU7Ozs7O0tBQ0wsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQW9GO0tBRTlGOzs7OztLQUNKLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFnQztLQUUxQzs7Ozs7SUFDQTs7Ozs7YUFHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNaLE1BQU0sS0FBSyxNQUFNLFFBQ2hCLHdCQUFDLE9BQUQ7S0FFRSxXQUFVO2VBRlosQ0FJRSx3QkFBQyxPQUFEO01BRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixLQUFLO09BQ0Y7Ozs7aUJBQ04sd0JBQUMsT0FBRCxFQUFLLFdBQVUsOERBQStEOzs7O2VBQzNFOzs7Ozs7TUFFTCx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFDWCxLQUFLO01BQ0o7Ozs7O01BRUosd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQ1YsS0FBSztNQUNMOzs7OztLQUNBOzs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1osS0FBSztNQUNIOzs7OztLQUNGOzs7O2FBQ0Y7T0ExQkUsS0FBSzs7OztXQTBCUCxDQUNOO0dBQ0U7Ozs7V0FFRjs7Ozs7O0NBQ0U7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSG93SXRXb3Jrc1NlY3Rpb24udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBVcGxvYWQsIENwdSwgU2VhcmNoLCBDaGVja0NpcmNsZSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmV4cG9ydCBjb25zdCBIb3dJdFdvcmtzU2VjdGlvbjogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIGNvbnN0IHN0ZXBzID0gW1xuICAgIHtcbiAgICAgIG51bWJlcjogJzAxJyxcbiAgICAgIHRpdGxlOiAnQ29udGFpbmVyIEluZ2VzdGlvbiAmIEhhcmR3YXJlIFRlbGVtZXRyeScsXG4gICAgICBkZXNjcmlwdGlvbjpcbiAgICAgICAgJ1RoZSBtZWRpYSBmaWxlIGlzIHBhcnNlZCBpbi1tZW1vcnkuIENvbnRhaW5lciBhdG9tcywgSlBFRyBBUFAxIHNlZ21lbnRzLCBhbmQgUE5HIHRleHQgY2h1bmtzIGFyZSBzY2FubmVkIGZvciBoYXJkd2FyZSBzZW5zb3IgcHJvZmlsZXMgKElTTywgYXBlcnR1cmUsIHNodXR0ZXIpLCBsZW5zIGNhbGlicmF0aW9uIHBhcmFtZXRlcnMsIGFuZCBDMlBBIGNyeXB0b2dyYXBoaWMgc2lnbmF0dXJlcy4nLFxuICAgICAgbWV0cmljczogJ0FQUDEgRXhpZiDCtyBDMlBBIE1hbmlmZXN0cyDCtyBQTkcgdEVYdCcsXG4gICAgfSxcbiAgICB7XG4gICAgICBudW1iZXI6ICcwMicsXG4gICAgICB0aXRsZTogJ1NwYXRpYWwgRnJlcXVlbmN5ICYgRXJyb3IgTGV2ZWwgQW5hbHlzaXMnLFxuICAgICAgZGVzY3JpcHRpb246XG4gICAgICAgICdUaGUgaW1hZ2UgaXMgcmUtZW5jb2RlZCBhdCBjb250cm9sbGVkIHF1YW50aXphdGlvbiBsZXZlbHMgdG8gbWVhc3VyZSBEaXNjcmV0ZSBDb3NpbmUgVHJhbnNmb3JtIChEQ1QpIGJsb2NrIGRpc3NpcGF0aW9uLiBHZW5lcmF0aXZlIG1vZGVscyBsZWF2ZSBkaXN0aW5jdCBkZWNvbnZvbHV0aW9uIHJlc2lkdWUgYWxvbmcgc3ludGhldGljIGJvdW5kYXJpZXMuJyxcbiAgICAgIG1ldHJpY3M6ICdEQ1QgRGlzcGFyaXR5IMK3IE55cXVpc3QgUmFkaWFsIFBvd2VyIMK3IEVMQSBIZWF0bWFwJyxcbiAgICB9LFxuICAgIHtcbiAgICAgIG51bWJlcjogJzAzJyxcbiAgICAgIHRpdGxlOiAnT3B0aWNhbCBQaHlzaWNzICYgT2N1bGFyIFNwZWN1bGFyIEF1ZGl0JyxcbiAgICAgIGRlc2NyaXB0aW9uOlxuICAgICAgICAnTGlnaHQgZGlyZWN0aW9uIHZlY3RvcnMsIGFtYmllbnQgc2hhZG93IGZhbGxvZmZzLCBhbmQgY29ybmVhbCByZWZsZWN0aW9ucyBhcmUgY2FsY3VsYXRlZCBhZ2FpbnN0IDNEIHJheS10cmFjaW5nIHBoeXNpY3MuIEJpbGF0ZXJhbCBkaXNjb3JkYW5jZSBpbiBleWUgY2F0Y2hsaWdodHMgZXhwb3NlcyBub24tcGh5c2ljYWwgMkQgbGF0ZW50IHN5bnRoZXNpcy4nLFxuICAgICAgbWV0cmljczogJ0Nvcm5lYWwgTm9ybWFsIFZlY3RvcnMgwrcgU2hhZG93IENvbnNpc3RlbmN5JyxcbiAgICB9LFxuICAgIHtcbiAgICAgIG51bWJlcjogJzA0JyxcbiAgICAgIHRpdGxlOiAnVHJhbnNwYXJlbnQgUHJvYmFiaWxpc3RpYyBDbGFzc2lmaWNhdGlvbicsXG4gICAgICBkZXNjcmlwdGlvbjpcbiAgICAgICAgJ1NpZ25hbHMgYXJlIGFnZ3JlZ2F0ZWQgd2l0aCBleHBsaWNpdCB1bmNlcnRhaW50eSBib3VuZHMuIFJhdGhlciB0aGFuIGEgZGVjZXB0aXZlIDEwMCUgdmVyZGljdCwgdGhlIGVuZ2luZSByZXR1cm5zIExpa2VseSBBSS1nZW5lcmF0ZWQsIExpa2VseSBhdXRoZW50aWMsIG9yIEluY29uY2x1c2l2ZSB3aXRoIHZlcmlmaWFibGUgZm9yZW5zaWMgcmF0aW9uYWxlLicsXG4gICAgICBtZXRyaWNzOiAnVW5jZXJ0YWludHkgSW50ZXJ2YWwgwrcgRXhwbGFpbmFibGUgVmVjdG9ycycsXG4gICAgfSxcbiAgXTtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGlkPVwiaG93LWl0LXdvcmtzXCIgY2xhc3NOYW1lPVwicmVsYXRpdmUgc2Nyb2xsLW10LTIwIHB5LTI0IHB4LTYgbGc6cHgtOCBib3JkZXItdCBib3JkZXItd2hpdGUvWzAuMDZdIGJnLVsjMDMwNjEyXVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LTd4bFwiPlxuICAgICAgICBcbiAgICAgICAgey8qIFNlY3Rpb24gSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIG1heC13LTN4bCBteC1hdXRvIG1iLTE2XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LWN5YW4tNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0yXCI+XG4gICAgICAgICAgICBUaGUgSW5zcGVjdGlvbiBQaXBlbGluZVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBzbTp0ZXh0LTR4bCBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIHRyYWNraW5nLXRpZ2h0IFt0ZXh0LXdyYXA6YmFsYW5jZV1cIj5cbiAgICAgICAgICAgIEhvdyBWRVJJVEFTIEFJIFVuY292ZXJzIFN5bnRoZXRpYyBNZWRpYVxuICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LWJhc2UgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgIEEgbWV0aG9kaWNhbCBmb3VyLXN0YWdlIHBpcGVsaW5lIHRoYXQgaW50ZXJyb2dhdGVzIHZpc3VhbCBhcnRpZmFjdHMsIGNvbnRhaW5lciBpbnRlZ3JpdHksIGFuZCBwaHlzaWNhbCBzZW5zb3IgcGh5c2ljcy5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBTdGVwcyBHcmlkICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTYgcmVsYXRpdmVcIj5cbiAgICAgICAgICB7c3RlcHMubWFwKChzdGVwLCBpZHgpID0+IChcbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAga2V5PXtzdGVwLm51bWJlcn1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci13aGl0ZS9bMC4wOF0gYmctd2hpdGUvWzAuMDJdIGhvdmVyOmJnLXdoaXRlL1swLjA0XSBwLTYgYmFja2Ryb3AtYmx1ci14bCBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiB0cmFuc2l0aW9uLWFsbCBncm91cFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgey8qIFN0ZXAgbnVtYmVyIGJhZGdlICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYmxhY2sgZm9udC1tb25vIHRleHQtY3lhbi00MDAgZ3JvdXAtaG92ZXI6dGV4dC1jeWFuLTMwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICB7c3RlcC5udW1iZXJ9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMiB3LTIgcm91bmRlZC1mdWxsIGJnLWN5YW4tNDAwLzUwIGdyb3VwLWhvdmVyOmJnLWN5YW4tMzAwXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtd2hpdGUgbWItMyBsZWFkaW5nLXNudWdcIj5cbiAgICAgICAgICAgICAgICAgIHtzdGVwLnRpdGxlfVxuICAgICAgICAgICAgICAgIDwvaDM+XG5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAge3N0ZXAuZGVzY3JpcHRpb259XG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgcHQtNCBib3JkZXItdCBib3JkZXItd2hpdGUvWzAuMDZdXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LW1vbm8gdGV4dC1jeWFuLTQwMC85MCB0cnVuY2F0ZVwiPlxuICAgICAgICAgICAgICAgICAge3N0ZXAubWV0cmljc31cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn07XG4iXX0=