const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4c5f34d3";
import { ShieldAlert, ArrowUp } from "/node_modules/.vite/deps/lucide-react.js?v=4c5f34d3";
var _jsxFileName = "/app/applet/src/components/Footer.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4c5f34d3";
export const Footer = ({ onAnalyzeClick, onOpenMobileGuide }) => {
	const scrollToTop = () => {
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	};
	return /* @__PURE__ */ _jsxDEV("footer", {
		className: "border-t border-white/[0.08] bg-[#020307] text-slate-400 text-xs",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "mx-auto max-w-7xl px-6 lg:px-8 py-14",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 md:grid-cols-4 gap-10 mb-12",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "md:col-span-2 space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2.5",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-500/20 to-violet-500/20 border border-cyan-500/30 text-cyan-400",
									children: /* @__PURE__ */ _jsxDEV(ShieldAlert, { className: "h-4 w-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 25,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 24,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-lg font-bold tracking-tight text-white",
									children: ["VERITAS", /* @__PURE__ */ _jsxDEV("span", {
										className: "text-cyan-400 ml-1 font-mono text-xs tracking-wider",
										children: "AI"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 28,
										columnNumber: 24
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 27,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 23,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-300 max-w-sm leading-relaxed",
								children: "\"See Beyond the Synthetic.\" Next-generation forensic signal inspection empowering researchers, newsrooms, and digital investigators to analyze images and video for generative manipulation."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 32,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3 pt-2",
								children: /* @__PURE__ */ _jsxDEV("button", {
									onClick: onOpenMobileGuide,
									className: "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] text-slate-300 hover:text-white transition-colors",
									children: /* @__PURE__ */ _jsxDEV("span", { children: "Mobile Access & Deploy" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 41,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 37,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 36,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 22,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "text-xs font-mono font-semibold text-white uppercase tracking-wider",
							children: "Navigation"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("ul", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("a", {
									href: "#analyze",
									className: "hover:text-cyan-400 transition-colors",
									children: "Detection Studio"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 53,
									columnNumber: 17
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 52,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("a", {
									href: "#how-it-works",
									className: "hover:text-cyan-400 transition-colors",
									children: "How It Works"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 58,
									columnNumber: 17
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 57,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("a", {
									href: "#features",
									className: "hover:text-cyan-400 transition-colors",
									children: "Forensic Features"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 63,
									columnNumber: 17
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 62,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("a", {
									href: "#technology",
									className: "hover:text-cyan-400 transition-colors",
									children: "Technology & Math"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 68,
									columnNumber: 17
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 67,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("a", {
									href: "#pricing",
									className: "hover:text-cyan-400 transition-colors",
									children: "Plans & Pricing"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 73,
									columnNumber: 17
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 72,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("a", {
									href: "#faq",
									className: "hover:text-cyan-400 transition-colors",
									children: "Frequently Asked Questions"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 78,
									columnNumber: 17
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 77,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "text-xs font-mono font-semibold text-white uppercase tracking-wider",
							children: "Verification Standards"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 87,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("ul", {
							className: "space-y-2 text-slate-400",
							children: [
								/* @__PURE__ */ _jsxDEV("li", { children: "C2PA Content Credentials 2.1" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 91,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("li", { children: "Error Level Analysis (ELA)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 92,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("li", { children: "Discrete Cosine Transform (DCT)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 93,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("li", { children: "Photo-Response Non-Uniformity (PRNU)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 94,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("li", { children: "Zero Data Retention Protocol" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 95,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "pt-8 border-t border-white/[0.06] space-y-4",
				children: [/* @__PURE__ */ _jsxDEV("p", {
					className: "text-[11px] text-slate-400 leading-relaxed max-w-4xl",
					children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Forensic & Legal Disclaimer:" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 13
					}, this), " VERITAS AI provides probabilistic multi-vector forensic indicators for research, educational, and verification demonstration purposes. Due to advancing diffusion architectures and lossy media compression, automated indicators do not constitute legally certified guarantees. Critical determinations should be cross-verified with cryptographic chain-of-custody credentials (C2PA) and domain-certified forensic analysis."]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 103,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-400",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [
						"© ",
						new Date().getFullYear(),
						" VERITAS AI Systems. All rights reserved."
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: scrollToTop,
						className: "flex items-center gap-1.5 hover:text-cyan-400 transition-colors cursor-pointer",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: "Back to top" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 116,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV(ArrowUp, { className: "h-3.5 w-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 117,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 112,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 107,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 16,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsYUFBcUMsZUFBZTs7O0FBTzdELE9BQU8sTUFBTSxVQUFpQyxFQUFFLGdCQUFnQix3QkFBd0I7Q0FDdEYsTUFBTSxvQkFBb0I7RUFDeEIsT0FBTyxTQUFTO0dBQUUsS0FBSztHQUFHLFVBQVU7RUFBUyxDQUFDO0NBQ2hEO0NBRUEsT0FDRSx3QkFBQyxVQUFEO0VBQVEsV0FBVTtZQUNoQix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBR0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUdFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxhQUFELEVBQWEsV0FBVSxVQUFXOzs7OztRQUMvQjs7OztrQkFDTCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEIsQ0FBOEQsV0FDckQsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXNEO1NBQVE7Ozs7aUJBQ2pGOzs7OztnQkFDSDs7Ozs7O09BRUwsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWtEO09BRTVEOzs7OztPQUVILHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLFVBQUQ7U0FDRSxTQUFTO1NBQ1QsV0FBVTttQkFFVix3QkFBQyxRQUFELFlBQU0seUJBQTRCOzs7OztRQUM1Qjs7Ozs7T0FDTDs7Ozs7TUFDRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBc0U7TUFFaEY7Ozs7Z0JBQ0wsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQ7UUFDRSx3QkFBQyxNQUFELFlBQ0Usd0JBQUMsS0FBRDtTQUFHLE1BQUs7U0FBVyxXQUFVO21CQUF3QztRQUVsRTs7OztpQkFDRDs7Ozs7UUFDSix3QkFBQyxNQUFELFlBQ0Usd0JBQUMsS0FBRDtTQUFHLE1BQUs7U0FBZ0IsV0FBVTttQkFBd0M7UUFFdkU7Ozs7aUJBQ0Q7Ozs7O1FBQ0osd0JBQUMsTUFBRCxZQUNFLHdCQUFDLEtBQUQ7U0FBRyxNQUFLO1NBQVksV0FBVTttQkFBd0M7UUFFbkU7Ozs7aUJBQ0Q7Ozs7O1FBQ0osd0JBQUMsTUFBRCxZQUNFLHdCQUFDLEtBQUQ7U0FBRyxNQUFLO1NBQWMsV0FBVTttQkFBd0M7UUFFckU7Ozs7aUJBQ0Q7Ozs7O1FBQ0osd0JBQUMsTUFBRCxZQUNFLHdCQUFDLEtBQUQ7U0FBRyxNQUFLO1NBQVcsV0FBVTttQkFBd0M7UUFFbEU7Ozs7aUJBQ0Q7Ozs7O1FBQ0osd0JBQUMsTUFBRCxZQUNFLHdCQUFDLEtBQUQ7U0FBRyxNQUFLO1NBQU8sV0FBVTttQkFBd0M7UUFFOUQ7Ozs7aUJBQ0Q7Ozs7O09BQ0Y7Ozs7O2NBQ0Q7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQXNFO01BRWhGOzs7O2dCQUNMLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkO1FBQ0Usd0JBQUMsTUFBRCxZQUFJLCtCQUFnQzs7Ozs7UUFDcEMsd0JBQUMsTUFBRCxZQUFJLDZCQUE4Qjs7Ozs7UUFDbEMsd0JBQUMsTUFBRCxZQUFJLGtDQUFtQzs7Ozs7UUFDdkMsd0JBQUMsTUFBRCxZQUFJLHVDQUF3Qzs7Ozs7UUFDNUMsd0JBQUMsTUFBRCxZQUFJLCtCQUFnQzs7Ozs7T0FDbEM7Ozs7O2NBQ0Q7Ozs7OztJQUVGOzs7OzthQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFiLENBQ0Usd0JBQUMsVUFBRCxZQUFRLCtCQUFvQzs7OztlQUFDLG9hQUM1Qzs7Ozs7Y0FFSCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLO01BQ0ssSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO01BQUU7S0FDOUI7Ozs7ZUFFTCx3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFdBQVU7Z0JBRlosQ0FJRSx3QkFBQyxRQUFELFlBQU0sY0FBaUI7Ozs7Z0JBQ3ZCLHdCQUFDLFNBQUQsRUFBUyxXQUFVLGNBQWU7Ozs7Y0FDNUI7Ozs7O2FBQ0w7Ozs7O1lBQ0Y7Ozs7O1dBRUY7Ozs7OztDQUNDOzs7OztBQUVaIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkZvb3Rlci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFNoaWVsZEFsZXJ0LCBHaXRodWIsIFR3aXR0ZXIsIEdsb2JlLCBBcnJvd1VwIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuaW50ZXJmYWNlIEZvb3RlclByb3BzIHtcbiAgb25BbmFseXplQ2xpY2s6ICgpID0+IHZvaWQ7XG4gIG9uT3Blbk1vYmlsZUd1aWRlOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgRm9vdGVyOiBSZWFjdC5GQzxGb290ZXJQcm9wcz4gPSAoeyBvbkFuYWx5emVDbGljaywgb25PcGVuTW9iaWxlR3VpZGUgfSkgPT4ge1xuICBjb25zdCBzY3JvbGxUb1RvcCA9ICgpID0+IHtcbiAgICB3aW5kb3cuc2Nyb2xsVG8oeyB0b3A6IDAsIGJlaGF2aW9yOiAnc21vb3RoJyB9KTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxmb290ZXIgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLXdoaXRlL1swLjA4XSBiZy1bIzAyMDMwN10gdGV4dC1zbGF0ZS00MDAgdGV4dC14c1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LTd4bCBweC02IGxnOnB4LTggcHktMTRcIj5cbiAgICAgICAgXG4gICAgICAgIHsvKiBUb3AgRm9vdGVyIEdyaWQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtNCBnYXAtMTAgbWItMTJcIj5cbiAgICAgICAgICBcbiAgICAgICAgICB7LyogQnJhbmQgJiBNaXNzaW9uICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6Y29sLXNwYW4tMiBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC04IHctOCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1sZyBiZy1ncmFkaWVudC10by1iciBmcm9tLWN5YW4tNTAwLzIwIHRvLXZpb2xldC01MDAvMjAgYm9yZGVyIGJvcmRlci1jeWFuLTUwMC8zMCB0ZXh0LWN5YW4tNDAwXCI+XG4gICAgICAgICAgICAgICAgPFNoaWVsZEFsZXJ0IGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgIFZFUklUQVM8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWN5YW4tNDAwIG1sLTEgZm9udC1tb25vIHRleHQteHMgdHJhY2tpbmctd2lkZXJcIj5BSTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS0zMDAgbWF4LXctc20gbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgIFwiU2VlIEJleW9uZCB0aGUgU3ludGhldGljLlwiIE5leHQtZ2VuZXJhdGlvbiBmb3JlbnNpYyBzaWduYWwgaW5zcGVjdGlvbiBlbXBvd2VyaW5nIHJlc2VhcmNoZXJzLCBuZXdzcm9vbXMsIGFuZCBkaWdpdGFsIGludmVzdGlnYXRvcnMgdG8gYW5hbHl6ZSBpbWFnZXMgYW5kIHZpZGVvIGZvciBnZW5lcmF0aXZlIG1hbmlwdWxhdGlvbi5cbiAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBwdC0yXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbk9wZW5Nb2JpbGVHdWlkZX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSByb3VuZGVkLWxnIGJnLXdoaXRlL1swLjA0XSBob3ZlcjpiZy13aGl0ZS9bMC4wOF0gYm9yZGVyIGJvcmRlci13aGl0ZS9bMC4wOF0gdGV4dC1zbGF0ZS0zMDAgaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8c3Bhbj5Nb2JpbGUgQWNjZXNzICYgRGVwbG95PC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFF1aWNrIE5hdmlnYXRpb24gTGlua3MgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgICBOYXZpZ2F0aW9uXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgIDxhIGhyZWY9XCIjYW5hbHl6ZVwiIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtY3lhbi00MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgIERldGVjdGlvbiBTdHVkaW9cbiAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgICA8YSBocmVmPVwiI2hvdy1pdC13b3Jrc1wiIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtY3lhbi00MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgIEhvdyBJdCBXb3Jrc1xuICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgIDxhIGhyZWY9XCIjZmVhdHVyZXNcIiBjbGFzc05hbWU9XCJob3Zlcjp0ZXh0LWN5YW4tNDAwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICBGb3JlbnNpYyBGZWF0dXJlc1xuICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgIDxhIGhyZWY9XCIjdGVjaG5vbG9neVwiIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtY3lhbi00MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgIFRlY2hub2xvZ3kgJiBNYXRoXG4gICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNwcmljaW5nXCIgY2xhc3NOYW1lPVwiaG92ZXI6dGV4dC1jeWFuLTQwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgUGxhbnMgJiBQcmljaW5nXG4gICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNmYXFcIiBjbGFzc05hbWU9XCJob3Zlcjp0ZXh0LWN5YW4tNDAwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICBGcmVxdWVudGx5IEFza2VkIFF1ZXN0aW9uc1xuICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogRm9yZW5zaWMgU3RhbmRhcmRzICYgSW50ZWdyaXR5ICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgICAgVmVyaWZpY2F0aW9uIFN0YW5kYXJkc1xuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwic3BhY2UteS0yIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgIDxsaT5DMlBBIENvbnRlbnQgQ3JlZGVudGlhbHMgMi4xPC9saT5cbiAgICAgICAgICAgICAgPGxpPkVycm9yIExldmVsIEFuYWx5c2lzIChFTEEpPC9saT5cbiAgICAgICAgICAgICAgPGxpPkRpc2NyZXRlIENvc2luZSBUcmFuc2Zvcm0gKERDVCk8L2xpPlxuICAgICAgICAgICAgICA8bGk+UGhvdG8tUmVzcG9uc2UgTm9uLVVuaWZvcm1pdHkgKFBSTlUpPC9saT5cbiAgICAgICAgICAgICAgPGxpPlplcm8gRGF0YSBSZXRlbnRpb24gUHJvdG9jb2w8L2xpPlxuICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogRGlzY2xhaW1lciBTdHJpcCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC04IGJvcmRlci10IGJvcmRlci13aGl0ZS9bMC4wNl0gc3BhY2UteS00XCI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgbGVhZGluZy1yZWxheGVkIG1heC13LTR4bFwiPlxuICAgICAgICAgICAgPHN0cm9uZz5Gb3JlbnNpYyAmIExlZ2FsIERpc2NsYWltZXI6PC9zdHJvbmc+IFZFUklUQVMgQUkgcHJvdmlkZXMgcHJvYmFiaWxpc3RpYyBtdWx0aS12ZWN0b3IgZm9yZW5zaWMgaW5kaWNhdG9ycyBmb3IgcmVzZWFyY2gsIGVkdWNhdGlvbmFsLCBhbmQgdmVyaWZpY2F0aW9uIGRlbW9uc3RyYXRpb24gcHVycG9zZXMuIER1ZSB0byBhZHZhbmNpbmcgZGlmZnVzaW9uIGFyY2hpdGVjdHVyZXMgYW5kIGxvc3N5IG1lZGlhIGNvbXByZXNzaW9uLCBhdXRvbWF0ZWQgaW5kaWNhdG9ycyBkbyBub3QgY29uc3RpdHV0ZSBsZWdhbGx5IGNlcnRpZmllZCBndWFyYW50ZWVzLiBDcml0aWNhbCBkZXRlcm1pbmF0aW9ucyBzaG91bGQgYmUgY3Jvc3MtdmVyaWZpZWQgd2l0aCBjcnlwdG9ncmFwaGljIGNoYWluLW9mLWN1c3RvZHkgY3JlZGVudGlhbHMgKEMyUEEpIGFuZCBkb21haW4tY2VydGlmaWVkIGZvcmVuc2ljIGFuYWx5c2lzLlxuICAgICAgICAgIDwvcD5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IHRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAmY29weTsge25ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKX0gVkVSSVRBUyBBSSBTeXN0ZW1zLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17c2Nyb2xsVG9Ub3B9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgaG92ZXI6dGV4dC1jeWFuLTQwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxzcGFuPkJhY2sgdG8gdG9wPC9zcGFuPlxuICAgICAgICAgICAgICA8QXJyb3dVcCBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuICAgIDwvZm9vdGVyPlxuICApO1xufTtcbiJdfQ==