const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4c5f34d3";
import { ArrowRight, Cpu, SlidersHorizontal, CheckCircle2 } from "/node_modules/.vite/deps/lucide-react.js?v=4c5f34d3";
var _jsxFileName = "/app/applet/src/components/HeroSection.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4c5f34d3";
export const HeroSection = ({ onAnalyzeClick, onExploreTechClick }) => {
	const [sliderPos, setSliderPos] = useState(52);
	const [activeCase, setActiveCase] = useState("portrait");
	const [viewMode, setViewMode] = useState("laser");
	const [simulatedConfidence, setSimulatedConfidence] = useState(89.4);
	const [scanTelemetry, setScanTelemetry] = useState({
		azimuthL: "42.1°",
		azimuthR: "18.6°",
		fourierSpike: "0.42 cyc/px",
		prnuCorrelation: "r = 0.08"
	});
	// Natural subtle telemetry fluctuation
	useEffect(() => {
		const interval = setInterval(() => {
			setSimulatedConfidence((prev) => {
				const delta = (Math.random() - .5) * .8;
				return Math.min(94.2, Math.max(86.1, Number((prev + delta).toFixed(1))));
			});
		}, 2400);
		return () => clearInterval(interval);
	}, []);
	const handleCaseChange = (newCase) => {
		setActiveCase(newCase);
		if (newCase === "portrait") {
			setSimulatedConfidence(89.4);
			setScanTelemetry({
				azimuthL: "42.1°",
				azimuthR: "18.6°",
				fourierSpike: "0.42 cyc/px",
				prnuCorrelation: "r = 0.08"
			});
		} else if (newCase === "deepfake") {
			setSimulatedConfidence(86.8);
			setScanTelemetry({
				azimuthL: "31.4°",
				azimuthR: "30.9°",
				fourierSpike: "0.51 cyc/px",
				prnuCorrelation: "r = 0.12"
			});
		} else {
			setSimulatedConfidence(92.5);
			setScanTelemetry({
				azimuthL: "28.0°",
				azimuthR: "28.2°",
				fourierSpike: "Uniform",
				prnuCorrelation: "r = 0.89"
			});
		}
	};
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "relative overflow-hidden pt-12 pb-24 md:pt-20 md:pb-32 cyber-grid-pattern",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { className: "absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[850px] h-[450px] bg-cyan-500/10 rounded-full blur-[160px] pointer-events-none -z-10" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { className: "absolute top-1/3 right-4 w-[550px] h-[450px] bg-violet-600/15 rounded-full blur-[150px] pointer-events-none -z-10" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { className: "absolute -bottom-10 left-10 w-[400px] h-[300px] bg-cyan-600/10 rounded-full blur-[130px] pointer-events-none -z-10" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 71,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mx-auto max-w-7xl px-6 lg:px-8",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-10 items-center",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "lg:col-span-7 space-y-7",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-cyan-950/70 border border-cyan-500/30 text-cyan-300 text-xs font-mono tracking-wider uppercase backdrop-blur-md shadow-[0_0_20px_rgba(6,182,212,0.15)]",
								children: [
									/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-cyan-400 animate-ping" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 81,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-semibold",
										children: "See Beyond the Synthetic"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 82,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										"aria-hidden": "true",
										className: "text-cyan-700",
										children: "·"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 83,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400 font-mono",
										children: "v2.4 Forensic Suite"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 84,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 80,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("h1", {
								className: "text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.08] [text-wrap:balance]",
								children: [
									"Can You Trust ",
									/* @__PURE__ */ _jsxDEV("br", { className: "hidden sm:inline" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 89,
										columnNumber: 29
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "bg-gradient-to-r from-white via-cyan-200 to-cyan-400 bg-clip-text text-transparent",
										children: "What You See?"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 90,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 88,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed [text-wrap:balance]",
								children: "Discover the signals behind synthetic media with intelligent image and video analysis. Interrogate Discrete Cosine Transform (DCT) deconvolution artifacts, bi-ocular catchlight discordance, and latent temporal drift."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 96,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-wrap items-center gap-x-5 gap-y-2.5 text-xs text-slate-400 pt-1 font-mono",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "flex items-center gap-2 text-slate-200",
										children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "h-4 w-4 text-cyan-400 shrink-0" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 104,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Error Level Analysis (ELA)" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 105,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 103,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										"aria-hidden": "true",
										className: "text-slate-700",
										children: "/"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 107,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "flex items-center gap-2 text-slate-200",
										children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "h-4 w-4 text-cyan-400 shrink-0" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 109,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Temporal Flow Video Scrutiny" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 110,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 108,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										"aria-hidden": "true",
										className: "text-slate-700",
										children: "/"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 112,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "flex items-center gap-2 text-slate-200",
										children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "h-4 w-4 text-cyan-400 shrink-0" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 114,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "C2PA Manifest Audit" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 115,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 113,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 102,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-3",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									onClick: onAnalyzeClick,
									className: "group inline-flex items-center justify-center gap-3 px-7 py-4 text-sm font-bold text-black bg-gradient-to-r from-cyan-400 via-cyan-300 to-teal-300 hover:from-cyan-300 hover:to-white rounded-xl shadow-[0_0_35px_rgba(6,182,212,0.4)] transition-all cursor-pointer active:scale-98",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Analyze Media" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 125,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "h-4 w-4 transition-transform group-hover:translate-x-1" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 126,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 121,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: onExploreTechClick,
									className: "inline-flex items-center justify-center gap-2.5 px-6 py-4 text-sm font-semibold text-slate-200 hover:text-white bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.12] hover:border-cyan-500/40 rounded-xl transition-all cursor-pointer backdrop-blur-md",
									children: [/* @__PURE__ */ _jsxDEV(Cpu, { className: "h-4 w-4 text-cyan-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 133,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Explore Technology" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 134,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 129,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-slate-500 max-w-lg leading-normal",
								children: "Built on transparent scientific heuristics without exaggerated claims. Evaluates observable physical sensor physics and compression footprints."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 77,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "lg:col-span-5 relative",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "relative mx-auto max-w-[480px] rounded-3xl bg-gradient-to-b from-white/[0.12] via-white/[0.04] to-transparent p-2 backdrop-blur-2xl border border-cyan-500/35 shadow-[0_0_60px_rgba(6,182,212,0.2)]",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between px-3 py-2 border-b border-white/[0.08] text-[11px] font-mono text-slate-400 mb-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-cyan-400 animate-pulse" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 151,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-white font-semibold",
											children: "LIVE FORENSIC VIEWER"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 152,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 150,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-1 p-0.5 bg-black/40 rounded-lg border border-white/[0.06]",
										children: [
											/* @__PURE__ */ _jsxDEV("button", {
												onClick: () => handleCaseChange("portrait"),
												className: `px-2 py-0.5 rounded text-[10px] transition-colors ${activeCase === "portrait" ? "bg-cyan-500/20 text-cyan-300 font-bold" : "text-slate-400 hover:text-white"}`,
												children: "AI Face"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 157,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												onClick: () => handleCaseChange("deepfake"),
												className: `px-2 py-0.5 rounded text-[10px] transition-colors ${activeCase === "deepfake" ? "bg-cyan-500/20 text-cyan-300 font-bold" : "text-slate-400 hover:text-white"}`,
												children: "Video Clip"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 165,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												onClick: () => handleCaseChange("authentic"),
												className: `px-2 py-0.5 rounded text-[10px] transition-colors ${activeCase === "authentic" ? "bg-cyan-500/20 text-cyan-300 font-bold" : "text-slate-400 hover:text-white"}`,
												children: "35mm Film"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 173,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 156,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 149,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "relative aspect-[4/5] w-full overflow-hidden rounded-2xl bg-[#02050f] border border-white/[0.06]",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute inset-0 overflow-hidden",
											style: { clipPath: `polygon(0 0, ${sliderPos}% 0, ${sliderPos}% 100%, 0 100%)` },
											children: /* @__PURE__ */ _jsxDEV("div", {
												className: "relative w-full h-full bg-gradient-to-b from-slate-900 via-[#070d1e] to-black flex items-center justify-center",
												children: [/* @__PURE__ */ _jsxDEV("svg", {
													viewBox: "0 0 400 500",
													className: "w-full h-full object-cover",
													children: [
														/* @__PURE__ */ _jsxDEV("defs", { children: [/* @__PURE__ */ _jsxDEV("linearGradient", {
															id: "skinGrad",
															x1: "0%",
															y1: "0%",
															x2: "100%",
															y2: "100%",
															children: [
																/* @__PURE__ */ _jsxDEV("stop", {
																	offset: "0%",
																	stopColor: "#1e293b"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 198,
																	columnNumber: 27
																}, this),
																/* @__PURE__ */ _jsxDEV("stop", {
																	offset: "50%",
																	stopColor: "#0f172a"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 199,
																	columnNumber: 27
																}, this),
																/* @__PURE__ */ _jsxDEV("stop", {
																	offset: "100%",
																	stopColor: "#020617"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 200,
																	columnNumber: 27
																}, this)
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 197,
															columnNumber: 25
														}, this), /* @__PURE__ */ _jsxDEV("radialGradient", {
															id: "eyeSpecularLeft",
															cx: "45%",
															cy: "40%",
															r: "25%",
															children: [
																/* @__PURE__ */ _jsxDEV("stop", {
																	offset: "0%",
																	stopColor: "#ffffff"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 203,
																	columnNumber: 27
																}, this),
																/* @__PURE__ */ _jsxDEV("stop", {
																	offset: "70%",
																	stopColor: "#38bdf8"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 204,
																	columnNumber: 27
																}, this),
																/* @__PURE__ */ _jsxDEV("stop", {
																	offset: "100%",
																	stopColor: "#0369a1"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 205,
																	columnNumber: 27
																}, this)
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 202,
															columnNumber: 25
														}, this)] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 196,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("rect", {
															width: "400",
															height: "500",
															fill: "url(#skinGrad)"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 209,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("path", {
															d: "M120 500 C120 420, 150 370, 200 370 C250 370, 280 420, 280 500 Z",
															fill: "#0b1120"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 212,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("path", {
															d: "M200 110 C145 110, 125 165, 125 235 C125 315, 155 375, 200 380 C245 375, 275 315, 275 235 C275 165, 255 110, 200 110 Z",
															fill: "#1e293b"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 213,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("ellipse", {
															cx: "165",
															cy: "220",
															rx: "18",
															ry: "11",
															fill: "#0f172a",
															stroke: "#334155",
															strokeWidth: "1.5"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 216,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("circle", {
															cx: "165",
															cy: "220",
															r: "7",
															fill: "#0284c7"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 217,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("circle", {
															cx: "163",
															cy: "218",
															r: "3",
															fill: "#ffffff"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 218,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("ellipse", {
															cx: "235",
															cy: "220",
															rx: "18",
															ry: "11",
															fill: "#0f172a",
															stroke: "#334155",
															strokeWidth: "1.5"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 220,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("circle", {
															cx: "235",
															cy: "220",
															r: "7",
															fill: "#0284c7"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 221,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("circle", {
															cx: "237",
															cy: "218",
															r: "3",
															fill: "#ffffff"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 222,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("path", {
															d: "M195 245 L200 270 L190 275",
															stroke: "#475569",
															strokeWidth: "2",
															fill: "none",
															strokeLinecap: "round"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 225,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("path", {
															d: "M180 310 Q200 325 220 310",
															stroke: "#64748b",
															strokeWidth: "2.5",
															fill: "none",
															strokeLinecap: "round"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 226,
															columnNumber: 23
														}, this),
														Array.from({ length: 25 }).map((_, i) => /* @__PURE__ */ _jsxDEV("line", {
															x1: "0",
															y1: i * 20,
															x2: "400",
															y2: i * 20,
															stroke: "#38bdf8",
															strokeWidth: "0.5",
															strokeDasharray: "3 6",
															opacity: "0.12"
														}, i, false, {
															fileName: _jsxFileName,
															lineNumber: 230,
															columnNumber: 25
														}, this))
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 195,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "absolute top-4 left-4 text-[10px] font-mono tracking-widest uppercase px-2.5 py-1 rounded-lg bg-black/70 border border-white/15 text-cyan-300 backdrop-blur-md",
													children: "Sensory Baseline"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 235,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 192,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 188,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute inset-0 overflow-hidden",
											style: { clipPath: `polygon(${sliderPos}% 0, 100% 0, 100% 100%, ${sliderPos}% 100%)` },
											children: /* @__PURE__ */ _jsxDEV("div", {
												className: "relative w-full h-full bg-[#030616] flex items-center justify-center",
												children: [/* @__PURE__ */ _jsxDEV("svg", {
													viewBox: "0 0 400 500",
													className: "w-full h-full object-cover",
													children: [
														/* @__PURE__ */ _jsxDEV("defs", { children: /* @__PURE__ */ _jsxDEV("radialGradient", {
															id: "synthGlow",
															cx: "60%",
															cy: "45%",
															r: "35%",
															children: [
																/* @__PURE__ */ _jsxDEV("stop", {
																	offset: "0%",
																	stopColor: "#a855f7",
																	stopOpacity: "0.8"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 251,
																	columnNumber: 27
																}, this),
																/* @__PURE__ */ _jsxDEV("stop", {
																	offset: "60%",
																	stopColor: "#06b6d4",
																	stopOpacity: "0.3"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 252,
																	columnNumber: 27
																}, this),
																/* @__PURE__ */ _jsxDEV("stop", {
																	offset: "100%",
																	stopColor: "transparent",
																	stopOpacity: "0"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 253,
																	columnNumber: 27
																}, this)
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 250,
															columnNumber: 25
														}, this) }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 249,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("rect", {
															width: "400",
															height: "500",
															fill: "#030614"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 257,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("rect", {
															width: "400",
															height: "500",
															fill: "url(#synthGlow)"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 258,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("g", {
															stroke: "#06b6d4",
															strokeWidth: "0.75",
															opacity: "0.35",
															children: [Array.from({ length: 17 }).map((_, i) => /* @__PURE__ */ _jsxDEV("line", {
																x1: i * 25,
																y1: "0",
																x2: i * 25,
																y2: "500"
															}, `gv-${i}`, false, {
																fileName: _jsxFileName,
																lineNumber: 263,
																columnNumber: 27
															}, this)), Array.from({ length: 22 }).map((_, i) => /* @__PURE__ */ _jsxDEV("line", {
																x1: "0",
																y1: i * 24,
																x2: "400",
																y2: i * 24
															}, `gh-${i}`, false, {
																fileName: _jsxFileName,
																lineNumber: 266,
																columnNumber: 27
															}, this))]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 261,
															columnNumber: 23
														}, this),
														/* @__PURE__ */ _jsxDEV("g", {
															stroke: "#c084fc",
															strokeWidth: "1.4",
															fill: "none",
															opacity: "0.9",
															children: [
																/* @__PURE__ */ _jsxDEV("polygon", { points: "200,110 240,150 275,235 250,300 200,380" }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 272,
																	columnNumber: 25
																}, this),
																/* @__PURE__ */ _jsxDEV("line", {
																	x1: "200",
																	y1: "110",
																	x2: "275",
																	y2: "235",
																	strokeDasharray: "4 4"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 273,
																	columnNumber: 25
																}, this),
																/* @__PURE__ */ _jsxDEV("line", {
																	x1: "240",
																	y1: "150",
																	x2: "200",
																	y2: "380",
																	strokeDasharray: "4 4"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 274,
																	columnNumber: 25
																}, this),
																/* @__PURE__ */ _jsxDEV("circle", {
																	cx: "235",
																	cy: "220",
																	r: "16",
																	stroke: "#f43f5e",
																	strokeWidth: "2",
																	strokeDasharray: "3 3"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 277,
																	columnNumber: 25
																}, this),
																/* @__PURE__ */ _jsxDEV("line", {
																	x1: "235",
																	y1: "220",
																	x2: "270",
																	y2: "190",
																	stroke: "#f43f5e",
																	strokeWidth: "1.5"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 278,
																	columnNumber: 25
																}, this),
																/* @__PURE__ */ _jsxDEV("circle", {
																	cx: "270",
																	cy: "190",
																	r: "2.5",
																	fill: "#f43f5e"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 279,
																	columnNumber: 25
																}, this),
																/* @__PURE__ */ _jsxDEV("text", {
																	x: "278",
																	y: "193",
																	fill: "#f43f5e",
																	fontSize: "9",
																	fontFamily: "monospace",
																	fontWeight: "bold",
																	children: "Δ 23.5° CORNEAL ERROR"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 280,
																	columnNumber: 25
																}, this),
																/* @__PURE__ */ _jsxDEV("circle", {
																	cx: "250",
																	cy: "290",
																	r: "10",
																	stroke: "#06b6d4",
																	strokeWidth: "1.5"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 285,
																	columnNumber: 25
																}, this),
																/* @__PURE__ */ _jsxDEV("text", {
																	x: "265",
																	y: "295",
																	fill: "#22d3ee",
																	fontSize: "8",
																	fontFamily: "monospace",
																	children: "DCT DISPARITY"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 286,
																	columnNumber: 25
																}, this)
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 271,
															columnNumber: 23
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 248,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "absolute top-4 right-4 text-[10px] font-mono tracking-widest uppercase px-2.5 py-1 rounded-lg bg-violet-950/80 border border-violet-500/40 text-violet-300 backdrop-blur-md",
													children: "Synthetic Mesh"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 293,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 246,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 242,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute top-0 bottom-0 w-0.5 bg-gradient-to-b from-cyan-300 via-white to-violet-400 shadow-[0_0_15px_#22d3ee,0_0_35px_#8b5cf6] pointer-events-none z-20",
											style: { left: `${sliderPos}%` },
											children: [/* @__PURE__ */ _jsxDEV("div", { className: "absolute -top-1.5 -left-1.5 w-4 h-4 rounded-full bg-cyan-300 blur-[2px] shadow-[0_0_10px_#22d3ee]" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 304,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", { className: "absolute -bottom-1.5 -left-1.5 w-4 h-4 rounded-full bg-cyan-300 blur-[2px] shadow-[0_0_10px_#22d3ee]" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 305,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 300,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { className: "absolute left-0 right-0 h-2.5 bg-gradient-to-r from-transparent via-cyan-400/90 to-transparent blur-[1px] animate-laser-sweep pointer-events-none z-10" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 309,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute bottom-4 left-4 right-4 z-30 p-3.5 rounded-2xl bg-[#040816]/90 border border-cyan-500/35 backdrop-blur-xl holographic-glow",
											children: /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center justify-between gap-3",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center gap-2.5",
													children: [/* @__PURE__ */ _jsxDEV("div", { className: `w-3 h-3 rounded-full ${activeCase === "authentic" ? "bg-emerald-400" : "bg-rose-500"} animate-pulse` }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 315,
														columnNumber: 23
													}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "text-[11px] font-mono font-bold tracking-wider text-white uppercase flex items-center gap-1.5",
														children: /* @__PURE__ */ _jsxDEV("span", { children: activeCase === "authentic" ? "Likely Authentic" : "Likely AI-generated" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 318,
															columnNumber: 27
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 317,
														columnNumber: 25
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "text-[10px] text-slate-400 font-mono",
														children: [
															"Confidence: ",
															simulatedConfidence,
															"% (±5.5%)"
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 320,
														columnNumber: 25
													}, this)] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 316,
														columnNumber: 23
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 314,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "text-right",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "text-[10px] font-mono font-semibold text-cyan-400 uppercase",
														children: activeCase === "authentic" ? "PRNU Sensor Match" : "Corneal Glare Discord"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 327,
														columnNumber: 23
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "text-[9px] text-slate-400 font-mono",
														children: "Vector 04 / Audited"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 330,
														columnNumber: 23
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 326,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 313,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 312,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											type: "range",
											min: "8",
											max: "92",
											value: sliderPos,
											onChange: (e) => setSliderPos(Number(e.target.value)),
											className: "absolute inset-x-0 bottom-18 h-10 opacity-0 cursor-ew-resize z-40",
											"aria-label": "Drag split comparison slider"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 338,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 185,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "mt-3 grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px] font-mono px-2 text-slate-400",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-1.5 rounded bg-white/[0.02] border border-white/[0.04]",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-500 block",
												children: "Eye Azimuth:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 352,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-cyan-300 font-semibold",
												children: [
													scanTelemetry.azimuthL,
													" / ",
													scanTelemetry.azimuthR
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 353,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 351,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-1.5 rounded bg-white/[0.02] border border-white/[0.04]",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-500 block",
												children: "Nyquist Spike:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 356,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-violet-300 font-semibold",
												children: scanTelemetry.fourierSpike
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 357,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 355,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-1.5 rounded bg-white/[0.02] border border-white/[0.04]",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-500 block",
												children: "PRNU Match:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 360,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-200 font-semibold",
												children: scanTelemetry.prnuCorrelation
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 361,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 359,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-1.5 rounded bg-white/[0.02] border border-white/[0.04] flex items-center justify-between",
											children: /* @__PURE__ */ _jsxDEV("span", {
												className: "text-cyan-400 flex items-center gap-1",
												children: [/* @__PURE__ */ _jsxDEV(SlidersHorizontal, { className: "h-3 w-3" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 365,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Drag Slider" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 366,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 364,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 363,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 350,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 146,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 145,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 74,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 73,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 67,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsWUFBWSxLQUFvQixtQkFBbUIsb0JBQXNEOzs7QUFTbEgsT0FBTyxNQUFNLGVBQTJDLEVBQ3RELGdCQUNBLHlCQUNJO0NBQ0osTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQWlCLEVBQUU7Q0FDckQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQW1CLFVBQVU7Q0FDakUsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUE0QyxPQUFPO0NBQ25GLE1BQU0sQ0FBQyxxQkFBcUIsMEJBQTBCLFNBQWlCLElBQUk7Q0FDM0UsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVM7RUFDakQsVUFBVTtFQUNWLFVBQVU7RUFDVixjQUFjO0VBQ2QsaUJBQWlCO0NBQ25CLENBQUM7O0NBR0QsZ0JBQWdCO0VBQ2QsTUFBTSxXQUFXLGtCQUFrQjtHQUNqQyx3QkFBd0IsU0FBUztJQUMvQixNQUFNLFNBQVMsS0FBSyxPQUFPLElBQUksTUFBTztJQUN0QyxPQUFPLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSSxNQUFNLFFBQVEsT0FBTyxNQUFLLENBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0dBQ3pFLENBQUM7RUFDSCxHQUFHLElBQUk7RUFDUCxhQUFhLGNBQWMsUUFBUTtDQUNyQyxHQUFHLENBQUMsQ0FBQztDQUVMLE1BQU0sb0JBQW9CLFlBQXNCO0VBQzlDLGNBQWMsT0FBTztFQUNyQixJQUFJLFlBQVksWUFBWTtHQUMxQix1QkFBdUIsSUFBSTtHQUMzQixpQkFBaUI7SUFDZixVQUFVO0lBQ1YsVUFBVTtJQUNWLGNBQWM7SUFDZCxpQkFBaUI7R0FDbkIsQ0FBQztFQUNILE9BQU8sSUFBSSxZQUFZLFlBQVk7R0FDakMsdUJBQXVCLElBQUk7R0FDM0IsaUJBQWlCO0lBQ2YsVUFBVTtJQUNWLFVBQVU7SUFDVixjQUFjO0lBQ2QsaUJBQWlCO0dBQ25CLENBQUM7RUFDSCxPQUFPO0dBQ0wsdUJBQXVCLElBQUk7R0FDM0IsaUJBQWlCO0lBQ2YsVUFBVTtJQUNWLFVBQVU7SUFDVixjQUFjO0lBQ2QsaUJBQWlCO0dBQ25CLENBQUM7RUFDSDtDQUNGO0NBRUEsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUVFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLHFKQUFzSjs7Ozs7R0FDckssd0JBQUMsT0FBRCxFQUFLLFdBQVUsb0hBQXFIOzs7OztHQUNwSSx3QkFBQyxPQUFELEVBQUssV0FBVSxxSEFBc0g7Ozs7O0dBRXJJLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUdFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BR0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxnREFBaUQ7Ozs7O1NBQ2pFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFnQjtTQUE4Qjs7Ozs7U0FDOUQsd0JBQUMsUUFBRDtVQUFNLGVBQVk7VUFBTyxXQUFVO29CQUFnQjtTQUFPOzs7OztTQUMxRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBdUM7U0FBeUI7Ozs7O1FBQzdFOzs7Ozs7T0FHTCx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZDtTQUE2SDtTQUM3Ryx3QkFBQyxNQUFELEVBQUksV0FBVSxtQkFBb0I7Ozs7O1NBQ2hELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFxRjtTQUUvRjs7Ozs7UUFDSjs7Ozs7O09BR0osd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQW9GO09BRzlGOzs7OztPQUdILHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQ0Usd0JBQUMsY0FBRCxFQUFjLFdBQVUsaUNBQWtDOzs7O29CQUMxRCx3QkFBQyxRQUFELFlBQU0sNkJBQWdDOzs7O2tCQUNsQzs7Ozs7O1NBQ04sd0JBQUMsUUFBRDtVQUFNLGVBQVk7VUFBTyxXQUFVO29CQUFpQjtTQUFPOzs7OztTQUMzRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FDRSx3QkFBQyxjQUFELEVBQWMsV0FBVSxpQ0FBa0M7Ozs7b0JBQzFELHdCQUFDLFFBQUQsWUFBTSwrQkFBa0M7Ozs7a0JBQ3BDOzs7Ozs7U0FDTix3QkFBQyxRQUFEO1VBQU0sZUFBWTtVQUFPLFdBQVU7b0JBQWlCO1NBQU87Ozs7O1NBQzNELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUNFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLGlDQUFrQzs7OztvQkFDMUQsd0JBQUMsUUFBRCxZQUFNLHNCQUF5Qjs7OztrQkFDM0I7Ozs7OztRQUNIOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFVBQUQ7U0FDRSxTQUFTO1NBQ1QsV0FBVTttQkFGWixDQUlFLHdCQUFDLFFBQUQsWUFBTSxnQkFBbUI7Ozs7bUJBQ3pCLHdCQUFDLFlBQUQsRUFBWSxXQUFVLHlEQUEwRDs7OztpQkFDMUU7Ozs7O2tCQUVSLHdCQUFDLFVBQUQ7U0FDRSxTQUFTO1NBQ1QsV0FBVTttQkFGWixDQUlFLHdCQUFDLEtBQUQsRUFBSyxXQUFVLHdCQUF5Qjs7OzttQkFDeEMsd0JBQUMsUUFBRCxZQUFNLHFCQUF3Qjs7OztpQkFDeEI7Ozs7O2dCQUNMOzs7Ozs7T0FHTCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBcUQ7T0FFL0Q7Ozs7O01BQ0E7Ozs7O2VBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFHRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsaURBQWtEOzs7O29CQUNsRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBMkI7VUFBMEI7Ozs7a0JBQ2xFOzs7OzttQkFHTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNFLHdCQUFDLFVBQUQ7WUFDRSxlQUFlLGlCQUFpQixVQUFVO1lBQzFDLFdBQVcscURBQ1QsZUFBZSxhQUFhLDJDQUEyQztzQkFFMUU7V0FFTzs7Ozs7V0FDUix3QkFBQyxVQUFEO1lBQ0UsZUFBZSxpQkFBaUIsVUFBVTtZQUMxQyxXQUFXLHFEQUNULGVBQWUsYUFBYSwyQ0FBMkM7c0JBRTFFO1dBRU87Ozs7O1dBQ1Isd0JBQUMsVUFBRDtZQUNFLGVBQWUsaUJBQWlCLFdBQVc7WUFDM0MsV0FBVyxxREFDVCxlQUFlLGNBQWMsMkNBQTJDO3NCQUUzRTtXQUVPOzs7OztVQUNMOzs7OztpQkFDRjs7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFHRSx3QkFBQyxPQUFEO1dBQ0UsV0FBVTtXQUNWLE9BQU8sRUFBRSxVQUFVLGdCQUFnQixVQUFVLE9BQU8sVUFBVSxpQkFBaUI7cUJBRS9FLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBR0Usd0JBQUMsT0FBRDthQUFLLFNBQVE7YUFBYyxXQUFVO3VCQUFyQztjQUNFLHdCQUFDLFFBQUQsYUFDRSx3QkFBQyxrQkFBRDtlQUFnQixJQUFHO2VBQVcsSUFBRztlQUFLLElBQUc7ZUFBSyxJQUFHO2VBQU8sSUFBRzt5QkFBM0Q7Z0JBQ0Usd0JBQUMsUUFBRDtpQkFBTSxRQUFPO2lCQUFLLFdBQVU7Z0JBQVc7Ozs7O2dCQUN2Qyx3QkFBQyxRQUFEO2lCQUFNLFFBQU87aUJBQU0sV0FBVTtnQkFBVzs7Ozs7Z0JBQ3hDLHdCQUFDLFFBQUQ7aUJBQU0sUUFBTztpQkFBTyxXQUFVO2dCQUFXOzs7OztlQUMzQjs7Ozs7d0JBQ2hCLHdCQUFDLGtCQUFEO2VBQWdCLElBQUc7ZUFBa0IsSUFBRztlQUFNLElBQUc7ZUFBTSxHQUFFO3lCQUF6RDtnQkFDRSx3QkFBQyxRQUFEO2lCQUFNLFFBQU87aUJBQUssV0FBVTtnQkFBVzs7Ozs7Z0JBQ3ZDLHdCQUFDLFFBQUQ7aUJBQU0sUUFBTztpQkFBTSxXQUFVO2dCQUFXOzs7OztnQkFDeEMsd0JBQUMsUUFBRDtpQkFBTSxRQUFPO2lCQUFPLFdBQVU7Z0JBQVc7Ozs7O2VBQzNCOzs7OztzQkFDWjs7Ozs7Y0FFTix3QkFBQyxRQUFEO2VBQU0sT0FBTTtlQUFNLFFBQU87ZUFBTSxNQUFLO2NBQWtCOzs7OztjQUd0RCx3QkFBQyxRQUFEO2VBQU0sR0FBRTtlQUFtRSxNQUFLO2NBQVc7Ozs7O2NBQzNGLHdCQUFDLFFBQUQ7ZUFBTSxHQUFFO2VBQXlILE1BQUs7Y0FBVzs7Ozs7Y0FHakosd0JBQUMsV0FBRDtlQUFTLElBQUc7ZUFBTSxJQUFHO2VBQU0sSUFBRztlQUFLLElBQUc7ZUFBSyxNQUFLO2VBQVUsUUFBTztlQUFVLGFBQVk7Y0FBTzs7Ozs7Y0FDOUYsd0JBQUMsVUFBRDtlQUFRLElBQUc7ZUFBTSxJQUFHO2VBQU0sR0FBRTtlQUFJLE1BQUs7Y0FBVzs7Ozs7Y0FDaEQsd0JBQUMsVUFBRDtlQUFRLElBQUc7ZUFBTSxJQUFHO2VBQU0sR0FBRTtlQUFJLE1BQUs7Y0FBVzs7Ozs7Y0FFaEQsd0JBQUMsV0FBRDtlQUFTLElBQUc7ZUFBTSxJQUFHO2VBQU0sSUFBRztlQUFLLElBQUc7ZUFBSyxNQUFLO2VBQVUsUUFBTztlQUFVLGFBQVk7Y0FBTzs7Ozs7Y0FDOUYsd0JBQUMsVUFBRDtlQUFRLElBQUc7ZUFBTSxJQUFHO2VBQU0sR0FBRTtlQUFJLE1BQUs7Y0FBVzs7Ozs7Y0FDaEQsd0JBQUMsVUFBRDtlQUFRLElBQUc7ZUFBTSxJQUFHO2VBQU0sR0FBRTtlQUFJLE1BQUs7Y0FBVzs7Ozs7Y0FHaEQsd0JBQUMsUUFBRDtlQUFNLEdBQUU7ZUFBNkIsUUFBTztlQUFVLGFBQVk7ZUFBSSxNQUFLO2VBQU8sZUFBYztjQUFTOzs7OztjQUN6Ryx3QkFBQyxRQUFEO2VBQU0sR0FBRTtlQUE0QixRQUFPO2VBQVUsYUFBWTtlQUFNLE1BQUs7ZUFBTyxlQUFjO2NBQVM7Ozs7O2NBR3pHLE1BQU0sS0FBSyxFQUFFLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsTUFDbEMsd0JBQUMsUUFBRDtlQUFjLElBQUc7ZUFBSSxJQUFJLElBQUk7ZUFBSSxJQUFHO2VBQU0sSUFBSSxJQUFJO2VBQUksUUFBTztlQUFVLGFBQVk7ZUFBTSxpQkFBZ0I7ZUFBTSxTQUFRO2NBQVEsR0FBcEg7Ozs7cUJBQW9ILENBQ2hJO2FBQ0U7Ozs7O3NCQUdMLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFpSztZQUUzSzs7OztvQkFDRjs7Ozs7O1VBQ0Y7Ozs7O1VBR0wsd0JBQUMsT0FBRDtXQUNFLFdBQVU7V0FDVixPQUFPLEVBQUUsVUFBVSxXQUFXLFVBQVUsMEJBQTBCLFVBQVUsU0FBUztxQkFFckYsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FFRSx3QkFBQyxPQUFEO2FBQUssU0FBUTthQUFjLFdBQVU7dUJBQXJDO2NBQ0Usd0JBQUMsUUFBRCxZQUNFLHdCQUFDLGtCQUFEO2VBQWdCLElBQUc7ZUFBWSxJQUFHO2VBQU0sSUFBRztlQUFNLEdBQUU7eUJBQW5EO2dCQUNFLHdCQUFDLFFBQUQ7aUJBQU0sUUFBTztpQkFBSyxXQUFVO2lCQUFVLGFBQVk7Z0JBQU87Ozs7O2dCQUN6RCx3QkFBQyxRQUFEO2lCQUFNLFFBQU87aUJBQU0sV0FBVTtpQkFBVSxhQUFZO2dCQUFPOzs7OztnQkFDMUQsd0JBQUMsUUFBRDtpQkFBTSxRQUFPO2lCQUFPLFdBQVU7aUJBQWMsYUFBWTtnQkFBSzs7Ozs7ZUFDL0M7Ozs7O3VCQUNaOzs7OztjQUVOLHdCQUFDLFFBQUQ7ZUFBTSxPQUFNO2VBQU0sUUFBTztlQUFNLE1BQUs7Y0FBVzs7Ozs7Y0FDL0Msd0JBQUMsUUFBRDtlQUFNLE9BQU07ZUFBTSxRQUFPO2VBQU0sTUFBSztjQUFtQjs7Ozs7Y0FHdkQsd0JBQUMsS0FBRDtlQUFHLFFBQU87ZUFBVSxhQUFZO2VBQU8sU0FBUTt5QkFBL0MsQ0FDRyxNQUFNLEtBQUssRUFBRSxRQUFRLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLE1BQ2xDLHdCQUFDLFFBQUQ7Z0JBQXNCLElBQUksSUFBSTtnQkFBSSxJQUFHO2dCQUFJLElBQUksSUFBSTtnQkFBSSxJQUFHO2VBQU8sR0FBcEQsTUFBTTs7OztzQkFBOEMsQ0FDaEUsR0FDQSxNQUFNLEtBQUssRUFBRSxRQUFRLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLE1BQ2xDLHdCQUFDLFFBQUQ7Z0JBQXNCLElBQUc7Z0JBQUksSUFBSSxJQUFJO2dCQUFJLElBQUc7Z0JBQU0sSUFBSSxJQUFJO2VBQUssR0FBcEQsTUFBTTs7OztzQkFBOEMsQ0FDaEUsQ0FDQTs7Ozs7O2NBR0gsd0JBQUMsS0FBRDtlQUFHLFFBQU87ZUFBVSxhQUFZO2VBQU0sTUFBSztlQUFPLFNBQVE7eUJBQTFEO2dCQUNFLHdCQUFDLFdBQUQsRUFBUyxRQUFPLDBDQUEyQzs7Ozs7Z0JBQzNELHdCQUFDLFFBQUQ7aUJBQU0sSUFBRztpQkFBTSxJQUFHO2lCQUFNLElBQUc7aUJBQU0sSUFBRztpQkFBTSxpQkFBZ0I7Z0JBQU87Ozs7O2dCQUNqRSx3QkFBQyxRQUFEO2lCQUFNLElBQUc7aUJBQU0sSUFBRztpQkFBTSxJQUFHO2lCQUFNLElBQUc7aUJBQU0saUJBQWdCO2dCQUFPOzs7OztnQkFHakUsd0JBQUMsVUFBRDtpQkFBUSxJQUFHO2lCQUFNLElBQUc7aUJBQU0sR0FBRTtpQkFBSyxRQUFPO2lCQUFVLGFBQVk7aUJBQUksaUJBQWdCO2dCQUFPOzs7OztnQkFDekYsd0JBQUMsUUFBRDtpQkFBTSxJQUFHO2lCQUFNLElBQUc7aUJBQU0sSUFBRztpQkFBTSxJQUFHO2lCQUFNLFFBQU87aUJBQVUsYUFBWTtnQkFBTzs7Ozs7Z0JBQzlFLHdCQUFDLFVBQUQ7aUJBQVEsSUFBRztpQkFBTSxJQUFHO2lCQUFNLEdBQUU7aUJBQU0sTUFBSztnQkFBVzs7Ozs7Z0JBQ2xELHdCQUFDLFFBQUQ7aUJBQU0sR0FBRTtpQkFBTSxHQUFFO2lCQUFNLE1BQUs7aUJBQVUsVUFBUztpQkFBSSxZQUFXO2lCQUFZLFlBQVc7MkJBQU87Z0JBRXJGOzs7OztnQkFHTix3QkFBQyxVQUFEO2lCQUFRLElBQUc7aUJBQU0sSUFBRztpQkFBTSxHQUFFO2lCQUFLLFFBQU87aUJBQVUsYUFBWTtnQkFBTzs7Ozs7Z0JBQ3JFLHdCQUFDLFFBQUQ7aUJBQU0sR0FBRTtpQkFBTSxHQUFFO2lCQUFNLE1BQUs7aUJBQVUsVUFBUztpQkFBSSxZQUFXOzJCQUFZO2dCQUVuRTs7Ozs7ZUFDTDs7Ozs7O2FBQ0E7Ozs7O3NCQUdMLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUE4SztZQUV4TDs7OztvQkFDRjs7Ozs7O1VBQ0Y7Ozs7O1VBR0wsd0JBQUMsT0FBRDtXQUNFLFdBQVU7V0FDVixPQUFPLEVBQUUsTUFBTSxHQUFHLFVBQVUsR0FBRztxQkFGakMsQ0FJRSx3QkFBQyxPQUFELEVBQUssV0FBVSxvR0FBcUc7Ozs7cUJBQ3BILHdCQUFDLE9BQUQsRUFBSyxXQUFVLHVHQUF3Rzs7OzttQkFDcEg7Ozs7OztVQUdMLHdCQUFDLE9BQUQsRUFBSyxXQUFVLHlKQUEwSjs7Ozs7VUFHekssd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ2Isd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNFLHdCQUFDLE9BQUQsRUFBSyxXQUFXLHdCQUF3QixlQUFlLGNBQWMsbUJBQW1CLGNBQWMsZ0JBQWtCOzs7O3VCQUN4SCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQ2Isd0JBQUMsUUFBRCxZQUFPLGVBQWUsY0FBYyxxQkFBcUIsc0JBQTRCOzs7OzthQUNsRjs7Ozt1QkFDTCx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZjtlQUFzRDtlQUN2QztlQUFvQjtjQUM5Qjs7Ozs7cUJBQ0Y7Ozs7cUJBQ0Y7Ozs7O3NCQUVMLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQ1osZUFBZSxjQUFjLHNCQUFzQjthQUNqRDs7Ozt1QkFDTCx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBc0M7YUFFaEQ7Ozs7cUJBQ0Y7Ozs7O29CQUNGOzs7Ozs7VUFDRjs7Ozs7VUFHTCx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLEtBQUk7V0FDSixLQUFJO1dBQ0osT0FBTztXQUNQLFdBQVcsTUFBTSxhQUFhLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQztXQUNwRCxXQUFVO1dBQ1YsY0FBVztVQUNaOzs7OztTQUNFOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXVCO1dBQWtCOzs7O3FCQUN6RCx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaEI7YUFBK0MsY0FBYzthQUFTO2FBQUksY0FBYztZQUFlOzs7OzttQkFDcEc7Ozs7OztVQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXVCO1dBQW9COzs7O3FCQUMzRCx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaUMsY0FBYztXQUFtQjs7OzttQkFDL0U7Ozs7OztVQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXVCO1dBQWlCOzs7O3FCQUN4RCx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBZ0MsY0FBYztXQUFzQjs7OzttQkFDakY7Ozs7OztVQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNiLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFoQixDQUNFLHdCQUFDLG1CQUFELEVBQW1CLFdBQVUsVUFBVzs7OztzQkFDeEMsd0JBQUMsUUFBRCxZQUFNLGNBQWlCOzs7O29CQUNuQjs7Ozs7O1VBQ0g7Ozs7O1NBQ0Y7Ozs7OztPQUNGOzs7Ozs7S0FDRjs7OzthQUVGOzs7Ozs7R0FDRjs7Ozs7RUFDRTs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSGVyb1NlY3Rpb24udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQXJyb3dSaWdodCwgQ3B1LCBFeWUsIFNwYXJrbGVzLCBTbGlkZXJzSG9yaXpvbnRhbCwgQ2hlY2tDaXJjbGUyLCBTaGllbGRBbGVydCwgQWN0aXZpdHksIFJlZnJlc2hDdyB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmludGVyZmFjZSBIZXJvU2VjdGlvblByb3BzIHtcbiAgb25BbmFseXplQ2xpY2s6ICgpID0+IHZvaWQ7XG4gIG9uRXhwbG9yZVRlY2hDbGljazogKCkgPT4gdm9pZDtcbn1cblxudHlwZSBIZXJvQ2FzZSA9ICdwb3J0cmFpdCcgfCAnZGVlcGZha2UnIHwgJ2F1dGhlbnRpYyc7XG5cbmV4cG9ydCBjb25zdCBIZXJvU2VjdGlvbjogUmVhY3QuRkM8SGVyb1NlY3Rpb25Qcm9wcz4gPSAoe1xuICBvbkFuYWx5emVDbGljayxcbiAgb25FeHBsb3JlVGVjaENsaWNrLFxufSkgPT4ge1xuICBjb25zdCBbc2xpZGVyUG9zLCBzZXRTbGlkZXJQb3NdID0gdXNlU3RhdGU8bnVtYmVyPig1Mik7XG4gIGNvbnN0IFthY3RpdmVDYXNlLCBzZXRBY3RpdmVDYXNlXSA9IHVzZVN0YXRlPEhlcm9DYXNlPigncG9ydHJhaXQnKTtcbiAgY29uc3QgW3ZpZXdNb2RlLCBzZXRWaWV3TW9kZV0gPSB1c2VTdGF0ZTwnbGFzZXInIHwgJ2hlYXRtYXAnIHwgJ3dpcmVmcmFtZSc+KCdsYXNlcicpO1xuICBjb25zdCBbc2ltdWxhdGVkQ29uZmlkZW5jZSwgc2V0U2ltdWxhdGVkQ29uZmlkZW5jZV0gPSB1c2VTdGF0ZTxudW1iZXI+KDg5LjQpO1xuICBjb25zdCBbc2NhblRlbGVtZXRyeSwgc2V0U2NhblRlbGVtZXRyeV0gPSB1c2VTdGF0ZSh7XG4gICAgYXppbXV0aEw6ICc0Mi4xwrAnLFxuICAgIGF6aW11dGhSOiAnMTguNsKwJyxcbiAgICBmb3VyaWVyU3Bpa2U6ICcwLjQyIGN5Yy9weCcsXG4gICAgcHJudUNvcnJlbGF0aW9uOiAnciA9IDAuMDgnLFxuICB9KTtcblxuICAvLyBOYXR1cmFsIHN1YnRsZSB0ZWxlbWV0cnkgZmx1Y3R1YXRpb25cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBpbnRlcnZhbCA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICAgIHNldFNpbXVsYXRlZENvbmZpZGVuY2UoKHByZXYpID0+IHtcbiAgICAgICAgY29uc3QgZGVsdGEgPSAoTWF0aC5yYW5kb20oKSAtIDAuNSkgKiAwLjg7XG4gICAgICAgIHJldHVybiBNYXRoLm1pbig5NC4yLCBNYXRoLm1heCg4Ni4xLCBOdW1iZXIoKHByZXYgKyBkZWx0YSkudG9GaXhlZCgxKSkpKTtcbiAgICAgIH0pO1xuICAgIH0sIDI0MDApO1xuICAgIHJldHVybiAoKSA9PiBjbGVhckludGVydmFsKGludGVydmFsKTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IGhhbmRsZUNhc2VDaGFuZ2UgPSAobmV3Q2FzZTogSGVyb0Nhc2UpID0+IHtcbiAgICBzZXRBY3RpdmVDYXNlKG5ld0Nhc2UpO1xuICAgIGlmIChuZXdDYXNlID09PSAncG9ydHJhaXQnKSB7XG4gICAgICBzZXRTaW11bGF0ZWRDb25maWRlbmNlKDg5LjQpO1xuICAgICAgc2V0U2NhblRlbGVtZXRyeSh7XG4gICAgICAgIGF6aW11dGhMOiAnNDIuMcKwJyxcbiAgICAgICAgYXppbXV0aFI6ICcxOC42wrAnLFxuICAgICAgICBmb3VyaWVyU3Bpa2U6ICcwLjQyIGN5Yy9weCcsXG4gICAgICAgIHBybnVDb3JyZWxhdGlvbjogJ3IgPSAwLjA4JyxcbiAgICAgIH0pO1xuICAgIH0gZWxzZSBpZiAobmV3Q2FzZSA9PT0gJ2RlZXBmYWtlJykge1xuICAgICAgc2V0U2ltdWxhdGVkQ29uZmlkZW5jZSg4Ni44KTtcbiAgICAgIHNldFNjYW5UZWxlbWV0cnkoe1xuICAgICAgICBhemltdXRoTDogJzMxLjTCsCcsXG4gICAgICAgIGF6aW11dGhSOiAnMzAuOcKwJyxcbiAgICAgICAgZm91cmllclNwaWtlOiAnMC41MSBjeWMvcHgnLFxuICAgICAgICBwcm51Q29ycmVsYXRpb246ICdyID0gMC4xMicsXG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2V0U2ltdWxhdGVkQ29uZmlkZW5jZSg5Mi41KTtcbiAgICAgIHNldFNjYW5UZWxlbWV0cnkoe1xuICAgICAgICBhemltdXRoTDogJzI4LjDCsCcsXG4gICAgICAgIGF6aW11dGhSOiAnMjguMsKwJyxcbiAgICAgICAgZm91cmllclNwaWtlOiAnVW5pZm9ybScsXG4gICAgICAgIHBybnVDb3JyZWxhdGlvbjogJ3IgPSAwLjg5JyxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiBwdC0xMiBwYi0yNCBtZDpwdC0yMCBtZDpwYi0zMiBjeWJlci1ncmlkLXBhdHRlcm5cIj5cbiAgICAgIHsvKiBDaW5lbWF0aWMgYXRtb3NwaGVyaWMgZ2xvd2luZyBvcmJzICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMS80IGxlZnQtMS8yIC10cmFuc2xhdGUteC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB3LVs4NTBweF0gaC1bNDUwcHhdIGJnLWN5YW4tNTAwLzEwIHJvdW5kZWQtZnVsbCBibHVyLVsxNjBweF0gcG9pbnRlci1ldmVudHMtbm9uZSAtei0xMFwiIC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0xLzMgcmlnaHQtNCB3LVs1NTBweF0gaC1bNDUwcHhdIGJnLXZpb2xldC02MDAvMTUgcm91bmRlZC1mdWxsIGJsdXItWzE1MHB4XSBwb2ludGVyLWV2ZW50cy1ub25lIC16LTEwXCIgLz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLWJvdHRvbS0xMCBsZWZ0LTEwIHctWzQwMHB4XSBoLVszMDBweF0gYmctY3lhbi02MDAvMTAgcm91bmRlZC1mdWxsIGJsdXItWzEzMHB4XSBwb2ludGVyLWV2ZW50cy1ub25lIC16LTEwXCIgLz5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LTd4bCBweC02IGxnOnB4LThcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0xMiBnYXAtMTIgbGc6Z2FwLTEwIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgIFxuICAgICAgICAgIHsvKiBMZWZ0IENvbHVtbjogSGVybyBQcm9wb3NpdGlvbiBhbmQgQ1RBcyAoNyBjb2xzKSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTcgc3BhY2UteS03XCI+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHsvKiBUYWdsaW5lIGtpY2tlciAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgcHgtNCBweS0xLjUgcm91bmRlZC1mdWxsIGJnLWN5YW4tOTUwLzcwIGJvcmRlciBib3JkZXItY3lhbi01MDAvMzAgdGV4dC1jeWFuLTMwMCB0ZXh0LXhzIGZvbnQtbW9ubyB0cmFja2luZy13aWRlciB1cHBlcmNhc2UgYmFja2Ryb3AtYmx1ci1tZCBzaGFkb3ctWzBfMF8yMHB4X3JnYmEoNiwxODIsMjEyLDAuMTUpXVwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTIgaC0yIHJvdW5kZWQtZnVsbCBiZy1jeWFuLTQwMCBhbmltYXRlLXBpbmdcIiAvPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+U2VlIEJleW9uZCB0aGUgU3ludGhldGljPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIiBjbGFzc05hbWU9XCJ0ZXh0LWN5YW4tNzAwXCI+wrc8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPnYyLjQgRm9yZW5zaWMgU3VpdGU8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEhlYWRsaW5lICovfVxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtNHhsIHNtOnRleHQtNXhsIGxnOnRleHQtNnhsIGZvbnQtZXh0cmFib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtd2hpdGUgbGVhZGluZy1bMS4wOF0gW3RleHQtd3JhcDpiYWxhbmNlXVwiPlxuICAgICAgICAgICAgICBDYW4gWW91IFRydXN0IDxiciBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLXdoaXRlIHZpYS1jeWFuLTIwMCB0by1jeWFuLTQwMCBiZy1jbGlwLXRleHQgdGV4dC10cmFuc3BhcmVudFwiPlxuICAgICAgICAgICAgICAgIFdoYXQgWW91IFNlZT9cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9oMT5cblxuICAgICAgICAgICAgey8qIFN1YnRpdGxlICovfVxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1iYXNlIHNtOnRleHQtbGcgdGV4dC1zbGF0ZS0zMDAgbWF4LXctMnhsIGxlYWRpbmctcmVsYXhlZCBbdGV4dC13cmFwOmJhbGFuY2VdXCI+XG4gICAgICAgICAgICAgIERpc2NvdmVyIHRoZSBzaWduYWxzIGJlaGluZCBzeW50aGV0aWMgbWVkaWEgd2l0aCBpbnRlbGxpZ2VudCBpbWFnZSBhbmQgdmlkZW8gYW5hbHlzaXMuIFxuICAgICAgICAgICAgICBJbnRlcnJvZ2F0ZSBEaXNjcmV0ZSBDb3NpbmUgVHJhbnNmb3JtIChEQ1QpIGRlY29udm9sdXRpb24gYXJ0aWZhY3RzLCBiaS1vY3VsYXIgY2F0Y2hsaWdodCBkaXNjb3JkYW5jZSwgYW5kIGxhdGVudCB0ZW1wb3JhbCBkcmlmdC5cbiAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAgey8qIE1pY3JvIHByb29mIGJhZGdlcyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC14LTUgZ2FwLXktMi41IHRleHQteHMgdGV4dC1zbGF0ZS00MDAgcHQtMSBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1jeWFuLTQwMCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+RXJyb3IgTGV2ZWwgQW5hbHlzaXMgKEVMQSk8L3NwYW4+XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gYXJpYS1oaWRkZW49XCJ0cnVlXCIgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS03MDBcIj4vPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWN5YW4tNDAwIHNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5UZW1wb3JhbCBGbG93IFZpZGVvIFNjcnV0aW55PC9zcGFuPlxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNzAwXCI+Lzwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1jeWFuLTQwMCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+QzJQQSBNYW5pZmVzdCBBdWRpdDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBBY3Rpb24gQnV0dG9ucyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBpdGVtcy1zdHJldGNoIHNtOml0ZW1zLWNlbnRlciBnYXAtNCBwdC0zXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkFuYWx5emVDbGlja31cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTMgcHgtNyBweS00IHRleHQtc20gZm9udC1ib2xkIHRleHQtYmxhY2sgYmctZ3JhZGllbnQtdG8tciBmcm9tLWN5YW4tNDAwIHZpYS1jeWFuLTMwMCB0by10ZWFsLTMwMCBob3Zlcjpmcm9tLWN5YW4tMzAwIGhvdmVyOnRvLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LVswXzBfMzVweF9yZ2JhKDYsMTgyLDIxMiwwLjQpXSB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBhY3RpdmU6c2NhbGUtOThcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPHNwYW4+QW5hbHl6ZSBNZWRpYTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJoLTQgdy00IHRyYW5zaXRpb24tdHJhbnNmb3JtIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTFcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17b25FeHBsb3JlVGVjaENsaWNrfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMi41IHB4LTYgcHktNCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0yMDAgaG92ZXI6dGV4dC13aGl0ZSBiZy13aGl0ZS9bMC4wNF0gaG92ZXI6Ymctd2hpdGUvWzAuMDhdIGJvcmRlciBib3JkZXItd2hpdGUvWzAuMTJdIGhvdmVyOmJvcmRlci1jeWFuLTUwMC80MCByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGJhY2tkcm9wLWJsdXItbWRcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPENwdSBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtY3lhbi00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkV4cGxvcmUgVGVjaG5vbG9neTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFRyYW5zcGFyZW50IEFyY2hpdGVjdHVyZSBOb3RlICovfVxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgbWF4LXctbGcgbGVhZGluZy1ub3JtYWxcIj5cbiAgICAgICAgICAgICAgQnVpbHQgb24gdHJhbnNwYXJlbnQgc2NpZW50aWZpYyBoZXVyaXN0aWNzIHdpdGhvdXQgZXhhZ2dlcmF0ZWQgY2xhaW1zLiBFdmFsdWF0ZXMgb2JzZXJ2YWJsZSBwaHlzaWNhbCBzZW5zb3IgcGh5c2ljcyBhbmQgY29tcHJlc3Npb24gZm9vdHByaW50cy5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBSaWdodCBDb2x1bW46IEludGVyYWN0aXZlIFNjYW5uaW5nIFZpc3VhbCB3aXRoIEhVRCwgUmV0aWNsZXMgJiBMYXNlciBCZWFtICg1IGNvbHMpICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tNSByZWxhdGl2ZVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBteC1hdXRvIG1heC13LVs0ODBweF0gcm91bmRlZC0zeGwgYmctZ3JhZGllbnQtdG8tYiBmcm9tLXdoaXRlL1swLjEyXSB2aWEtd2hpdGUvWzAuMDRdIHRvLXRyYW5zcGFyZW50IHAtMiBiYWNrZHJvcC1ibHVyLTJ4bCBib3JkZXIgYm9yZGVyLWN5YW4tNTAwLzM1IHNoYWRvdy1bMF8wXzYwcHhfcmdiYSg2LDE4MiwyMTIsMC4yKV1cIj5cbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgIHsvKiBUb3AgVmlld3BvcnQgVG9vbGJhciAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHgtMyBweS0yIGJvcmRlci1iIGJvcmRlci13aGl0ZS9bMC4wOF0gdGV4dC1bMTFweF0gZm9udC1tb25vIHRleHQtc2xhdGUtNDAwIG1iLTJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTIgaC0yIHJvdW5kZWQtZnVsbCBiZy1jeWFuLTQwMCBhbmltYXRlLXB1bHNlXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgZm9udC1zZW1pYm9sZFwiPkxJVkUgRk9SRU5TSUMgVklFV0VSPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIHsvKiBCZW5jaG1hcmsgQ2FzZSBTd2l0Y2hlciAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHAtMC41IGJnLWJsYWNrLzQwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci13aGl0ZS9bMC4wNl1cIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQ2FzZUNoYW5nZSgncG9ydHJhaXQnKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMiBweS0wLjUgcm91bmRlZCB0ZXh0LVsxMHB4XSB0cmFuc2l0aW9uLWNvbG9ycyAke1xuICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZUNhc2UgPT09ICdwb3J0cmFpdCcgPyAnYmctY3lhbi01MDAvMjAgdGV4dC1jeWFuLTMwMCBmb250LWJvbGQnIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBBSSBGYWNlXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQ2FzZUNoYW5nZSgnZGVlcGZha2UnKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMiBweS0wLjUgcm91bmRlZCB0ZXh0LVsxMHB4XSB0cmFuc2l0aW9uLWNvbG9ycyAke1xuICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZUNhc2UgPT09ICdkZWVwZmFrZScgPyAnYmctY3lhbi01MDAvMjAgdGV4dC1jeWFuLTMwMCBmb250LWJvbGQnIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBWaWRlbyBDbGlwXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQ2FzZUNoYW5nZSgnYXV0aGVudGljJyl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTIgcHktMC41IHJvdW5kZWQgdGV4dC1bMTBweF0gdHJhbnNpdGlvbi1jb2xvcnMgJHtcbiAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVDYXNlID09PSAnYXV0aGVudGljJyA/ICdiZy1jeWFuLTUwMC8yMCB0ZXh0LWN5YW4tMzAwIGZvbnQtYm9sZCcgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDM1bW0gRmlsbVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBWaWV3cG9ydCBGcmFtZSAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBhc3BlY3QtWzQvNV0gdy1mdWxsIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLTJ4bCBiZy1bIzAyMDUwZl0gYm9yZGVyIGJvcmRlci13aGl0ZS9bMC4wNl1cIj5cbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICB7LyogVmlzdWFsIExheWVyIDE6IExlZnQgLyBCYXNlbGluZSBTaWRlICovfVxuICAgICAgICAgICAgICAgIDxkaXYgXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIG92ZXJmbG93LWhpZGRlblwiXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBjbGlwUGF0aDogYHBvbHlnb24oMCAwLCAke3NsaWRlclBvc30lIDAsICR7c2xpZGVyUG9zfSUgMTAwJSwgMCAxMDAlKWAgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBoLWZ1bGwgYmctZ3JhZGllbnQtdG8tYiBmcm9tLXNsYXRlLTkwMCB2aWEtWyMwNzBkMWVdIHRvLWJsYWNrIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICB7LyogU1ZHIEZhY2UgLyBTdWJqZWN0IFNpbGhvdWV0dGUgd2l0aCBSZWFsaXN0aWMgTGlnaHRpbmcgKi99XG4gICAgICAgICAgICAgICAgICAgIDxzdmcgdmlld0JveD1cIjAgMCA0MDAgNTAwXCIgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGVmcz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsaW5lYXJHcmFkaWVudCBpZD1cInNraW5HcmFkXCIgeDE9XCIwJVwiIHkxPVwiMCVcIiB4Mj1cIjEwMCVcIiB5Mj1cIjEwMCVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHN0b3Agb2Zmc2V0PVwiMCVcIiBzdG9wQ29sb3I9XCIjMWUyOTNiXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHN0b3Agb2Zmc2V0PVwiNTAlXCIgc3RvcENvbG9yPVwiIzBmMTcyYVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzdG9wIG9mZnNldD1cIjEwMCVcIiBzdG9wQ29sb3I9XCIjMDIwNjE3XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGluZWFyR3JhZGllbnQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cmFkaWFsR3JhZGllbnQgaWQ9XCJleWVTcGVjdWxhckxlZnRcIiBjeD1cIjQ1JVwiIGN5PVwiNDAlXCIgcj1cIjI1JVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3RvcCBvZmZzZXQ9XCIwJVwiIHN0b3BDb2xvcj1cIiNmZmZmZmZcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3RvcCBvZmZzZXQ9XCI3MCVcIiBzdG9wQ29sb3I9XCIjMzhiZGY4XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHN0b3Agb2Zmc2V0PVwiMTAwJVwiIHN0b3BDb2xvcj1cIiMwMzY5YTFcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9yYWRpYWxHcmFkaWVudD5cbiAgICAgICAgICAgICAgICAgICAgICA8L2RlZnM+XG5cbiAgICAgICAgICAgICAgICAgICAgICA8cmVjdCB3aWR0aD1cIjQwMFwiIGhlaWdodD1cIjUwMFwiIGZpbGw9XCJ1cmwoI3NraW5HcmFkKVwiIC8+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogSGVhZCBhbmQgc2hvdWxkZXJzIGNvbnRvdXIgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk0xMjAgNTAwIEMxMjAgNDIwLCAxNTAgMzcwLCAyMDAgMzcwIEMyNTAgMzcwLCAyODAgNDIwLCAyODAgNTAwIFpcIiBmaWxsPVwiIzBiMTEyMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk0yMDAgMTEwIEMxNDUgMTEwLCAxMjUgMTY1LCAxMjUgMjM1IEMxMjUgMzE1LCAxNTUgMzc1LCAyMDAgMzgwIEMyNDUgMzc1LCAyNzUgMzE1LCAyNzUgMjM1IEMyNzUgMTY1LCAyNTUgMTEwLCAyMDAgMTEwIFpcIiBmaWxsPVwiIzFlMjkzYlwiIC8+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogRXllcyB3aXRoIHNwZWN1bGFyIGNhdGNobGlnaHRzICovfVxuICAgICAgICAgICAgICAgICAgICAgIDxlbGxpcHNlIGN4PVwiMTY1XCIgY3k9XCIyMjBcIiByeD1cIjE4XCIgcnk9XCIxMVwiIGZpbGw9XCIjMGYxNzJhXCIgc3Ryb2tlPVwiIzMzNDE1NVwiIHN0cm9rZVdpZHRoPVwiMS41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8Y2lyY2xlIGN4PVwiMTY1XCIgY3k9XCIyMjBcIiByPVwiN1wiIGZpbGw9XCIjMDI4NGM3XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8Y2lyY2xlIGN4PVwiMTYzXCIgY3k9XCIyMThcIiByPVwiM1wiIGZpbGw9XCIjZmZmZmZmXCIgLz5cblxuICAgICAgICAgICAgICAgICAgICAgIDxlbGxpcHNlIGN4PVwiMjM1XCIgY3k9XCIyMjBcIiByeD1cIjE4XCIgcnk9XCIxMVwiIGZpbGw9XCIjMGYxNzJhXCIgc3Ryb2tlPVwiIzMzNDE1NVwiIHN0cm9rZVdpZHRoPVwiMS41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8Y2lyY2xlIGN4PVwiMjM1XCIgY3k9XCIyMjBcIiByPVwiN1wiIGZpbGw9XCIjMDI4NGM3XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8Y2lyY2xlIGN4PVwiMjM3XCIgY3k9XCIyMThcIiByPVwiM1wiIGZpbGw9XCIjZmZmZmZmXCIgLz5cblxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBOb3NlICYgTGlwcyBvdXRsaW5lICovfVxuICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIGQ9XCJNMTk1IDI0NSBMMjAwIDI3MCBMMTkwIDI3NVwiIHN0cm9rZT1cIiM0NzU1NjlcIiBzdHJva2VXaWR0aD1cIjJcIiBmaWxsPVwibm9uZVwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk0xODAgMzEwIFEyMDAgMzI1IDIyMCAzMTBcIiBzdHJva2U9XCIjNjQ3NDhiXCIgc3Ryb2tlV2lkdGg9XCIyLjVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIC8+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogU2ltdWxhdGVkIGNhbWVyYSBzZW5zb3Igbm9pc2UgbGluZXMgKi99XG4gICAgICAgICAgICAgICAgICAgICAge0FycmF5LmZyb20oeyBsZW5ndGg6IDI1IH0pLm1hcCgoXywgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpbmUga2V5PXtpfSB4MT1cIjBcIiB5MT17aSAqIDIwfSB4Mj1cIjQwMFwiIHkyPXtpICogMjB9IHN0cm9rZT1cIiMzOGJkZjhcIiBzdHJva2VXaWR0aD1cIjAuNVwiIHN0cm9rZURhc2hhcnJheT1cIjMgNlwiIG9wYWNpdHk9XCIwLjEyXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9zdmc+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIE1vZGUgVGFnICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC00IGxlZnQtNCB0ZXh0LVsxMHB4XSBmb250LW1vbm8gdHJhY2tpbmctd2lkZXN0IHVwcGVyY2FzZSBweC0yLjUgcHktMSByb3VuZGVkLWxnIGJnLWJsYWNrLzcwIGJvcmRlciBib3JkZXItd2hpdGUvMTUgdGV4dC1jeWFuLTMwMCBiYWNrZHJvcC1ibHVyLW1kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgU2Vuc29yeSBCYXNlbGluZVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIFZpc3VhbCBMYXllciAyOiBSaWdodCAvIFN5bnRoZXRpYyBEZWNvbnN0cnVjdGlvbiBTaWRlICovfVxuICAgICAgICAgICAgICAgIDxkaXYgXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIG92ZXJmbG93LWhpZGRlblwiXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBjbGlwUGF0aDogYHBvbHlnb24oJHtzbGlkZXJQb3N9JSAwLCAxMDAlIDAsIDEwMCUgMTAwJSwgJHtzbGlkZXJQb3N9JSAxMDAlKWAgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBoLWZ1bGwgYmctWyMwMzA2MTZdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICA8c3ZnIHZpZXdCb3g9XCIwIDAgNDAwIDUwMFwiIGNsYXNzTmFtZT1cInctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRlZnM+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cmFkaWFsR3JhZGllbnQgaWQ9XCJzeW50aEdsb3dcIiBjeD1cIjYwJVwiIGN5PVwiNDUlXCIgcj1cIjM1JVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3RvcCBvZmZzZXQ9XCIwJVwiIHN0b3BDb2xvcj1cIiNhODU1ZjdcIiBzdG9wT3BhY2l0eT1cIjAuOFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzdG9wIG9mZnNldD1cIjYwJVwiIHN0b3BDb2xvcj1cIiMwNmI2ZDRcIiBzdG9wT3BhY2l0eT1cIjAuM1wiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzdG9wIG9mZnNldD1cIjEwMCVcIiBzdG9wQ29sb3I9XCJ0cmFuc3BhcmVudFwiIHN0b3BPcGFjaXR5PVwiMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3JhZGlhbEdyYWRpZW50PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGVmcz5cblxuICAgICAgICAgICAgICAgICAgICAgIDxyZWN0IHdpZHRoPVwiNDAwXCIgaGVpZ2h0PVwiNTAwXCIgZmlsbD1cIiMwMzA2MTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxyZWN0IHdpZHRoPVwiNDAwXCIgaGVpZ2h0PVwiNTAwXCIgZmlsbD1cInVybCgjc3ludGhHbG93KVwiIC8+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogRGVjb25zdHJ1Y3Rpb24gd2lyZWZyYW1lIGdyaWQgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPGcgc3Ryb2tlPVwiIzA2YjZkNFwiIHN0cm9rZVdpZHRoPVwiMC43NVwiIG9wYWNpdHk9XCIwLjM1XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7QXJyYXkuZnJvbSh7IGxlbmd0aDogMTcgfSkubWFwKChfLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsaW5lIGtleT17YGd2LSR7aX1gfSB4MT17aSAqIDI1fSB5MT1cIjBcIiB4Mj17aSAqIDI1fSB5Mj1cIjUwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHtBcnJheS5mcm9tKHsgbGVuZ3RoOiAyMiB9KS5tYXAoKF8sIGkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpbmUga2V5PXtgZ2gtJHtpfWB9IHgxPVwiMFwiIHkxPXtpICogMjR9IHgyPVwiNDAwXCIgeTI9e2kgKiAyNH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZz5cblxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBEZWNvbXBvc2VkIGZhY2lhbCBnZW9tZXRyeSAmIG9jdWxhciBkaXNjb3JkYW5jZSB2ZWN0b3JzICovfVxuICAgICAgICAgICAgICAgICAgICAgIDxnIHN0cm9rZT1cIiNjMDg0ZmNcIiBzdHJva2VXaWR0aD1cIjEuNFwiIGZpbGw9XCJub25lXCIgb3BhY2l0eT1cIjAuOVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHBvbHlnb24gcG9pbnRzPVwiMjAwLDExMCAyNDAsMTUwIDI3NSwyMzUgMjUwLDMwMCAyMDAsMzgwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsaW5lIHgxPVwiMjAwXCIgeTE9XCIxMTBcIiB4Mj1cIjI3NVwiIHkyPVwiMjM1XCIgc3Ryb2tlRGFzaGFycmF5PVwiNCA0XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsaW5lIHgxPVwiMjQwXCIgeTE9XCIxNTBcIiB4Mj1cIjIwMFwiIHkyPVwiMzgwXCIgc3Ryb2tlRGFzaGFycmF5PVwiNCA0XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIFJpZ2h0IEV5ZSBEaXNjb3JkYW5jZSB0YXJnZXQgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8Y2lyY2xlIGN4PVwiMjM1XCIgY3k9XCIyMjBcIiByPVwiMTZcIiBzdHJva2U9XCIjZjQzZjVlXCIgc3Ryb2tlV2lkdGg9XCIyXCIgc3Ryb2tlRGFzaGFycmF5PVwiMyAzXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsaW5lIHgxPVwiMjM1XCIgeTE9XCIyMjBcIiB4Mj1cIjI3MFwiIHkyPVwiMTkwXCIgc3Ryb2tlPVwiI2Y0M2Y1ZVwiIHN0cm9rZVdpZHRoPVwiMS41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxjaXJjbGUgY3g9XCIyNzBcIiBjeT1cIjE5MFwiIHI9XCIyLjVcIiBmaWxsPVwiI2Y0M2Y1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGV4dCB4PVwiMjc4XCIgeT1cIjE5M1wiIGZpbGw9XCIjZjQzZjVlXCIgZm9udFNpemU9XCI5XCIgZm9udEZhbWlseT1cIm1vbm9zcGFjZVwiIGZvbnRXZWlnaHQ9XCJib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIM6UIDIzLjXCsCBDT1JORUFMIEVSUk9SXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RleHQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBGcmVxdWVuY3kgcmVzaWR1ZSBjbHVzdGVyICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGNpcmNsZSBjeD1cIjI1MFwiIGN5PVwiMjkwXCIgcj1cIjEwXCIgc3Ryb2tlPVwiIzA2YjZkNFwiIHN0cm9rZVdpZHRoPVwiMS41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0IHg9XCIyNjVcIiB5PVwiMjk1XCIgZmlsbD1cIiMyMmQzZWVcIiBmb250U2l6ZT1cIjhcIiBmb250RmFtaWx5PVwibW9ub3NwYWNlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIERDVCBESVNQQVJJVFlcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGV4dD5cbiAgICAgICAgICAgICAgICAgICAgICA8L2c+XG4gICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBNb2RlIFRhZyAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtNCByaWdodC00IHRleHQtWzEwcHhdIGZvbnQtbW9ubyB0cmFja2luZy13aWRlc3QgdXBwZXJjYXNlIHB4LTIuNSBweS0xIHJvdW5kZWQtbGcgYmctdmlvbGV0LTk1MC84MCBib3JkZXIgYm9yZGVyLXZpb2xldC01MDAvNDAgdGV4dC12aW9sZXQtMzAwIGJhY2tkcm9wLWJsdXItbWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICBTeW50aGV0aWMgTWVzaFxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIEFuaW1hdGVkIE1vdmluZyBMYXNlciBCZWFtICovfVxuICAgICAgICAgICAgICAgIDxkaXYgXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMCBib3R0b20tMCB3LTAuNSBiZy1ncmFkaWVudC10by1iIGZyb20tY3lhbi0zMDAgdmlhLXdoaXRlIHRvLXZpb2xldC00MDAgc2hhZG93LVswXzBfMTVweF8jMjJkM2VlLDBfMF8zNXB4XyM4YjVjZjZdIHBvaW50ZXItZXZlbnRzLW5vbmUgei0yMFwiXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBsZWZ0OiBgJHtzbGlkZXJQb3N9JWAgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIC10b3AtMS41IC1sZWZ0LTEuNSB3LTQgaC00IHJvdW5kZWQtZnVsbCBiZy1jeWFuLTMwMCBibHVyLVsycHhdIHNoYWRvdy1bMF8wXzEwcHhfIzIyZDNlZV1cIiAvPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtYm90dG9tLTEuNSAtbGVmdC0xLjUgdy00IGgtNCByb3VuZGVkLWZ1bGwgYmctY3lhbi0zMDAgYmx1ci1bMnB4XSBzaGFkb3ctWzBfMF8xMHB4XyMyMmQzZWVdXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBTd2VlcGluZyBsYXNlciBob3Jpem9udGFsIGJlYW0gKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTAgcmlnaHQtMCBoLTIuNSBiZy1ncmFkaWVudC10by1yIGZyb20tdHJhbnNwYXJlbnQgdmlhLWN5YW4tNDAwLzkwIHRvLXRyYW5zcGFyZW50IGJsdXItWzFweF0gYW5pbWF0ZS1sYXNlci1zd2VlcCBwb2ludGVyLWV2ZW50cy1ub25lIHotMTBcIiAvPlxuXG4gICAgICAgICAgICAgICAgey8qIEhvbG9ncmFwaGljIEF1dGhlbnRpY2l0eSBJbmRpY2F0b3IgSFVEIEJhZGdlICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTQgbGVmdC00IHJpZ2h0LTQgei0zMCBwLTMuNSByb3VuZGVkLTJ4bCBiZy1bIzA0MDgxNl0vOTAgYm9yZGVyIGJvcmRlci1jeWFuLTUwMC8zNSBiYWNrZHJvcC1ibHVyLXhsIGhvbG9ncmFwaGljLWdsb3dcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdy0zIGgtMyByb3VuZGVkLWZ1bGwgJHthY3RpdmVDYXNlID09PSAnYXV0aGVudGljJyA/ICdiZy1lbWVyYWxkLTQwMCcgOiAnYmctcm9zZS01MDAnfSBhbmltYXRlLXB1bHNlYH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8gZm9udC1ib2xkIHRyYWNraW5nLXdpZGVyIHRleHQtd2hpdGUgdXBwZXJjYXNlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2FjdGl2ZUNhc2UgPT09ICdhdXRoZW50aWMnID8gJ0xpa2VseSBBdXRoZW50aWMnIDogJ0xpa2VseSBBSS1nZW5lcmF0ZWQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgQ29uZmlkZW5jZToge3NpbXVsYXRlZENvbmZpZGVuY2V9JSAowrE1LjUlKVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LW1vbm8gZm9udC1zZW1pYm9sZCB0ZXh0LWN5YW4tNDAwIHVwcGVyY2FzZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2FjdGl2ZUNhc2UgPT09ICdhdXRoZW50aWMnID8gJ1BSTlUgU2Vuc29yIE1hdGNoJyA6ICdDb3JuZWFsIEdsYXJlIERpc2NvcmQnfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bOXB4XSB0ZXh0LXNsYXRlLTQwMCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFZlY3RvciAwNCAvIEF1ZGl0ZWRcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBSYW5nZSBTbGlkZXIgZm9yIEludGVyYWN0aW9uICovfVxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgICAgIG1pbj1cIjhcIlxuICAgICAgICAgICAgICAgICAgbWF4PVwiOTJcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NsaWRlclBvc31cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2xpZGVyUG9zKE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteC0wIGJvdHRvbS0xOCBoLTEwIG9wYWNpdHktMCBjdXJzb3ItZXctcmVzaXplIHotNDBcIlxuICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkRyYWcgc3BsaXQgY29tcGFyaXNvbiBzbGlkZXJcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBWaWV3cG9ydCBCb3R0b20gVGVsZW1ldHJ5IFN0cmlwICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZ3JpZCBncmlkLWNvbHMtMiBzbTpncmlkLWNvbHMtNCBnYXAtMiB0ZXh0LVsxMHB4XSBmb250LW1vbm8gcHgtMiB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZCBiZy13aGl0ZS9bMC4wMl0gYm9yZGVyIGJvcmRlci13aGl0ZS9bMC4wNF1cIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrXCI+RXllIEF6aW11dGg6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1jeWFuLTMwMCBmb250LXNlbWlib2xkXCI+e3NjYW5UZWxlbWV0cnkuYXppbXV0aEx9IC8ge3NjYW5UZWxlbWV0cnkuYXppbXV0aFJ9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZCBiZy13aGl0ZS9bMC4wMl0gYm9yZGVyIGJvcmRlci13aGl0ZS9bMC4wNF1cIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrXCI+TnlxdWlzdCBTcGlrZTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC0zMDAgZm9udC1zZW1pYm9sZFwiPntzY2FuVGVsZW1ldHJ5LmZvdXJpZXJTcGlrZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTEuNSByb3VuZGVkIGJnLXdoaXRlL1swLjAyXSBib3JkZXIgYm9yZGVyLXdoaXRlL1swLjA0XVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgYmxvY2tcIj5QUk5VIE1hdGNoOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMjAwIGZvbnQtc2VtaWJvbGRcIj57c2NhblRlbGVtZXRyeS5wcm51Q29ycmVsYXRpb259PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZCBiZy13aGl0ZS9bMC4wMl0gYm9yZGVyIGJvcmRlci13aGl0ZS9bMC4wNF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWN5YW4tNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxTbGlkZXJzSG9yaXpvbnRhbCBjbGFzc05hbWU9XCJoLTMgdy0zXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+RHJhZyBTbGlkZXI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59O1xuIl19